package Stepik.Lesson31_Generics;
import java.util.ArrayList;
public class Nomber2_ParametrizedMethods {
    public static void main(String[] args) {
        ArrayList<Integer>al1=new ArrayList<>();
        al1.add(23);
        al1.add(49);
        al1.add(120);
        al1.add(2);
        int a=GenereticMethod.getSecondElement(al1);
        System.out.println(a);
        System.out.println(GenereticMethod.getSecondElement(al1));

        System.out.println();

        ArrayList<String>al2=new ArrayList<>();
        al2.add("a");
        al2.add("b");
        al2.add("c");
        String s = GenereticMethod.getSecondElement(al2);
        System.out.println(s);
        System.out.println(GenereticMethod.getSecondElement(al2));
    }
}
class GenereticMethod{
    public static <T> T getSecondElement(ArrayList<T>al){
        return al.get(1);  //выводит второй элемент из листа
    }
}
