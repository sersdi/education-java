package Stepik.Lesson31_Generics;
public class Nomber1_ParametrizedClass {
    public static void main(String[] args) {
        Info<String>info1=new Info<>("privet");         //<String> generics TypeSafe Reusable Code
        System.out.println(info1);
        String s = info1.getValue();
        System.out.println(s);
        System.out.println();

        Info<Integer>info2=new Info<>(123);
        System.out.println(info2);
        Integer i1 = info2.getValue();
        System.out.println(i1);
    }

//    public void abc(Info<String>info){                             //Type erasure стирание
//        String s =info.getValue();                                проблемы с оверлоадед методами тк для джавы машины они выглядят без дженеретиков и они одинаковые
//    }                                                                  abc(Info info)
//    public void abc(Info<Integer>info){
//        Integer i =info.getValue();
//    }


}
class Info<T>{                   //Parametrized class      <T>-хранитель данных сюда будет подставляться нужный нам тип данных который мы укажем в мейне
    private T value;

    public Info(T value){       //конструктор
        this.value=value;
    }
    public String toString(){   //метод вывода тустринг
        return "[{"+value+"}]";
    }

    public T getValue() {       //метод гет
        return value;
    }
}
//class Parent{                                     //проблемы с оверайдед методами    для джавы машины abc(Info info)
//    public void abc(Info<String>info){
//       String s =info.getValue();
//    }
//}
//class Child extends Parent{
//    public void abc(Info<Integer>info){
//        Integer i =info.getValue();
//    }



//}