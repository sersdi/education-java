package Stepik.Lesson22_Encapsulation_Super_Protected;
                                //При инкапсуляции мы запрещаем влиять на переменные напрямую(принимать не нужные значения)

public class Chelovek {

    final String pol;                                //константа переменная пол
    public Chelovek(String pol){    //конструктор
        this.pol=pol;
    }           //конструктор Конструкторы ненаследуются
    private StringBuilder name;                             //переменные с типом данных приват нельзя вызвать вне класса Для этого создаю методы на вывод и изменение переменных
    private int vosrast;
    private int ves;
    private boolean clever;

    public StringBuilder getName(){                            //метод Get выводит на экран переменную name
        StringBuilder sb = new StringBuilder(name);             // Создаём копию обьекта и выводим её что бы нельзя было изменить при вызове метода get
        return sb;
    }
    public void setName(StringBuilder s) {     //метод Set позволяющий изменять name
        name = s;
    }
    public int getVosrast() {
        return vosrast;
    }
    public void setVosrast(int i) {
        if(i>0){                                                //устанавливаем границы для переменной
            vosrast=i;
        }
    }
    public int getVes() {
        return ves;
    }
    public void setVes(int i) {
        if(i>0){
            ves=i;
        }
    }
    public boolean isClever(){                              //когда работает с булиан переменными вместо гет пишем ис
        return clever;
    }
}
class Test{
    public static void main(String[] args) {
        Chelovek c = new Chelovek("Male");
        c.setName(new StringBuilder("Kolya"));
        c.setVes(69);
        c.setVosrast(36);

        System.out.println(c.getName());
        System.out.println(c.getVes());
        System.out.println(c.getVosrast());
        c.setVes(-30);
        System.out.println(c.getVes());

        c.getName().append("!!!");   //обьект не изменится тк сделали в методе get копию обьекта и вызываем её(меняется копия а не name)
        System.out.println(c.getName());







    }
}
