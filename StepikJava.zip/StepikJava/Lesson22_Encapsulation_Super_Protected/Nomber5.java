package Stepik.Lesson22_Encapsulation_Super_Protected;

public class Nomber5 {
}
class Human3{                                           //родитель
    Human3(String name,String surname){
        this.name = name;
        this.surname=surname;
    }
    String name;
    String surname;
}

class Student3 extends Human3{
    int course;
    Student3(String name,String surname,int course){
        super(name,surname);      //вводим параметры род конструктора
        this.course = course;
        System.out.println(name+" "+surname+" "+course);


    }


    public static void main(String[] args) {
        System.out.print("Privet student:");
        Student3 s =new Student3("Sergey","Ivanov",2);
        //при создании обьекта чаилд класса через параметры находими его конструктор через его конструктор обращаемся к конструктору родителя(он не дефолтный тк мы написали свой)затем конструктор роидтель обращается к своему супер классу Object. после чего в обратном порядке выполняются команды(написанные в конструкторе)

    }
}

