package Stepik.Lesson22_Encapsulation_Super_Protected.p1;
import Stepik.Lesson22_Encapsulation_Super_Protected.*;
class Student extends Human {
    public static void main(String[] args) {
        Student s = new Student();
        System.out.println(s.name);                 //protected наследуется виден только в сабклассе
        s.work();

    }
}



