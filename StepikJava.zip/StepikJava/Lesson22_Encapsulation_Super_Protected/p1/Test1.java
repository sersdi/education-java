package Stepik.Lesson22_Encapsulation_Super_Protected.p1;
import Stepik.Lesson22_Encapsulation_Super_Protected.Chelovek;
public class Test1 {
    public static void main(String[] args) {
        Chelovek c = new Chelovek("male");
        c.setName(new StringBuilder("Kolya"));
        c.setVosrast(24);
        c.setVes(74);

    }
}
