package Stepik.Lesson22_Encapsulation_Super_Protected;

class A{}

class B{}


// 3 признака ООП
//  Инскапсуляция(сокрытие данных)
//-Характеризуется private переменными и public методами get and set которые нередко проверяют какие либо условия
//-Если return type метода get это mutable(изменяемый) тип данных то лучше возвращать его копию

// Inheritance(наследование)
//-

//Polymorphism(полиморфизм)