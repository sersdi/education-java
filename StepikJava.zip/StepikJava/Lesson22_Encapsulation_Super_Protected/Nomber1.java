package Stepik.Lesson22_Encapsulation_Super_Protected;

public class Nomber1 {
    public static void main(String[] args) {
        int i =2;
        String s = new String[]{"A","B","C"}[i];   //выводим второй элемент массива
        System.out.println(s);

    }
}

