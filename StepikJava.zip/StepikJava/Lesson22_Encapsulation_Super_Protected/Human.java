package Stepik.Lesson22_Encapsulation_Super_Protected;
public class Human {
    protected String name="Kolya";                    //Можем применить инкапсуляцию чтобы вызвать если private
    protected static int salary=150;                //private не наследуется виден только в классе  protected наследуется виден только в сабклассе
    protected void work(){
        System.out.println("rabotat");}
    protected static void rest(){
        System.out.println("otdixat");}
}

class Student extends Human{
    public static void main(String[] args) {
        Student s = new Student();
        System.out.println(s.name);
        s.work();
        Student.rest();

    }

}
