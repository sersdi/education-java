package Stepik.Lesson22_Encapsulation_Super_Protected.HomeWork;

public class Student {
    private StringBuilder name;
    private int course;
    private int grade;
    public StringBuilder getName(){
        StringBuilder sb = new StringBuilder(name);
        return sb;
    }
    public void setName(StringBuilder n){
        if(n.length()>=3){
            name = n;
        }
    }
    public int getCourse(){
        return course;
    }
    public void setCourse(int c){
        if(c>=1&&c<=4){
            course = c;
        }
    }
    public int getGrade(){
        return grade;
    }
    public void setGrade(int g){
        if(g>1&g<=10){
            grade = g;
        }
    }
    public void showInfo() {
        System.out.println(getName()+" "+getCourse()+" "+getGrade());
    }
}
class TestStudent extends Student{
    public static void main(String[] args) {
        Student s = new Student();
        s.setName(new StringBuilder("Sergey"));
        s.setCourse(2);
        s.setGrade(8);

        s.showInfo();

    }
}





