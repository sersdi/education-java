package Stepik.Lesson22_Encapsulation_Super_Protected.HomeWork;

public class Nomber2 {
}
class Animal{
    Animal(){
        System.out.println("I am animal");
    }
    public int eyes;
    public void eat(){
        System.out.println("Animal eats");
    }
    public void drink(){
        System.out.println("Animal drinks");
    }
}
class Pet extends Animal{
    Pet(){
        System.out.println("I am pet");
        eyes = 2;
    }
    String name;
    public int tail = 1;
    public int paw = 4;
    public void run(){
        System.out.println("Pet runs");
    }
    public void petJump(){
        System.out.println("Pet jumps");
    }
}
class Dog extends Pet{
    Dog(String name){
        System.out.println("I am dog and my name is: "+name);
    }
    public void play(){
        System.out.println("Dog plays");
    }
}
class Cat extends Pet{
    Cat(String name){
        System.out.println("I am cat and my name is: "+name);
    }
    public void sleep() {
        System.out.println("Cat sleeps");
    }
}
class Test{
    public static void main(String[] args) {
        Dog dog = new Dog("Sharik");
        System.out.println("Kol-vo lap:"+dog.paw);
        System.out.println();
        Cat cat = new Cat("Loki");
        cat.sleep();


    }
}
