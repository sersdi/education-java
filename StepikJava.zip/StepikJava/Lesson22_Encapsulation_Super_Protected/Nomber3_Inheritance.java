package Stepik.Lesson22_Encapsulation_Super_Protected;
// наследование

public class Nomber3_Inheritance {
    void uvelichZp(Employee e){       //Extensibility(растяжимость)метод в данном контексте
        e.salary = e.salary+100;
    }
    public static void main(String[] args) {
        Doctor doc = new Doctor();
        System.out.println(doc.name = "Sanya");
        System.out.println(doc.age = 15);
        doc.eat();
        doc.sleep();
        doc.lechit();
        doc.specializacia="xirurg";

    }
}
class Employee{
    double salary;
    String name;
    int age;
    int experiance;
    void eat(){System.out.println("Kushat");}
    void sleep(){System.out.println("Spat");}
}

class Doctor extends Employee{
    String specializacia;
    void lechit(){
        System.out.println("Lechit");}
}
class Teacher extends Employee{
    int kids;
    void uchit(){System.out.println("Uchit");}
}
class Driver extends Employee{
    String machina;
    void vodit(){System.out.println("Vodit");}
    }
class Xirurg extends Doctor{
    String scalpel;
    void operacia(){}
}
class Dantist extends Doctor{}







