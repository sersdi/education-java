package Stepik.Package_1;

import Stepik.Package.Employee;

public class TretiyClass {
    public static void main(String[] args) {
        Employee e1 = new Employee("kolya");
        System.out.println(e1.surname);

        e1.getsurname();
        e1.getid();




    }
}
