package Stepik.Lesson16_STRING;

public class Test3 {
    public static void main(String[] args) {
        int a=5;
        int b=6;
        String s ="ok";
        System.out.println(""+a+b+s);  // что бы а и б не складывались если хотим что бы сложились можем их взять в ()

        String s1 = "hello";
        //String s2= a+6; будет ошибка string(s2) + int(5)
        //System.out.println(s2);

    }
}
