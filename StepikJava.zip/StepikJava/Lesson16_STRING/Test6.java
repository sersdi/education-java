package Stepik.Lesson16_STRING;

public class Test6 {
    public static void main(String[] args) {
        String s = "PRIVET";
        //.toLowerCase метод уменьшает буквы
        String s2 = s.toLowerCase();
        System.out.println(s2);
        //.toUpperCase
        String s3 = s2.toUpperCase();
        System.out.println(s3);
        //.contains  метод указывает содержит ли какие либо символы(стринг)
        boolean b = s.contains(":2");
        System.out.println(b);
    }
}
