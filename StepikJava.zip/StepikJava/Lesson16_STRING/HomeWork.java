package Stepik.Lesson16_STRING;

public class HomeWork {
    public void Email(String e){
        int a=0;    //позиция  @
        int b=0;    // позиция .
        int c=0;    // позиция ;
        while (c<e.length()-1){      //-1тк индексы идут с 0
            a=e.indexOf('@', c);
            b=e.indexOf('.',c);
            c=e.indexOf(';', c+1); //+1 что бы не считала себя делаем на шаг больше
            System.out.println(e.substring(a+1,b));
        }

    }

    public static void main(String[] args) {
        HomeWork h1 = new HomeWork();
        h1.Email("ya@yahoo.com; on@mail.ru; ona@gmail.com;");

    }

}
