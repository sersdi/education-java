package Stepik.Lesson16_STRING;

public class Test7 {
    public static void main(String[] args) {
        String s1="hello world";
        String s2="uraaaaa!!!";
        //Набор методов(changing) через точку
        String s3 = s1.concat(s2).trim().replace("uraaaaa!!!","ураа").substring(6,10);    //hello worldураа
        System.out.println(s3);
        System.out.println(s1.substring(s1.indexOf('w')));   //world
        System.out.println(s1);  //s1 не меняется
    }
}
