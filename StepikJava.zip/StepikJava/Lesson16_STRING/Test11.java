package Stepik.Lesson16_STRING;

public class Test11 {
    public static void main(String[] args) {
        //isBlank    //возвращает boolean показывает если стринг состоит из пробелов табов и тд тогда true если нет false
        //isEmpty   // возвращает boolean тру когда стринг пустой(пробелы считаются)
        //strip, stripLeading, stripTrailing  // strip=trim только распознает больше символов убирает пробелы и тд

        String s1 = "privet";
        System.out.println(s1.isBlank());
        String s2 = "                         ";
        System.out.println(s2.isBlank());

        String s4 = "        privet     ";
        System.out.println(s4.strip());
        String s5="     privet  ";                  //stripLeading убирает пробелы только в начале
        System.out.println(s5.stripLeading());
        String s6 = "  privet   ";
        System.out.println(s6.stripTrailing());   //stripTrailing убирает пробелы в конце

        String s7 = s1.strip();    //если когда стрип ничего не делает он ссылается на один и тот же обьект s1=s7
        System.out.println(s7==s1); //True





    }
}
