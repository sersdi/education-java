package Stepik.Lesson16_STRING;
//equals and equalsIgnoreCase
public class Test9 {
    public static void main(String[] args) {
        String s1 = new String("ok");
        String s2 = new String("ok");
        System.out.println(s1==s2); // false тк сравниваем ссылки на обьекты
        //equals это == но мы можем его перезаписывать (в стринге он перезаписан)
        System.out.println(s1.equals(s2)); //True если значения в стринге равны

        String s10 = "af?";
        String s11 = "Af?";
        System.out.println(s10.equalsIgnoreCase(s11)); //  true тк метод не обращает вниманяи на различия


    }
}
