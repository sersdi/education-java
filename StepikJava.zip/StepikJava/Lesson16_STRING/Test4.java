package Stepik.Lesson16_STRING;

public class Test4 {

}

class Employee{
    double salary;
    boolean isManager;

    Employee(double salary,boolean isManager){
        this.salary = salary;
        this.isManager = isManager;
    }
}

class EmployeeTestP{
    public static void main(String[] args) {
        Employee emp = new Employee(100.5, true);
        System.out.println("On manager? "+emp.isManager+" Ego zp:"+emp.salary);       // чтобы сложить разные типы данных добавляем стринг перед конкатанацией(+)
    }
}
