package Stepik.Lesson16_STRING;

public class Test10 {
    public static void main(String[] args) {
        String x = "privet";
        String y = " privet".trim();  //если производит какие то действия метод трим то создаётся новый обьект
        System.out.println(x==y);   // из-за этого ссылки разные становятся поэтому false
    }                               // если исп equals то будет тру тк он перезаписан в стринге 
}
