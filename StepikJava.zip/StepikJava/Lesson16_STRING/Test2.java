package Stepik.Lesson16_STRING;
//методы стринг
public class Test2 {
    public static void main(String[] args) {
        String s1 = new String("privet");
        //.substring
        String s10 = s1.substring(3);     // метод присваивает переменной кусочек стринга начиная с нужного индекса в массиве стринг
        System.out.println(s10);
        System.out.println(s1);     // метод вызванный на стринге никогда не меняет его самого(тк он не изменяем)

        String s11 = s1.substring(2, 4);   // присваивает по указанным индексам начало и конец (конец не входит в кусочек стринга)
        System.out.println(s11);

        //.trim
        String s12 = s1.trim();                     // метод который выводит такой же стринг как и s1(начальный стринг) метод убирает пробелы в стринге по бокам но внутри не трогает
        System.out.println(s12);

        //.substring
        String s13 = s1.substring(0,6);                 // если указать индекс превышаюший длину стринга на 1 индекст то выводится полный стринг
        System.out.println(s13);

        //.replace                                          метод который меняет символы(тип данных чар) на другие возвращает тип данных стринг
        String s14 = s1.replace('p','z');               // метод который меняет символы(тип данных чар) на другие возвращает тип данных стринг
        System.out.println(s14);
        String s15 = s1.replace("pri","pk");;               // меняет стринг а не чар выводит также стринг
        System.out.println(s15);
        String s2 = "poka";
        String s3 = s2.replace('k', 'k'); //если используем char то ссылаются на один и тотже обьект если стринг тогда обьект будет новый
        System.out.println(s2==s3);
        //.concat складываем стринги
        String s5 = "privet";
        String s6 = "drug";
        System.out.println(s5.concat(s6));   //складываем стринги  либо s5+s6






    }
}
