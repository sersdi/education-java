package Stepik.Lesson16_STRING;
// Методы String
public class Test1{
    public static void main(String[] args) {
        String s1 = new String("privet");
//      int a = s1.length();
        System.out.println(s1.length());
        //.charAt
        char c1 = s1.charAt(3);    //выводит символы(char) по индексу
        System.out.println(c1);
        //.indexOf
        int i1 = s1.indexOf('t');   // выводит индекс по символy(char)
        System.out.println(i1);
        int i2 = s1.indexOf("vet");  // выводит индекс по строке (String(несколько сиволов в массиве окуда они начинаются))
        System.out.println(i2);
        int i3 = s1.indexOf("Z");  // если нет существующего в массиве String  то индекс всегда -1(не существует)
        System.out.println(i3);
        int i4 = s1.indexOf("i", 1);// если есть повторы символов то указываем откуда начинать считать
        System.out.println(i4);
        //.startsWith
        boolean b1 = s1.startsWith("pri", 0);  // метод который показывает с какого стринга начинается весь стринг и с какого именно индекса Выводит булиан
        System.out.println(b1);
        //.endsWith
        boolean b2 = s1.endsWith("et");  //  метод показывает на что заканчивается стринг
        System.out.println(b2);









    }
}
