package Stepik.Lesson16_STRING;

public class Car {
        String colour;
        String engine;

        Car(String colour, String engine){
            this.colour=colour;
            this.engine=engine;
        }

        final static int a=15;

        public Car abc(String cvet){    // метод с типом данных CAR
            Car c10= new Car(cvet,"v4");   // создает обьект и принимает один параметр цвет
            return c10;
        }

        public static void main(String[] args) {
            Car c = new Car("red", "v6");
            Car c2 = c.abc("black");      // создаём обьект и присваевываем ему метод обьекта с abc
            System.out.println(c.colour);
            System.out.println(c2.colour +","+ c2.engine);


        }




}
