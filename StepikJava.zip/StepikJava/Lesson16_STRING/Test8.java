package Stepik.Lesson16_STRING;
//программа выводит из предложения только заглавные буквы
public class Test8 {
    public static void main(String[] args) {
        String s1 = "Ты ночь моей надежды сделай днём, "+"Пусть рок мой ходит с поднятым челом, "+"Пусть, как Лейли, мой стих блеснёт лучом, "+"И, как Меджнун, он сердце жжёт огнём";
        String s2 = s1.toUpperCase();
        char c1;
        char c2;
        for(int i=0;i<s1.length();i++){
            c1=s1.charAt(i);
            c2=s2.charAt(i);
            if(c1!=',' && c1!=' ' && c1!='.' && c1!='!' && c1==c2){
                System.out.println();
                System.out.print(c1);
                continue;
            }
            //System.out.print(c1);//выводятся все символы
        }

    }


}
