package Stepik.Lesson16_STRING;

public class Test5 {
    public static void main(String[] args) {
        String s = null;   // s не ссылается на  обьект
        s+="ok";
        System.out.println(s);
    }
}
