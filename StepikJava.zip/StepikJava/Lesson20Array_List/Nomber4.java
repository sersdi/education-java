package Stepik.Lesson20Array_List;
import java.util.ArrayList;
public class Nomber4 {
    public static void main(String[] args) {
        ArrayList<StringBuilder>list=new ArrayList<>();
        StringBuilder sb1= new StringBuilder("salam");
        list.add(sb1);                                                 // стрингбилдере метод equals не перезаписан
        list.add(new StringBuilder("privet"));
        list.add(new StringBuilder("poka"));
        list.add(new StringBuilder("hello"));
        for(StringBuilder sb:list){
            System.out.print(sb+" ");
        }
        System.out.println();
        System.out.println(list.indexOf(new StringBuilder("poka")));       //indexOf ищет обьект по индексу(если не находит то выводит -1) не находит тк в стрингбилдере не перезаписан метод equals и он сравнивает ссылки на обьекты  а они будут всегда разные
        System.out.println(list.contains(sb1));  // стрингбилдере метод equals не перезаписан и он ищёт по ссылке на обьект
        System.out.println(list.toString());    //list.toString() показывает как выглядит наша коллекция  в виде стринге
                                                    //можем пользоваться ту стрингом что бы не писать циклы на вывод
    }
}
