package Stepik.Lesson20Array_List;
import java.util.ArrayList;
public class Nomber5 {
    public static void main(String[] args) {
        ArrayList<String>list=new ArrayList<>();            // создаём ArrayList  тип данных стринг
        list.add(new String("poka"));
        list.add(new String("privet"));
        list.add(new String("poka"));
        list.add(new String("hello"));
        list.add(new String("salam"));
        for(String s:list){                                         //выводим обьекты из коллекции
            System.out.print(s+" ");
        }
        System.out.println();                                           //помещаем курсор на новую строку
        System.out.println(list.indexOf(new String("poka")));       //indexOf ищет индекс обьекта(если не находит то выводит -1)
        System.out.println(list.lastIndexOf("poka"));               //lastIndexOf последний элемент похожий на обьект в массиве
        System.out.println(list.size());                            //list.size() показывет размер коллекции
        System.out.println(list.isEmpty());                            //is.Empty() говорит пустая коллекция или нет
        System.out.println(list.contains(new String("hello")));  //list.contains говорит есть ли такой обьект в коллекции
    }



}

