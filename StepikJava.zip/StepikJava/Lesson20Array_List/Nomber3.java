package Stepik.Lesson20Array_List;
import java.util.ArrayList;
public class Nomber3 {
    public static void main(String[] args) {
        ArrayList<StringBuilder>list=new ArrayList<>();
        StringBuilder sb1 = new StringBuilder("hello");
        StringBuilder sb2 = new StringBuilder("ok");
        StringBuilder sb3 = new StringBuilder("privet");
        list.add(sb1);
        list.add(sb2);
        list.add(sb3);
        for(int i =0;i<list.size();i++){   //традишнл луп переменной выводит значения по индексу и доб символ к обьекту(меняет его)
            list.get(i).append("!!!");
        }
        for(StringBuilder sb:list){      //форич луп выводим массив
            System.out.print(sb+" ");
        }
        System.out.println();

        list.remove(0);         //list.remove удаляет обьект по индексу(либо по названию обьекта)
        for(StringBuilder sb:list){
            System.out.print(sb+" ");
        }

    }


}
