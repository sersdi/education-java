package Stepik.Lesson20Array_List;

import java.util.HashMap;
import java.util.Map;

public class Nomber11_Map_collection {
    public static void main(String[] args) {    //коллекция map создаётся ключ/значени.Реализует 2 класса HashMap TreeMap
        Map<Integer,String>map= new HashMap();
        map.put(172,"Sergey Ivanov");                //метод put добавляет значения
        map.put(173,"Petya Ivanov");
        map.put(174,"Roverto Carlos");
        map.put(187,"Eqapr Sloave");
        map.put(173,"Aesa VArna");                      //дубликаты не поддерживаются они перезаписываются
        map.put(186,"Sergey Ivanov");                   //с одинаковым стрингом записываются если ключи разные
        map.remove(173);                    //метод remove() удаляет элемент в параметре указываем key
        System.out.println(map);
    }
}
