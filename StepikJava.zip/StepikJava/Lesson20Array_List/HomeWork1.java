package Stepik.Lesson20Array_List;
import java.util.*;
public class HomeWork1 {
    public static ArrayList<String>abc(String...s){
        ArrayList<String>list= new ArrayList<>();
        for(String s1:s){
            if(!list.contains(s1)){          //если коллекция не содержит такого обьекта то мы его прибавляем 
                list.add(s1);

            }

        }
        Collections.sort(list);
        System.out.println(list);
        return list;
    }

    public static void main(String[] args) {
        abc("a","c","b","a","c","c");



    }
}
