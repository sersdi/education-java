package Stepik.Lesson20Array_List;
import java.util.Arrays;

public class Nomber8_someArray_Methotds {
    public static void main(String[] args) {
        //compare       метод сравнивает массивы с одинаковым типом данных(Возвращает 0 массивы равны,<0 если первый меньше второго,>0 если первый больше)
        int[]array1 = {1,2,3,4,5};
        int[]array2={1,2,3,5};

        char[]array3={'п','р','и','в','е','т'};
        char[]array4={'п','р','и','в','и','в','к','а'} ;
        char[]array5=null;
        char[]array6=null;


        System.out.print(Arrays.compare(array1, array2));    //ar1<ar2 тк у  него число после префикса меньше
        System.out.println();
        System.out.print(Arrays.compare(array3, array4));  //ar3<ar4 тк идёт раньше в словаре
        System.out.println();
        System.out.print(Arrays.compare(array5, array6));
        System.out.println();
        //mismatch       находит индекс первого расхождения массива (если массивы одинаковые то -1)
        System.out.print(Arrays.mismatch(array1, array2));
        System.out.println();
        System.out.print(Arrays.mismatch(array3, array4));
        System.out.println();
        System.out.print(Arrays.mismatch(array5, array6));      // будет ошибка




    }
}
