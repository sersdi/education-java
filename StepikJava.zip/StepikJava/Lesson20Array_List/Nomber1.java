package Stepik.Lesson20Array_List;
import Stepik.Package.A;

import java.util.ArrayList;
import java.util.List;
import java.util.StringJoiner;

public class Nomber1 {                               //в основе arraylist(коллекции) лежит массив тип данных object(самый главный класс в джава(самый первый))
    public static void main(String[] args) {            //Лист работает только с ссылочными типами данных 
        ArrayList list = new ArrayList();
        list.add("privet");
        Car c = new Car();
        list.add(c);
        Student s = new Student();
        list.add(s);
        list.add(new StringBuilder("ok"));

        ArrayList<String>list2=new ArrayList<>(30);
        ArrayList<String>list5=new ArrayList<>(list2);
            System.out.println(list2==list5);  //false
        list2.add("poka");
        List<StringBuilder>list3 = new ArrayList<>();
        list3.add(new StringBuilder("ok"));
    }
}
class Car{}
class Student{}
