package Stepik.Lesson20Array_List;
import java.util.ArrayList;
import java.util.List;
public class Nomber9_methods_ArrayList_List {
    public static void main(String[] args) {
        ArrayList<String>al1 = new ArrayList<>();
        al1.add("one");
        al1.add("two");
        al1.add("three");;
        al1.add("four");
        ArrayList<String>al2=new ArrayList<>();
        al2.add("one");
        al2.add("two");
        al2.add("ten");
        al2.add("eleven");
//        al1.removeAll(al2);                          //метод remove.all в параметре указываем коллекцию по которой будем удалять елементы из нужной коллекции
//        al1.retainAll(al2);                          //retain обьекты которые совпадают у коллекций сохраняются остальные удаляются
        System.out.println(al1);

        boolean result = al1.containsAll(al2);    //contains.ALL возвращает булиан сравнивает эллементы коллекций если все равны тру если нет false
        System.out.println("result = "+result);

        List<String>subList=al1.subList(0,2);               //метод subList создает отрывок листа из ArrayList в аутпуте тип данных List а не ArrayList(последний индекс в параметре не входит)
        subList.add("twenty");                     //если в саблист добавлять элементы то и в ArrayList он будет добавлен согласно индексу из sublista
        System.out.println(subList);
        System.out.println(al1);

        Object[]array=al1.toArray();                                    //метод toArray() из ArrayList делает Array(массив) типа object
        for(Object o:array){                      //что бы вывести на экран массив используем форичлуп либо стандартный
            System.out.print(o+" ");
        }
        System.out.println();

        String[]array2=al1.toArray(new String[4]);//если хотим при создании масива тип данных не object а другой(как в исходном ArrayListe) то указываем тип данных и кол-во символов
        for(String s:array2){
            System.out.print(s+" ");
        }
        System.out.println();
                                            //методы List.of() List.copyOf() создают коллекции в аутпуте лист(коллекция) неизменяемая.Не могут содержать элементы null
        List<String>list = List.of("odin","dva","tri");
        System.out.print("list="+list);
        System.out.println();
        List<String>list2=List.copyOf(al1);
        System.out.print("list2="+list2);



    }
}
