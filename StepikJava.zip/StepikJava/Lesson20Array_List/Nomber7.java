package Stepik.Lesson20Array_List;

import java.util.*;
import java.util.Collections;//класс коллекций для сортировки
import java.util.Iterator;      //класс итератор для пробега по коллекциям
import java.util.ListIterator;

public class Nomber7 {
    public static void main(String[] args) {
        String s1 = "A";
        String s2 = "B";
        String s3 = "C";
        String s4 = "D";

        ArrayList<String>list=new ArrayList<>();
        list.add(s2);
        list.add(s1);
        list.add(s4);
        list.add(s3);
        //с помощью итератора можно удалить элемент array листа в отличии от фор ич
        Iterator<String> it = list.listIterator();       //с помощью обьекта it можем пробижаться по коллекции листа
        while(it.hasNext()){                            //пока есть следущий элемент заходим в цикл и выводито на экран элемент колелкции
            System.out.println(it.next());              //it.next() метод выводит обьект из листа
            //it.remove();                                    //it.remove() метод удаляет обьект

        }




//        ArrayList<String>list2=list;
//
//        ArrayList<String>list3=new ArrayList<>();
//        list3.add(s2);
//        list3.add(s1);
//        list3.add(s4);
//        list3.add(s3);;
//
//        System.out.println(list2.equals(list));     //метод equals для коллекций тру из условия
//        System.out.println(list3.equals(list));    //тру тк обьекты в коллекции из начальной коллекции
//        System.out.println(list);
//
//        Collections.sort(list);             //Collections.sort сортирует коллекции
//        System.out.println(list);





    }
}
