package Stepik.Lesson20Array_List;
import java.util.ArrayList;


public class Nomber2 {
    public static void main(String[] args) {
        ArrayList<String>list = new ArrayList<>();
        list.add("Hello");
        list.add("Privet");
        list.add(0,"ok");       //list.add добавляет элемент к коллекции(может добавлять на места по индексу
        list.add("poka");
        for(String s:list){                     //цикл фор ич
            System.out.print(s+" ");
        }
        System.out.println();

        //list.remove(new String("Hello"));                 //удаляет обьект по индексу либо обьекту
        //list.set(replace)                                // заменяет обьект по индексу

        ArrayList<String>list2= new ArrayList<>();
        list2.add("Petrov");
        list2.add("Sidorov");
        list.addAll(0,list2);                    //list.addAll() добавляет коллекцию с одинаковым типом данных

        for(int i = 0;i<list.size();i++){              //традишнл луп
            System.out.print(list.get(i)+" ");}             //get выводит обьект по индексу



    }
}