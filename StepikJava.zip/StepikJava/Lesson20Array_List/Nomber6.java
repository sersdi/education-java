package Stepik.Lesson20Array_List;
import java.util.*;
public class Nomber6 {
    public static void main(String[] args) {
        ArrayList<StringBuilder>list = new ArrayList<>();
        StringBuilder sb1 = new StringBuilder("privet");
        StringBuilder sb2 = new StringBuilder("poka");
        StringBuilder sb3 = new StringBuilder("bye");
        list.add(sb1);
        list.add(sb2);
        list.add(sb3);
        StringBuilder[]array1 ={sb2,sb3,sb3,sb3};               //все изменения в начальном массиве отобразятся в листе(в отличии от  toArray() clone()
        List<StringBuilder>list8 = Arrays.asList(array1);       //Arrays.asList метод который создаёт лист на основе массива
        System.out.println(list8);

        for(int i = 0;i<array1.length;i++){
            array1[i]=new StringBuilder("123");
        }
        System.out.println(list8);  //после изменнеия элементов в массиве изменился лист




        //        StringBuilder[]array1 = list.toArray(new StringBuilder[10]);    //list.toArray метод который создаёт массив на основе коллекции
        //        for(StringBuilder sb:array1){
            //            System.out.print(sb+" ");
        //        }

        //        System.out.print(list.toString());                                      //выводим коллекциию на экран
        //        System.out.println();
        //
        //        ArrayList<StringBuilder>list2 = (ArrayList<StringBuilder>)list.clone();     //list.clone метод клонирует коллекцию на выводе получается тип данных обжект а не arrayList
        //        System.out.println(list2);
        //        System.out.println(list.get(0)==list2.get(0));                      //клонированная коллекция ссылается на одни и теже обьекты изначального варианта
        //
        //        list.get(0).append("!!!");                      //если добавлять к начальному варианту копии то и добавляется к копии тк ссылки на эти же обьекты к которым что то добавляем
        //        list.set(1,new StringBuilder("123"));   //если менять начальный вариант то копия не меняется тк ссылки становятся разные после  изменения обьектов
        //
        //        System.out.println(list);
        //        System.out.println(list2);

    }
}
