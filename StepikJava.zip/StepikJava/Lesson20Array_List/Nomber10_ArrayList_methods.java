package Stepik.Lesson20Array_List;

import java.util.ArrayList;

public class Nomber10_ArrayList_methods {
    public static void main(String[] args) {
        ArrayList<String>al1 = new ArrayList<>();
//        al1.add(new Nomber10_ArrayList_methods); будет ошибка тк дженеретик указали стринг в листе
        al1.add("one");
        al1.add("two");
        al1.add("three");
        al1.add("four");
        for(Object o:al1){
            System.out.println("Nomber "+o+" and length "+((String)o).length());

        }

    }
}
