package Stepik.Lesson30_Лямбда2_ТипДанных_Inference;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

public class Nomber3_MethodsForLyambda {
    public static void main(String[] args) {
        List<String>list =List.of("privet","poka","kak dela?","vse normalno!");
        String str="asdasd";                    //если не менять значение переменных то их можно использовать в лямбда выражении
        for(String s:list){
            Predicate<String>p= z->{
                System.out.println(str.length());
                return z.length()>0;};
        }


//        for(String s:list){
//            System.out.println(s);
//        }

//      метод .forEach -прописываем в нём что нужно сделать для каждого элемента
//        list.forEach(s -> System.out.println(s));
//        ArrayList<Integer>al = new ArrayList<>();
//        al.add(2);
//        al.add(1);
//        al.add(3);
//        al.add(4);
//        al.add(5);
//        al.add(6);
//        al.add(7);

//      метод .removeIf -удаляет обьект из списка если выполняется условие
//        al.removeIf(element->element%3==0);

//        Predicate<Integer>p= element -> element%3==0; 2 вариант
//        al.removeIf(p);

//        System.out.println(al);
//
////      метод .sort -сортирует.В параметре указывается лямбда выражение 2 переменные в ретерн тайпе булиан метод сравнения .compareTo если 1 больше второго то 1 если нет то 0 и меняет их местами
//        al.sort((x,y)->-x.compareTo(y));    //сортируем в обратном порядке
//        System.out.println(al);


    }

}
