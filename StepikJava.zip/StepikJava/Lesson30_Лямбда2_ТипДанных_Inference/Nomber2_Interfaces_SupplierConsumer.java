package Stepik.Lesson30_Лямбда2_ТипДанных_Inference;
import java.util.function.Supplier;         //чтобы нажать на них ctrl
import java.util.function.Consumer;
import java.util.ArrayList;

//      functional Interfaces
// interface I{
// void abc();
// default void def1(){}
// default void def2(){}
// static  void def3(){}
// }

//      Consumer&Supplier(потребитель и поставщик)

public class Nomber2_Interfaces_SupplierConsumer {
}
class Car{
    String model;
    String colour;
    double engine;
    Car(String model,String colour,double engine){                                           //констуктор
        this.model=model;
        this.colour=colour;
        this.engine = engine;
    }
    public String toString(){                                                            //метод в основном классе
        return "Our Car is "+model+", colour is "+colour+" and engine = "+engine;
    }

}
class TestCar{
    public static ArrayList<Car> createThreeCars(Supplier<Car>carSupplier){         //метод создания машин в параметре указываем интерфейс поставщика с типом кар
        ArrayList<Car>al=new ArrayList<>();
        for(int i=0;i<3;i++){
            al.add(carSupplier.get());                                              //доб в лист 3 обьекта Обращаемся к поставщику и к его методу гет который возвращает обьект кар
        }
        return al;
    }

    public static void changeCar(Car car,Consumer<Car>consumer){                  //метод принимает 2 параметра обьект типа кар и потребитель интерфейс
        consumer.accept(car);                                                      //вызываем метод потребителя  вставляем переменную типа кар тк у потребителя параметр есть типа Сar
    }

    public static void main(String[] args) {
        ArrayList<Car> ourCars = createThreeCars(() -> new Car("Nissan", "red", 1.6));       //пишем () тк в методе гет нет параметров у поставщика  //метод createThreeCars создаст три машины и засунет их в arrayList
        System.out.println("Our cars:" + ourCars);

        changeCar(ourCars.get(0), car -> {                                                //обращаемся к методу changeCar  во 2 параметре у консюмера делаем такой ретерн
            car.colour = "blue";                                                           //меняем нулевой элемент списка
            car.engine = 8.0;
            System.out.println("Updated car: " + car);                                    //выводим измененный обьект
        });

//        Consumer<Car>consumer=car->{                           //второй вариант выведения потребителя:Обращаемся к интерфейсу consumer тип данных Car, указываем параметр car и пишем ретерн тайп в этом интерфейсе который нам нужен
//            car.colour = "blue";
//            car.engine = 8.0;
//            System.out.println("Updated car: " + car);
//        };
//        consumer.accept(ourCars.get(0));                         //обращаемся к потребителю и выводим его метод accept,который мы перезаписали для нулевого элемента в списке, в параметре указываем обьект типа кар

        System.out.println("Our cars:"+ourCars);                                    //выводим список машин
    }



}


