package Stepik.Lesson30_Лямбда2_ТипДанных_Inference;

import java.util.ArrayList;

//                       var-переменная типа данных инференсе(inference-делать вывод)- Local variable type inference
//-Относится только к локальным переменным
//-вар нельзя писать вне методов
//-вар нельзя писать внутри параметров
//
//
public class Nomber1_Var_СокращениеКода {
//    var v =10;  вар нельзя писать вне методов


    public static void main(String[] args) {
        var tit = new Nomber1_Var_СокращениеКода();         //что бы не дублировать код и не писать тип данных в начале (используем переменную var)
        var i = 10;
        var w = 1.4f;
        var array = new String[]{"a","b"};
        var result = abc();
        Object obj1 = "privet";
        var obj2=obj1;
        ArrayList<String>al=new ArrayList<>();
        for(var s:al){
            System.out.println(s);
        }
    }
    static double abc(){
        return 3.14;
    }
}



