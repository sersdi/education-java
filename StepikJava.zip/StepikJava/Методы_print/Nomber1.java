package Stepik.Методы_print;

public class Nomber1 {
    public static void main (String[] args) {          // метод main -главный метод
        System.out.println("                  РУБАИ");  //println курсор на новую строку
        System.out.println("Много лет размышлял я над жизнью земной.");
        System.out.println("Непонятного нет для меня под луной.");
        System.out.println("Мне известно, что мне ничего не известно!");
        System.out.println("Вот последняя правда, открытая мной.");
        System.out.println("                             О.Хайям");

    }
}
