package Stepik.Lesson9_peremennie_Predeli_Vidimosti;

public class Car {
    String colour;                      // instance и object переменные   Это одно и тоже(переменные принадлежат обьекту)
    String engine;                      // instance и object
    static int count;                   // static verible принадлежит всему классу(общая для всех обьектов)
    final int XYZ = 3;                  // вся константа с больших сиволов

    public Car(String colour, String engine ){
        int x = 5;                      // у локальных перемнных нет начального значения
        int y = x+10;
        count++;
        this.colour = colour;                       //области видимости обжект переменных и параметров конструктора персекаются что бы использовать такое же название пишем перед обжект пременными this(означает чтопеременные обьекта присваиваются параметрам конструктора)
        this.engine = engine;                       //This нельзя использовать в статичных методах и переменных
    }

    public void showColour(){                                       // что бы использовать методы нужно создать обьект класса This означает что параметры обьекта(созданного) как либо меняются
        System.out.println("Цвет машины: " + colour);

    }

    public void changeColour(String colour3){                    // область видимости параметра может быть больше видимости  локальной переменной
        int cena = 5000;                                //примитивный тип данных(int)             //Локальные переменные это переменные созданные внтури метода   область видимости с момента содания до конца метода
        colour = colour3;                               //reference тип данных(String)
        cena +=1000;
        System.out.println("Цвет машины изменился: " + colour);
    }

    public static void main(String[] args) {
        Car c = new Car("red", "v6");
        c.showColour();
        c.changeColour("blue");



    }

}
