package Stepik.Lesson9_peremennie_Predeli_Vidimosti;

public class HomeWork1{

    public static void abc(){
        String s1 = new String("ABC");      // обьекты живы только в методе
        String s2 = new String("DEF");
    }

    public static void main(String[] args) {
        HomeWork1 s3 = new HomeWork1();
        System.out.println(s3);
        abc();
        abc();
        String s4 = new String("LKF");
        System.out.println(s4);
        abc();                          // остались живы s3 s4



    }
}
