package Stepik.Lesson9_peremennie_Predeli_Vidimosti;

public class Student {
    int a = 10;
    int b = this.a;
    public static int c =5;
    public int z = this.c;
    static int f = c;
}
class StudentTest{
    public static void main(String[] args) {
        Student st1 = new Student();           // обьекты
        Student st2 = new Student();
        String a  = "Privet";               // обьект класса стринг
        Student st3;                 // ссылка на обьект не явл обьектом
        st1 = null;     //убрали адресс(обьекта нет)


    }

}
