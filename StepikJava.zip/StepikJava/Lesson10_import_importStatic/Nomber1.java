package Stepik.Lesson10_import_importStatic;
import Stepik.Lesson9_peremennie_Predeli_Vidimosti.*;    // импортитруются все классы пакета
import Stepik.Class_and_objects.*;

public class Nomber1 {
    public static void main(String[] args) {
        Stepik.Lesson9_peremennie_Predeli_Vidimosti.Car c1 = new Stepik.Lesson9_peremennie_Predeli_Vidimosti.Car("red", "v8");
        Stepik.Class_and_objects.Car c2 = new Stepik.Class_and_objects.Car("blue", "v8");
        Stepik.Class_and_objects.Student st1 = new Stepik.Class_and_objects.Student(2, "Serega", "Ivanov", 2);

    }

}