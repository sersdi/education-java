package Stepik.Lesson10_import_importStatic;
import Stepik.Class_and_objects.Student;// обычный импорт
import static Stepik.Class_and_objects.Student.*;  // статичынй импорт импортирует все статичные елементы либо несколько

public class Nomber3 {
    public static void main(String[] args) {
        Student st1 = new Student(2,"Sergey", "Ivanov",3);
        System.out.println(a);              /*sdsd ккомент начались
        sdsdsd
        sdsd
        sd
                            комменты закоенчились */
        /** java doc HTML
         *
         */
    }

}
