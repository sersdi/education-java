package Stepik.Lesson10_import_importStatic;
import Stepik.Lesson9_peremennie_Predeli_Vidimosti.*;

public class Nomber2 {

    public static void main(String[] args) {
        String st1 = new String("Hello");
        Student st2 = new Student();
        System.out.println(st2.z);
        System.out.println(Student.c); // если используем статичные переменные из другого класса пишем название класса в котором находится статичная переменная



    }
}

class b{
    Student st3 = new Student();


}