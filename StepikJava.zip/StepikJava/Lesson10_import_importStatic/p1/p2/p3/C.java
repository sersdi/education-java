package Stepik.Lesson10_import_importStatic.p1.p2.p3;

public class C {
    public boolean c1 = true;
}
