package Stepik.Lesson10_import_importStatic.p1.p2;

public class B {
    public static int b1 =15;
    public static String name ="Vanya";
    public static int b2 = 20;
    public static int b3 = 3;


}
