package Stepik.Lesson10_import_importStatic.p1;

public class A {
    public int a1 = 20;

}
