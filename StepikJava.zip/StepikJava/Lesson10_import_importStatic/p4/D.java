package Stepik.Lesson10_import_importStatic.p4;
import static Stepik.Lesson10_import_importStatic.p1.p2.B.*;  //импортируем все статик элементы из класса B
import Stepik.Lesson10_import_importStatic.p1.*;
import Stepik.Lesson10_import_importStatic.p1.p2.p3.*;
import Stepik.Lesson10_import_importStatic.p4.p5.E;


public class D {
    public static void main(String[] args) {
        A a = new A();
        System.out.println(a.a1);

        System.out.println(name);  // статик елементы классаB не вызываются через обьекты тк они статик и не нуждаются в создании обьектов
        System.out.println(b1);
        System.out.println(b2);
        System.out.println(b3);

        C c = new C();
        System.out.println(c.c1);
        E e = new E();
        System.out.println(e.e1);
        System.out.println(e.e2);






    }
}
