package Stepik.Lesson10_import_importStatic.p4.p5;

public class E {
    public String e1 = "java";
    public int e2 = 3;
}
