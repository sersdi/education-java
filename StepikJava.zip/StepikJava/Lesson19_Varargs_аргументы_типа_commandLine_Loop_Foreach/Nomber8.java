package Stepik.Lesson19_Varargs_аргументы_типа_commandLine_Loop_Foreach;

public class Nomber8 {
    public static void main(String[] args) {
        int[]array=new int [4];
        for(int b:array){
            b=10;
        }
        for(int a:array){
            System.out.println(a+" ");
        }
    }
}
