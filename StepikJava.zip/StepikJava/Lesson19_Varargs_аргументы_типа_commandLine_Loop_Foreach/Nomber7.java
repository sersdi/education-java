package Stepik.Lesson19_Varargs_аргументы_типа_commandLine_Loop_Foreach;

public class Nomber7 {
    public static void main(String[] args) {
        StringBuilder sb1 = new StringBuilder("privet");
        StringBuilder sb2 = new StringBuilder("hello");
        StringBuilder sb3 = new StringBuilder("hi");
        StringBuilder sb4=new StringBuilder("Salam");
        StringBuilder[]array={sb1,sb2,sb3,sb4};
        // для традишинл(тип данных массивов)
//        for(int i=0;i<array.length;i++){  //меняем все элементы массива
//            array[i]=3;
//        }
//        for(int i=0;i<array.length;i++){  //Выводим массив на экран
//            System.out.print(array[i]+" ");
//        }

        //foreach он не может менять обьекты в массиве(С помощью методов может менять само значение обьектов)
        for(StringBuilder s:array){
            s.append("java");
        }
        for(int i=0;i<array.length;i++){  //Выводим массив на экран
            System.out.print(array[i]+" ");
        }

    }


}
