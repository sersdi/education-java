package Stepik.Lesson19_Varargs_аргументы_типа_commandLine_Loop_Foreach;

public class Nomber4 {
    public static void main(String[] args) {
        int[]array={0,6,4,1};
        int summa =0;
        for(int a:array){
            summa+=a;
        }
        System.out.println(summa);

    }
}
