package Stepik.Lesson19_Varargs_аргументы_типа_commandLine_Loop_Foreach;

public class Nomber5 {
    public static void main(String[] args) {
        String[]students={"Ivanov","Petrov","Sidorov"};
        String[]exams={"mat analiz","philosofia"};
        for(String s1:students){
            for(String s2:exams){
                System.out.println(s1+" "+s2);
            }
        }

    }
}
