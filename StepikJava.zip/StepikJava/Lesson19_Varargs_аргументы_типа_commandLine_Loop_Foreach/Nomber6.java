package Stepik.Lesson19_Varargs_аргументы_типа_commandLine_Loop_Foreach;

public class Nomber6 {
    public static void main(String[] args) {
        int[][]array={{3,7,8},{4,5},{9,4,4,6,8,3}};
        //изначальный способ
//        for(int i=0;i< array.length;i++){
//            for(int j=0;j<array[i].length;j++){  //что бы работать с двумерными массивами во втором лупе нужно указать что цикл идёт до длины одномерных массивов в двумерном массиве
//                System.out.print(array[i][j]+" ");
//            }
//        }
        //исп foreach
        for(int[]array2:array){   //указываем что элементами массива array явл элементы array2
            for(int a:array2){
                System.out.print(a+" ");
            }

        }





    }
}
