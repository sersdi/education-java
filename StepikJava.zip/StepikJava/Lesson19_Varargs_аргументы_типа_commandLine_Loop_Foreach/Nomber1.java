package Stepik.Lesson19_Varargs_аргументы_типа_commandLine_Loop_Foreach;
//создам файл с такой программой в папке и запускаем через консоль виндовс
// когда вызвана консоль пишем set path=вствляем путь jdk bin
//находим путь к файлу с программой пишем cd (название папки)                     //запускается javaс (название документа).java       //временно создавать файлы в users
public class Nomber1  {
    public static void main(String[] args) {
        System.out.println("Nulevoy element: "+args[0]);
        System.out.println("Dlina massiva: "+args.length);

    }
}   //в компиляторе здесь будет ошибка тк у нас массив (аргументов) не существует а мы хотим вывести по индексу первое
//java (Навзвание документа) Hello 14 true
//это будут аргументы 3 штуки
 //тип данных стринг  тоже самое что и массив
