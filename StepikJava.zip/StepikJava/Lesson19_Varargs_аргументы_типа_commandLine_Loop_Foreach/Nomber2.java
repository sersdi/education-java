package Stepik.Lesson19_Varargs_аргументы_типа_commandLine_Loop_Foreach;
//var args (аргументы кол-во которых могут быть совершенно разные)
public class Nomber2 {
    static void summa(String s, int ... a) {          //вызывем метод с разными по кол-ву параметрами получается тоже самое что и массив     В листе параметров только один varargs(а массив хоть где и сколько угодно) b и он самый последний
        int summa=0;
        for(int i=0;i< a.length;i++){               //узнаём сумму
            summa+=a[i];//к переменной прибавлям числа из массива с индексами от 0 до длины массива
        }
        System.out.println(summa);
        System.out.println(s);
    }
    public void abc(int[]...array){}// можем исп в параметре массивы хоть какие


    public static void main(String ... args) {
        summa("ok",new int[]{1,5,6});   //var args предствляется в компиляторе как массив


    }
}
