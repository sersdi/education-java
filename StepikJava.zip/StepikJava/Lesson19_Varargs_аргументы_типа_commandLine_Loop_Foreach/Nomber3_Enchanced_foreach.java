package Stepik.Lesson19_Varargs_аргументы_типа_commandLine_Loop_Foreach;

public class Nomber3_Enchanced_foreach {
    //for each улучшенный цикл фор для работы с массивами и коллекциями
    public static void main(String[] args) {
        int[]array={0,6,4,1};
        for(int a:array){                               //переменная а по очереди принимает все значения (по индексу в массиве) чисел
            System.out.print(a+" ");
        }
        System.out.println();

    }
}
