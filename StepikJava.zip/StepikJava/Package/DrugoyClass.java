package Stepik.Package;

public class DrugoyClass {
    public static void main(String[] args) {
        Employee e2 = new Employee("kolya");
        System.out.println(e2.surname);
        e2.getsurname();

        Employee e3 = new Employee(583);
        System.out.println(e3.id);
        e3.getid();


    }
}
