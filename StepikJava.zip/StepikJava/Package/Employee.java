package Stepik.Package;

public class Employee {
    private double salary;
    public String surname;
    int id;
//  методы
    public void dvoynaya(){
        System.out.println("Novaya z/p "+salary*2);
    }

    public void getsalary(){

        System.out.println("Salary: " + salary);
    }
    public void getsurname(){

        System.out.println("Surname: " + surname);
    }
    public void getid(){

        System.out.println("Id:" + id);
    }

    // конструкторы
    private Employee(double salary1){
        salary = salary1;
    }
    public Employee(String surname1){
        surname = surname1;
    }
    Employee(int id1){
        id = id1;

    }
    // метод main
    public static void main(String[] args) {
        Employee e1 = new Employee(15.2);
        System.out.println(e1.salary);
        e1.dvoynaya();

        Employee e2 = new Employee("Kolya");
        System.out.println(e2.surname);

        Employee e3 = new Employee(2);
        System.out.println(e3.id);
    }
}





