package Stepik.Lesson12_if_ifElse_Equals_Ternary;

public class Car {
    int engine;
    int doorCount;

    Car(int engine, int doorCount) {
        this.engine = engine;
        this.doorCount = doorCount;
    }

}

class CarTest{
    public static void main(String[] args) {
        Car c1 = new Car(3,4);
        Car c2 = new Car(2,5);

        if (c1.engine>c2.engine) {                    //если первый if  с значение тру тогда последний else не выполнится никогда
        if (c1.doorCount>c2.doorCount){             // внутренний метод if
            System.out.println("Мощность мотора и кол-во дверей у первой машины больше"); }
        else {                                       // внутренний else
            System.out.println("Мощность мотора меньше, но кол-во дверей у первой машины больше");} }
        else {                                // тк первый if тру то он не выполняется
           System.out.println("Мощшность у первой машины больше");}


    }
}
