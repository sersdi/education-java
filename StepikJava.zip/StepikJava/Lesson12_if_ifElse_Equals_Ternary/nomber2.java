package Stepik.Lesson12_if_ifElse_Equals_Ternary;

public class nomber2 {

    void maximum(int i1, int i2, int i3){
        if(i1>i2 && i1>i3){            //&&-и     ||-или
            int a =2;                                  // а - локальные переменные
            System.out.println("Maximum: " + i1);}
        else if (i2>i1 && i2>i3){
            System.out.println("Maximum: "+ i2);}
        else {
            System.out.println("Maximum: " + i3);}


    }

    public static void main(String[] args) {
        nomber2 t = new nomber2();
        t.maximum(1,5,7);
    }


}





