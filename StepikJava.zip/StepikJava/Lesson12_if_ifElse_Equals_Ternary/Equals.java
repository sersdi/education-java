package Stepik.Lesson12_if_ifElse_Equals_Ternary;

public class Equals {        // method equals применяется при референс тип данных если хотим сравнить параметры обьектов

    static void abc(String str1, String str2){       //String reference
        if(str1.equals(str2)){
            System.out.println("s1 and s2 ravni");}
        else{
            System.out.println("s1 and s2 ne ravni");}
    }

    public static void main(String[] args){
        String s1 = new String("abc");
        String s2 = new String("ac");
        Equals n1 = new Equals();
        n1.abc(s1,s2);
        System.out.println(s1.equals(s2));



    }
}
