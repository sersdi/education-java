package Stepik.Lesson12_if_ifElse_Equals_Ternary;

public class Ternary {             // оператор Turnary состоит из 3 операнд
                                       //(boolean expression)?(if true):(if false)
    void abc (){
        String str;
        int a = -6;
        if(a>1){
            str = "Privet";
            System.out.println(str);}
        else if(a==6){
            str = "Poka";
            System.out.println(str);}
        else{
            str = "wewe";
            System.out.println(str);}

    }

    public static void main(String[] args) {
        Ternary n1 = new Ternary();
        n1.abc();

        int a = 10;
        int b =20;
        int maximum = (a>b)?a:b;         //оператор turnary
        System.out.println(maximum);



    }

}
