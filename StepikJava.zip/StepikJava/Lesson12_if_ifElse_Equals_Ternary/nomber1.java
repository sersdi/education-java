package Stepik.Lesson12_if_ifElse_Equals_Ternary;

public class nomber1 {
    public static void main(String[] args) {
        int salary = 190;
        boolean b = true;

        if (salary < 50) {                      // если не писать {} в циклах, то к циклам будет отнтситься только первая строка кода, остальное будет выводиться на экран в не зваичсимости от условий выполнения цикла
            System.out.println("зп низкая");
        } else if (salary < 150 ) {
            System.out.println("зп средняя");
        } else if (salary <= 200 && b==(false || true)) {          // условие подходит, дальше программа не работает
            System.out.println("Зп высокая");
        } else if (b == true){                // условие не выполняется даже если оно походит тк до этого условие выполнилось
            System.out.println("булиан");

        }


    }

}
