package Stepik.Lesson13_Switch_Case;

public class Nomber1 {


}

class Student {
    int grade;

    Student(int grade) {
        this.grade = grade;
    }

    public static void main(String[] args) {
        Student st1 = new Student(5);
//       if(st1.grade==2){
//           System.out.println("Student dvoichnik");
//       }
//       else if (st1.grade==3) {
//            System.out.println("Student troichnik");
//        }
//       else if(st1.grade==4){
//            System.out.println("Student horoshist");
//        }
//       else if (st1.grade==5){
//            System.out.println("Student otlichnik");
//        }
//       else{
//            System.out.println("Ocenka neverna");
//        }

        switch (st1.grade) {                      // в свитч записываем с чем работает   //case  наши предполагаемые ответы на результат  //brake-выходим из тела свича // default- когда не срабатывает не один из кейсов
            case 2:
                System.out.println("Student dvoichnik");
                break;                                  //если не писать brake то все команды будут выполняться
            case 3:
                System.out.println("Student troichnik");
                break;
            case 4:
                System.out.println("Student horoshist");
                break;
            case 5:
                System.out.println("Student otlichnik");
                break;
            default:                 // можем не писать дефолт(можем написать где угодно не обяз в конце)
                System.out.println("Ocenka neverna");
                // можем не писать в конце break;
        }


    }

}
