package Stepik.Lesson13_Switch_Case;

public class nomber2 {                          //Конструкция свич
    public static void main(String[] args) {
        int denNedeli = 1;
        final int a = 2;             // в свиче можем использовать только константы
        final int b = 5;

        switch (denNedeli){     // switch(expression) может быть типом данных byte short int String char
            case 1:            // кейсы пропустятся и выполнится то ткоторый найдет первым по списку и  ввыполнит его до брейка

            case 2:

            case a*b:

            case 4:

            case 5:
                System.out.println("Rabota do 18:00");
                break;
            case 6:
                System.out.println("Rabota do 16:00");
                break;
            case 7:
                System.out.println("Ne rabochiy den");
                break;
            default:
                System.out.println("Takogo dnya net");
        }




    }
}
