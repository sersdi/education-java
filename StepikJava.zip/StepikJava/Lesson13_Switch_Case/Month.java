package Stepik.Lesson13_Switch_Case;

public class Month{
    public static void daycol(int a){
        switch (a){
            case 2:
                System.out.println("Количество дней в месяце 28");
                break;
            case 4:
            case 6:
            case 9:
            case 11:
                System.out.println("Количество дней в месяце 30");
                break;
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                System.out.println("Количество дней в месяце 31");
                break;
            default:
                System.out.println("Месяца с таким порядковым номером не существует");
        }
    }
    public static void main(String[] args) {
        daycol(5);
        daycol(2);
        daycol(-1);

    }

}



