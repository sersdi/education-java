package Stepik.Модификаторы_Final_Static;

public class Student_2 {
    String name;
    int course;
    static int count;                                               //static означает что переменная класса, а не обьектов (может изменять её любой обьект класса) (запоминает кол-во)
    int a;

    public Student_2(String name2, int course2) {
        count++;
        name = name2;
        course = course2;
        System.out.println("Student: " + name + " #" + count + " Sozdan");
    }

    public static void showCount(){
        System.out.println("Vsego stydentov " + count);
    }

    public void showInfo(){
        System.out.println("Welcome to the StudentClass");
    }

    void abc(){      // внутри не статичного метода можно использовать статичные переменные
        a++;                // нонстатик
        count++;           // статик


    }

    static void abcd(){        //   что бы их использовать нужно создавать обьекты и через обьекты увелечивать переменные нон статик(так как они не принадлежат классу)
        count++;
        Student_2 st3 = new Student_2("Kolya", 2);
        st3.a++;                 // в static metodax невозможно использовать не статик переменные

    }

    public static void main(String[] args) {                            // метод main статичный так как является точкой запуска программы
        Student_2 st1 = new Student_2("Vanya", 1);
        st1.abc();     // что бы запускать не статик методы нужн осоздавать обьект и через него обращаться к методам
        Student_2 st2 = new Student_2("Sasha", 3);
        st2.abc();
        abcd();                                            // статик методы можно вызывать без обьектов в мейне


    }
}


