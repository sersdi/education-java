package Stepik.Модификаторы_Final_Static;

public class HomeWork1 {

    static int ymnogenie(int a, int b, int c){
        return a*b*c;
    }

    static void ostatok(int a, int b){
        System.out.println(a/b);
        System.out.println(a%b);
    }

}
class HomeWork1_Test {
    public static void main(String[] args) {
        System.out.println(HomeWork1.ymnogenie(2, 3, 4));
        HomeWork1.ostatok(4, 3);
        System.out.println(HomeWork1.ymnogenie(8,10,6));
        HomeWork1.ostatok(8, 10);


    }
}
