package Stepik.Модификаторы_Final_Static;           // когда создаём константы(final) присваевывем им значения
public class Nomber1 {                              // access modifier и non access могут меняться местами смысл не меняется
    public final int a;                    // Final (non access modifier), Public(access modifier) файнал означает что значение переменной не меняется(константа)

    Nomber1(){
        a = 10;
    }

    Nomber1(boolean b){
        a = 20;

    }

    public void abc(final short s){
        final byte b;
        b = 10;
        System.out.println(s+b);
    }

    public static void main(String[] args){
        Nomber1 t = new Nomber1();
        System.out.println(t.a);

    }
}
