package Stepik.Модификаторы_Final_Static;

public class Car {
    String name = "Red";
    String engine = "V12";

}
class Human{                                                      // В классе Human создаем обьект класса Car
    String name = "Ivan";
    final Car c = new Car();
    public static void main(String[] args) {                        // В методе main создаём обьект класса Human затем обращаемся к нему а потом к обьекту класса Car и меняем параметр двигателя
        Human h1 = new Human();
        //h1.c = new Car();            // тк как обьект final не можем пользоваться его адресом(создавать другие обьексы его адресом)
        h1.c.engine = "V8";            // двигатель менят можем тк не меняет адрес
        System.out.println(h1.c.engine);

    }

}
