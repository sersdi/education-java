package Stepik.Модификаторы_Final_Static;

public class HomeWork2 {

    public final static double Pi = 3.14;


    public double ploshad(double radius) {
        double p1 = Pi * radius * radius;
        return p1;
    }


    public static double dlina(double radius2) {
         double d1 = 2*Pi*radius2;
         return d1;
    }

    public void showinfo(double radius3){
        System.out.println(radius3);
        System.out.println(ploshad(radius3));
        System.out.println(dlina(radius3));

    }
}

class HomeWork2_Test{
    public static void main(String[] args) {
        HomeWork2 h2 = new HomeWork2();
        h2.ploshad(5);
        HomeWork2.dlina(7.6);
        h2.showinfo(15);
    }

}
