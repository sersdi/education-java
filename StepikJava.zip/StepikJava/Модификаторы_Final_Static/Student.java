package Stepik.Модификаторы_Final_Static;

public class Student {
    String name;
    int course;
    static int count;      //static означает что переменная класса, а не обьектов (может изменять её любой обьект класса) (запоминает кол-во)

    public Student(String name2, int course2) {
        count++;
        name = name2;
        course = course2;
        System.out.println("Student: " + name + " #" + count + " Sozdan");
    }

    public static void showCount(){
        System.out.println("Vsego stydentov " + count);
    }

    public static void main(String[] args) {
        Student st1 = new Student("Serega", 1);
        Student st2 = new Student("Artem", 1);
        Student st3 = new Student("Vasya", 1);
        System.out.println(st1.name);
        System.out.println(Student.count);             // Если хотим узнать сколько всего количества созданных нами обьектов то обращаемся к классу потом к static переменной
        Student.showCount();            // обращаемся к классу
        st2.showCount();                // обращаемся к обьекту
    }
}





