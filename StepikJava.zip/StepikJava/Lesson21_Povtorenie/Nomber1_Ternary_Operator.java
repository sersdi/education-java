package Stepik.Lesson21_Povtorenie;

public class Nomber1_Ternary_Operator {
    public static void main(String[] args) {
//        int a =3;
//        System.out.println((a<4)?10:"net");
        int a =5;
        int b =5;
        int c = (a<6)?a++:b++;                          //(вопрос)? Выполни если true:Выплни если false
        System.out.println("a="+a+" "+"b="+b);
    }
}
