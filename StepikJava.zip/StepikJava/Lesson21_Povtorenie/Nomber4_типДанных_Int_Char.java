package Stepik.Lesson21_Povtorenie;

import javax.swing.plaf.basic.BasicInternalFrameTitlePane;

public class Nomber4_типДанных_Int_Char {
    void abc(int i){
        System.out.println(i);
    }

    public static void main(String[] args) {
        Nomber4_типДанных_Int_Char n1 = new Nomber4_типДанных_Int_Char();
        char c = 'a';    //в основе char int тк отвечает за порядковый номер символов
        n1.abc(c);
        System.out.println('b'+10);

    }



}

