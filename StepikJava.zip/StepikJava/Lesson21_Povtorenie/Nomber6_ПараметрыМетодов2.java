package Stepik.Lesson21_Povtorenie;

public class Nomber6_ПараметрыМетодов2 {
    int a =5;
    int t,h=5,k;





//    public void abc(int a, int b){             //сначала джава выбирает что ближе
//        System.out.println("privet");
//
//    }


    public void abc(double a, double b){          //потом дабл
        int c;
        c=10;
        System.out.println("poka");
    }

    public static void main(String[] args) {
        Nomber6_ПараметрыМетодов2 n = new Nomber6_ПараметрыМетодов2();
        n.abc(1,2);


    }


}
