package Stepik.Lesson21_Povtorenie;

public class Nomber5 {
    int abc(){             //метод
        return 5;
    }

    int abc2(int i){   //ещёи метод
        if(i>10){
            return 5;
        }
        else{
            return 10;
        }
    }

    void abc3(int i2){
        if(i2>3){
            return;
        }
        System.out.println("Hello");
        return;
    }

    public static void main(String[] args) {
        int a = new Nomber5().abc();
        new Nomber5().abc();

    }
}
