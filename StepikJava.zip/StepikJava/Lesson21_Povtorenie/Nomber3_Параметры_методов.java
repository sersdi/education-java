package Stepik.Lesson21_Povtorenie;

public class Nomber3_Параметры_методов {
    public void abc (String s){             //примитивные параметры
        System.out.println(s);
    }
    public void abc(boolean b){
        System.out.println(b);
    }
    public StringBuilder abc(StringBuilder sb){    //ссылочные параметры
        System.out.println(sb);
        return new StringBuilder("privet");

    }


}
