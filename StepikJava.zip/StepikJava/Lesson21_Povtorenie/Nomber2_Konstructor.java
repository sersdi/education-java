package Stepik.Lesson21_Povtorenie;

public class Nomber2_Konstructor {
    Nomber2_Konstructor(){                            //конструктор называется всегда как класс
        System.out.println("Это конструктор");
    }
    void Nomber2_Konstructor(){                      //метод может называеться как класс
        System.out.println("eto metod");        //тк указали ретерн тайп это метод
    }

    Nomber2_Konstructor Nomber2_Konstructor;   //переменная с типом данных как у класса и называется так( так делать плохо)


}

class A {
    public static void main(String[] args) {
        Nomber2_Konstructor n1=new Nomber2_Konstructor();

    }
}
