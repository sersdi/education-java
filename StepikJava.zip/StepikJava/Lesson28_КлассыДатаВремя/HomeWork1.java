package Stepik.Lesson28_КлассыДатаВремя;
import java.time.*;
import java.time.format.*;
public class HomeWork1 {
                                                                    //2016,января-01 !! 09:00
                                                                            //09:00, 03/фев/16
    static void Smena(LocalDateTime nachalo, LocalDateTime konec, Period p, Duration d){
        DateTimeFormatter f1 = DateTimeFormatter.ofPattern("yyyy,MMMM-dd !! hh:mm");
        DateTimeFormatter f2 = DateTimeFormatter.ofPattern("hh:mm, dd/MM/yy");
        LocalDateTime data = nachalo;

        while(data.isBefore(konec)){
            System.out.println("Работаем с: "+data.format(f1));
            data=data.plus(p);
            System.out.println("Работаем до: "+data.format(f1));
            System.out.println("Отдыхаем с: "+data.format(f2));
            data=data.plus(d);
            System.out.println("Отдыхаем до: "+data.format(f2));
            System.out.println();
        }
    }
    public static void main(String[] args) {
        LocalDateTime ldt1 = LocalDateTime.of(2016,Month.JANUARY,1,9,0);
        LocalDateTime ldt2 = LocalDateTime.of(2016,Month.APRIL,3,9,0);
        Period p = Period.ofDays(1);
        Duration d = Duration.ofHours(1);
        Smena(ldt1,ldt2,p,d);
    }
}
