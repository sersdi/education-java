package Stepik.Lesson28_КлассыДатаВремя;
import java.time.*;
import java.time.format.*;
//                              Данный класс находится java.time.format
//                              С помощью метода format можно изменять вывод нашей даты или времени на экран
//                              С помощью метода ofPattern можно создать свой формат
//                              Метод parse переводит String в обьект классов LocalDate LocalTime LocalDateTime

public class Nomber7_classDateTimeFormatter {
    public static void main(String[] args) {
        LocalDate ld = LocalDate.of(2014,Month.SEPTEMBER,23);
        LocalDateTime ldt = LocalDateTime.of(2014, Month.SEPTEMBER,1,16,40,4,5);
        LocalTime lt = LocalTime.of(10,30,45,23333);

        //свой формат
        DateTimeFormatter f = DateTimeFormatter.ofPattern("MM dd yyyy"); // если не знаем дефолтный формат то создаём свой шаблон
        //метод parse
        LocalDate date1 = LocalDate.parse("01 02 2015", f);   //при помощи формата f приводит к стандарному
        System.out.println(date1);
//        LocalDate date2 = LocalDate.parse("2015-01-02");    //если знаем дефолтный формат localDate то можем не использовать формат
//        System.out.println(date2);


        //создаём свой формат .ofPattern
        //DateTimeFormatter f = DateTimeFormatter.ofPattern("d MMMM , yyyy, hh:mm");  //для ldt
        //"y"=2014 "yy"=14  "yyyy"=2014
        //"M"=3    "MM"=03   "MMM"=sep   "MMMM"=september
        //"w"=1    "ww" =01
        //"d"=1    "dd"=01
        //"h"=3    "hh"=03
        //"m"=2    "mm"=02
        //"s"=0    "ss"=03
        //"n"=5555 "nnnn"=05555
        //
        //
        //
        //System.out.println(ldt);
        //System.out.println(ldt.format(f));



//        DateTimeFormatter d1 = DateTimeFormatter.ISO_LOCAL_DATE;            //ISO_LOCAL_DATE формат с помощью которого выведем класс времени localDAte
//        System.out.println(ld);                                             //исходный вариант
//        System.out.println(ld.format(d1));                                  //форматированный  не увидим разницы между ними//        DateTimeFormatter d2 = DateTimeFormatter.ISO_LOCAL_TIME;          //ISO_LOCAL_TIME формат для локал time

//        System.out.println(lt);
//        System.out.println(lt.format(DateTimeFormatter.ISO_LOCAL_TIME));      // другая вариация без отдельного создания переменной d2

//        DateTimeFormatter d3 = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
//        System.out.println(ldt);
//        System.out.println(ldt.format(d3));                                    //ldt можно форматировать как ISO_LOCAL_TIME так и ISO_LOCAL_DATE

//        DateTimeFormatter d4 = DateTimeFormatter.ISO_WEEK_DATE;
//        System.out.println(ld);                                                //в аутпуте 2014-09-23
//        System.out.println(ld.format(d4));                                     // 2014-W39-2 39-неделя в году 2- день недели(вторник)


//      для локалдэйт - DateTimeFormatter mediumFormat = DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM);   //ofLocalizedDate можно применить к LocalDateTime
//      для локалтайм - DateTimeFormatter LongFormat= DateTimeFormatter.ofLocalizedTime(FormatStyle.LONG);        //ofLocalizedTime  можно применить к LocalDateTime
//        System.out.println(ld);
//        System.out.println(ld.format(MediumFormat));

//        System.out.println(lt);
//        System.out.println(lt.format(LongFormat));

        DateTimeFormatter shortFormat = DateTimeFormatter.ofLocalizedDateTime(FormatStyle.SHORT);        //ofLocalizedDateTime только для LocalDateTime
        System.out.println(ldt);                                                                         //в аутпуте 2014-09-01T16:40:04.000000005
        System.out.println(ldt.format(shortFormat));                                                     //01.09.2014, 16:40
//      System.out.println(shortFormat.format(ldt));  можно писать так




    }

}
