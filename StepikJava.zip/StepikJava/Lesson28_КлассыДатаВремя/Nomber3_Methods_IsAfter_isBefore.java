package Stepik.Lesson28_КлассыДатаВремя;
import java.time.*;
public class Nomber3_Methods_IsAfter_isBefore {
    public static void main(String[] args) {
        //Методы .isAfter .isBefore  возвращает булиан  сравнивает обьекты только одинаковых классов!

        LocalDate ld1=LocalDate.of(2020,5,23);
        LocalDate ld2=LocalDate.of(2020,Month.JUNE,12);
        System.out.println(ld1.isAfter(ld2));                           //Этот день лд1 был после этого дня(лд2)(тру)
        System.out.println(ld1.isBefore(ld2));                          //(false)

        LocalTime lt1 = LocalTime.of(15,30);
        LocalTime lt2 = LocalTime.of(03,5,10,5543);
        System.out.println(lt1.isAfter(lt2));                        //false
        System.out.println(lt1.isBefore(lt2));                               //true

        LocalDateTime ldt1 = LocalDateTime.of(2020,Month.MAY,10,15,26);
        LocalDateTime ldt2 = LocalDateTime.of(2020,Month.MAY,10,15,26,3);
        System.out.println(ldt1.isAfter(ldt2));                      //фолс
        System.out.println(ldt1.isBefore(ldt2));                         //тру



    }
}
