package Stepik.Lesson28_КлассыДатаВремя;
import java.time.*;

//Класс Duration имеет конструктор private. Методы of возвращают обьект типа Duration

//public static Duration ofDays(long кол-во дней)
//public static Duration ofHours(long кол-во часов)
//public static Duration ofMinutes(long кол-во минут)
//public static Duration ofSeconds(long кол-во секунд)
//public static Duration ofMillis(long кол-во миллисекунд) милисекунда это 1/1000 секунды
//public static Duration ofNanos(long кол-во наносекунд) надо 1/1000000 секунды

//  Методы plus minus могут быть использованы для прибавления и отнимания обьекта класса Duration к обьектам класса LocalTime LocalDateTime
//  При попытке использования методов plus minus для сложения и вычитания обьекта класса Duration к LocalDate будет выброшена ошибка

//  При создании обьекта класса Duration не работает метод chaining метода of
//  При попытке method chaining последний метод of имеет значение


public class Nomber5_Duration {
    public static void main(String[] args) {
        LocalDateTime ldt = LocalDateTime.of(2014,Month.SEPTEMBER,1,16,40);
        LocalTime lt = LocalTime.of(10,30);
        //Period p = Period.ofMonth(3).ofDays(10);      //тк статик методы значение не меняется будет выводится последний метод
        //Period p = Period.ofDays(10)
        Period p = Period.ofMonths(3);
        Duration d = Duration.ofMinutes(10);    //дуратион используется для классов LocalTime LocalDateTime
        System.out.println(ldt.plus(d).plus(p));


    }

}
