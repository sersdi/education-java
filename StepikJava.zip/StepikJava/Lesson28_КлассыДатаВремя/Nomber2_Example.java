package Stepik.Lesson28_КлассыДатаВремя;

public class Nomber2_Example {
    public static void main(String[] args) {
        Car c =Car.createCar();             //при создании обьекта обращаемся к методу который создаёт обьект
    }

}
class Car{
    private Car(){}         //тк конструктор private не можем напрямую создавать обьекты класса Кар
    static Car createCar(){     //для этого используем метод
        return new Car();
    }

}
