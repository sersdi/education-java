package Stepik.Lesson28_КлассыДатаВремя;

import java.time.*;  //                                      Класс Period
                            //Класс period имеет конструктор с access modifier Private.Методы of возвращают обьект типа Period
                            //public static Period ofDays(int кол-во дней)
                            //public static Period ofWeeks(int кол-во недель)
                            //public static Period ofMonths(int кол-во месяцев)
                            //public static Period ofYears(int кол-во лет)
                            //public static Period of(int кол-во лет, кол-во месяцев, кол-во дней ) Period of сочетает три метода



public class Nomber4_Period {
    static void smenadejurnogo(LocalDate nachalo,LocalDate konec,Period p){     //вводим параметр Периода p
        LocalDate data=nachalo;                                             //вводим новую переменную что бы считать  и приравняли её к началу
        while(data.isBefore(konec)){                                            //уст временные рамки
            System.out.println("nastupila data "+data+". Pora menyat dejurnogo");
//            data=data.plusMonths(1);                              //каждый месяц меняем дежурного
            data=data.plus(p);                                      //упращаем код благодаря периоду
        }
    }
    public static void main(String[] args) {
        LocalDate nachalo = LocalDate.of(2023,Month.MAY,12);
        LocalDate konec = LocalDate.of(2024,Month.MAY,23);
        Period p = Period.of(1,1,5);      // выбираем через сколько времени будет происходить действие
        smenadejurnogo(nachalo,konec,p);


    }
}
