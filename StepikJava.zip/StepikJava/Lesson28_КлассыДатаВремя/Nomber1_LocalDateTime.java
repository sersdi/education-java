package Stepik.Lesson28_КлассыДатаВремя;
import java.time.*;
public class Nomber1_LocalDateTime {             // У классов времени private конструктор Напрямую не сможем создавать обьекты этих классов
                    //Методы of:                 //Будем использовать Метод of которые будут создавать эти обьекты
    //public static LocalDate of(int int int)
    //public static LocalDate of(int Month int)

    //public static LocalTime of(int int)   час минута
    //public static LocalTime of(int int int) час минута секунда
    //public static LocalTime of(int int int int)  час минута секунда наносекунда

    //public static LocalDateTime of(совмещает все контсрукторы)

    //Методы LocalDate:
    //.plusDays()       доб дни
    //.minusDays()      отняли дни
    //.plusWeeks()      доб недели
    //.minusWeeks()     отнимает недели
    //.plusMonths()      доб месяц
    //.minusMonths()     минус месяц
    //.plusYears()   доб год
    //.minusYears()  минус год

    //Методы localTime:
    //.plusHours
    //.minusHours
    //.plusMinutes
    //.minusMinutes
    //.plusSeconds
    //.minusSeconds
    //.plusNanos
    //.minusNanos

    //Методы LocalDateTime охватывают методы(имеет все эти методы) LocalDate и LocalTime и в аутпуте возвращают LocalDateTime



    public static void main(String[] args) {
//        System.out.println(LocalDate.now());                      //год месяц день
//        System.out.println(LocalTime.now());                   //время
//        System.out.println(LocalDateTime.now());           //все вместе

        LocalDate ld1 =LocalDate.of(2014,Month.MAY,15);     //Month константа инумерэйшен
//        ld1.plusDays(5);
        LocalDate ld2 = ld1.plusDays(5);   //доб дни        //тк значения из 3 классов времени все Immutable они не менются что бы вывести измененное значение нужно присвоить переменным
        System.out.println(ld2);
        ld1 = ld1.plusWeeks(3);     //к 15 мая прибавим 3 недели получился июнь
        ld1 = ld1.minusMonths(2);
        ld1 = ld1.plusYears(2);
        System.out.println(ld1);

        LocalTime lt1 = LocalTime.of(15,30,45,242222222);
        System.out.println(lt1);
        lt1 = lt1.plusSeconds(2323);
        System.out.println(lt1);


        LocalDateTime ldt1 = LocalDateTime.of(2015,Month.MAY,25,12,21,54,113132);
        System.out.println(ldt1);
        LocalDateTime ldt2 = LocalDateTime.of(ld1,lt1);
        System.out.println(ldt2);

        ldt1 = ldt1.plusYears(3).minusMonths(2).plusMinutes(240000).minusSeconds(58);
        System.out.println(ldt1);

    }
}
