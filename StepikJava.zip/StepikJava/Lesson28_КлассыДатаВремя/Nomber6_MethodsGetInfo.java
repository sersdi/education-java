package Stepik.Lesson28_КлассыДатаВремя;
import java.time.*;
//                                                   Поулучение информации из класса LocalDate
//  getDayOfWeek() - DayOfWeek      (День недели)
//  getDayOfMonth() - int           (число)
//  getDayOfYear() - int            (день в году)
//  getMonth() - Month              (месяц)
//  getMonthValue() - int           (месяц числом)
//  getYear() - int                 (год)
//                                                  Получение информации из класса LocalTime
//  getNano()-int
//  getSecond()-int
//  getMinute()-int
//  getHour()-int
//                                                  Получение информации из класса LocalDateTime
// Данный класс включает в себя все методы из классов выше

public class Nomber6_MethodsGetInfo {
    public static void main(String[] args) {
        LocalDate ld = LocalDate.of(2014,Month.SEPTEMBER,23);
        LocalDateTime ldt = LocalDateTime.of(2014, Month.SEPTEMBER,1,16,40,4,5);
        LocalTime lt = LocalTime.of(10,30,45,23333);
        System.out.println(ldt.getYear());
        System.out.println(lt.getSecond());


        


    }
}
