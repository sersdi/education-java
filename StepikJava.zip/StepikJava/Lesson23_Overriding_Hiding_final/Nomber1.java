package Stepik.Lesson23_Overriding_Hiding_final;

public class Nomber1 {
    String abc(){
        return null;        //можем возвращать налл для любого типа данных тк null частный случай любого обьекта(его остутствие)
    }
    int abc2(){
        char c ='k';
        return c;
    }
}
