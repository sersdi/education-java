package Stepik.Lesson23_Overriding_Hiding_final;

public class A10 {
    String s1 = "privet";
    static double d1 = 3.14;
    int summa(int... i){
        int result = 0;
        for(int a:i){
            result+=a;
        }
        return result;
    }
    static void abc(){
        System.out.println("Static method");
    }
}
class B10 extends A10{
    //String s1 = super.s1 +", drug";                   //super обращаемся к классу родителю (переменная s1 hide)
    double d1 = super.d1;                               //с помощью переменной обращаемся к static переменной
    String s1 = super.s1;
    int summa(int... i) {
        int result = super.summa(i);                        //обращаемся к методу в родителе чтобы не переписывать метод
        System.out.println("Summa: "+result);
        super.abc();
        return result;
    }

    public static void main(String[] args) {                  //static не наследуются не hidden
        B10 b = new B10();
        System.out.println(b.s1);
        b.summa(15,23,42);
    }
}
