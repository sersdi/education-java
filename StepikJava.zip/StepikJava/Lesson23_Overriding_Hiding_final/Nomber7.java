package Stepik.Lesson23_Overriding_Hiding_final;

public class Nomber7 {
    public static void main(String[] args) {
        A c1 = new C();
        c1.abc(new B());  // компилятор смотрит на тип переменной с1 видит A поэтому вызывает метод A

    }
}
class A{
    void abc(A a){                      // метод который перезапишем
        System.out.println("A");
    }
}
class B extends A{
    void abc(A a){                      //метод abc перезаписан выводидтся он
        System.out.println("BBB");
    }
    void abc(B b1){
        System.out.println("B");
    }
}
class C extends B {
    void abc(B b2){
        System.out.println("C");
    }
}