package Stepik.Lesson23_Overriding_Hiding_final;

public class HomeWork1 {
    HomeWork1(){}
    public void abc(){
        System.out.println("HomeWork1");
    }
}
class Y extends HomeWork1{
    Y(){}
    public void abc() {
        System.out.println('Y');
    }

    public static void main(String[] args) {
        Y y = new Y();
        y.abc();
    }
}


