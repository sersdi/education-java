package Stepik.Lesson23_Overriding_Hiding_final;
public class Nomber3_Method_Overriding{
    public static void main(String[] args) {
        Employee2 e = new Teacher2();      // создаем обьект типа тичер 2
        e.eat();                    //вызываем переписанный метод

    }
}
class Eda{};                        //вводим доп классы
class Frukti extends Eda{}          //для референс типов данных в оверидинг можем использовать саб классы
class Employee2 {                               //класс работника
    double salary = 100;
    String name = "Kolya";
    int age;
    int experiance;

    Eda eat() {                                        //метод
        System.out.println("Kushaet rabotnik");
        Eda e = new Eda();
        return e;
    }
    void sleep() {                              //метод ничего не возвращает
        System.out.println("Spat");
    }
}
class Teacher2 extends Employee2 {                             //класс учителя
    Frukti eat() {                                               //оверидиниг метода еат        //Методы static,final,private не перезаписываются
        System.out.println("Kushaet uchitel");
        Frukti f = new Frukti();
        return f;
    }
    int kids;
    void uchit() {                            ////метод ничего не возвращает
        System.out.println("Uchit");}
}


