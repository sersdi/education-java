package Stepik.Lesson23_Overriding_Hiding_final;

public class HomeWork5 {
}
class X5{
    String s1 = "Privet";
}
class Y5 extends X5{
    boolean bool = false;
}
class Test{
    public static void main(String[] args) {
        X5 x = new Y5();
        System.out.println(x.s1);
       // System.out.println(x.bool);   тк тип данных x5 не видно bool в X5
    }
}


