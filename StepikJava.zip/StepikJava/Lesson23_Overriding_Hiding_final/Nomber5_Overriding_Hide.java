package Stepik.Lesson23_Overriding_Hiding_final;

public class Nomber5_Overriding_Hide {
    public static void main(String[] args) {
        Employee5 e = new Employee5();
        Teacher5 e1 = new Teacher5();
        Employee5 e2 = new Teacher5();
        //e.sleep();   //не вызывается тк sleep private
        e.eat();
        e1.eat();
        e2.eat();
        e.sleep();
        e1.sleep();
        e2.sleep();
    }
}
class Eda5{};                        //вводим доп классы
class Frukti5 extends Eda5{}
class Employee5 {                               //класс работника
    double salary = 100;
    String name = "Kolya";

    public Eda5 eat() {
        System.out.println("Kushaet rabotnik");
        Eda5 e = new Eda5();
        return e;
    }
    static void sleep() {                                 //метод static
        System.out.println("Spit rabotnik");            //этот метод не переписывается
    }
}

class Teacher5 extends Employee5 {
    public Eda5 eat() {                                               //оверидиниг метода еат        //Методы static,final,private не перезаписываются
        System.out.println("Kushaet uchitel");
        Frukti5 f = new Frukti5();
        return f;
    }
    int kids;
    void uchit() {
        System.out.println("Uchit");}

    static void sleep() {                               //метод Hiding этот метод закрыл слиип из  класса имплои
        System.out.println("Spit uchitel");             // final  не может быть хидиинг и перезаписан
    }

}
