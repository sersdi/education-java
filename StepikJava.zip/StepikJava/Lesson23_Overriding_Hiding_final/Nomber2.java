package Stepik.Lesson23_Overriding_Hiding_final;
public class Nomber2{
//    public Object abc(){        //метод с типом данных Object может вернуть любой тип данных тк Object прародитель всех классов
//        return new Doctor();}

    public static void main(String[] args) {
//        Doctor d = new Doctor();
//        Driver dr = new Driver();
//        Teacher t = new Teacher();
//        Employee e = new Employee();
//        Xirurg x = new Xirurg();

        Employee emp1 = new Doctor();       //переменные с одним референс типом данных могут ссылаться на другие переменные с другим типом данных(по правилам) 1Переменная одного типа может сслыаться на обьект тоже типа
        System.out.println(emp1.salary);
        System.out.println(emp1.name);
        System.out.println(emp1.age);
        System.out.println(emp1.experiance);
        emp1.eat();
        emp1.sleep();
//*       emp1.lechit();    ошибка компилятора тк компилятор смотрит на тип данных employee а в нем нет такого метода
        Employee emp2 = new Teacher();                                                                                      //2Переменная employee может ссылаться на обьект сабкласса
        Employee emp3 = new Driver();

        Doctor d2 = new Xirurg();           //супер класс наследует сабклассы(полиморфизм) но нельзя через доктора обратиться к переменным в хирурге тк тип данных разный компилятор видит
        System.out.println(d2.experiance);
        d2.eat();
        d2.sleep();
        d2.lechit();

        Employee emp4 = new Xirurg();
        emp4.sleep();
        emp4.eat();
    }
}
class Employee {
    double salary = 100;
    String name = "Kolya";
    int age;
    int experiance;
    void eat() {System.out.println("Kushat");}
    void sleep() {
        System.out.println("Spat");
    }
}

    class Doctor extends Employee {
        String specializacia;
        void lechit() {
            System.out.println("Lechit");
        }
    }
    class Xirurg extends Doctor{
    String skalpel;
    void operacia(){}
    }

    class Teacher extends Employee {
        int kids;
        void uchit() {
            System.out.println("Uchit");}
    }
    class Driver extends Employee {
        String machina;
        void vodit() {System.out.println("Vodit");
        }
    }



