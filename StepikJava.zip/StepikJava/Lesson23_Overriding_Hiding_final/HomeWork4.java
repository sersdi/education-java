package Stepik.Lesson23_Overriding_Hiding_final;

class X4 {
}
class Y4 extends X4{}

public class HomeWork4{
    public static void abc(X4 x, Y4 y) {
        System.out.println("Privet");

    }
    public static void abc(Y4 y,X4 x){
        System.out.println("Poka");
    }

    public static void main(String[] args) {
        Y4 a = new Y4();
        X4 b = new Y4();
        abc(b,a);

    }
}

