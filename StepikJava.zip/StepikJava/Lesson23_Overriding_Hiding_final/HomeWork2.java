package Stepik.Lesson23_Overriding_Hiding_final;

public class HomeWork2 {
    protected void abc(){
        System.out.println("HomeWork2");
    }
}
class Y2 extends HomeWork2{
    public void abc(){
        System.out.println("y2");
    }
    public void def(){
        Y2 y2=new Y2();
        y2.abc();
    }
    public void ghi(){
        HomeWork2 x = new HomeWork2();
        x.abc();
    }

    public static void main(String[] args) {
        Y2 a= new Y2();
        a.abc();
        a.def();
        a.ghi();
    }
}
