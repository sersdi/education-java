package Stepik.Lesson23_Overriding_Hiding_final;

public class Nomber4 {
    void abc(Animal a){System.out.println("A");}
    void abc(Mouse m){System.out.println("M");}

    public static void main(String[] args) {
        Nomber4 n = new Nomber4();
        Animal an = new Mouse();
        n.abc(an);          // при обращении к методу abc параметр an-смотрит тип данных и видит Animal который выводит "A"
        an.getName();       // при обращении к обьекту an выводит метод getName перезаписанных тк создали an обьект типа mouse

    }
}
class Animal{
    void getName(){System.out.println("Animal");}
}
class Mouse extends Animal{
    void getName(){System.out.println("Mouse");}
}
