package Stepik.Lesson23_Overriding_Hiding_final;

public class Nomber6 {
}
class Animal6{
    static String showName(){                   //Static методы не перезаписываются
        return "Some Animal";
    }
    void showInfoAboutAnimal(){
        System.out.println("Name of Animal: "+showName());
    }
}
class Mouse6 extends Animal6{
    static String showName(){
        return "Jerry";
    }
    void showInfoAboutMouse(){
        System.out.println("Name of Mouse: "+showName());
    }
    public static void main(String[] args) {
        Animal6 a = new Mouse6();
        Mouse6 a1 = new Mouse6();
        a.showInfoAboutAnimal();
        a1.showInfoAboutMouse();

    }
}
