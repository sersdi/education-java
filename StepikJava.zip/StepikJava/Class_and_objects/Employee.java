package Stepik.Class_and_objects;

public class Employee {
   dannie1  d1;        // называем классы
   dannie2  d2;

    double salaryx2(double s1) {  // метод
        double result = s1 * 2;
        return result;
    }

    void info1() {
        System.out.println("Имя:" + d1.name1 + " Должность:" + d1.department1 + "   Зарплата:" + d2.salary1 + " Зарплата после премии:" + salaryx2(155000));
    }

    void info2() {
        System.out.println("Имя:" + d1.name2 + "  Должность:" + d1.department2 + "  Зарплата:" + d2.salary2 + " Зарплата после премии:" + salaryx2(650500));
    }

}

class EmployeeTest{
    public static void main(String[] args) {            // метод
        Employee r1 = new Employee();
        r1.d1 = new dannie1("pilot1", "capitan", "Sergey", "Petya");    // обращаемся через классы к конструкторам
        r1.d2 = new dannie2(1, 35, 155000, 650500);
        r1.salaryx2(155500);
        r1.info1();
        r1.info2();

    }
}
//конструкторы
class dannie1{
    dannie1(String d1, String d2, String n1,String n2){
        department1 = d1;
        department2 = d2;
        name1 = n1;
        name2 = n2;
    }
    String department1;
    String department2;
    String name1;
    String name2;
}
class dannie2{
    dannie2(int i, int a, double s1, double s2){
        id = i;
        age = a;
        salary1  = s1;
        salary2 = s2;
    }
    int id;
    int age;
    double salary1;
    double salary2;

}