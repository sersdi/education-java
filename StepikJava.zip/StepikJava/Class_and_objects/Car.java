package Stepik.Class_and_objects;

public class Car {
    public Car(String cvet, String motor){   //конструктор с параметрами
        color = cvet;
        engine = motor;

        System.out.println("Цвет машины:" + color + " Мотор машины:" + engine);
    }

    String color;
    String engine;
}
// вызываем конструктор через метод     / метод всегда возвращает конструктор нет
class CarTest{
    public static void main (String[] args) {
        Car car1 = new Car("yellow","V8");   //указываем кол-во параметров как у конструктора
        Car car2 = new Car("blue  ","V12");
    }

}

