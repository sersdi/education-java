package Stepik.Class_and_objects;

public class Car2 {
    String colour;
    String engine;
    int speed;

    //создаём методы
    int gas(int skorost) {
        speed+=skorost;
        return speed;
    }

    int tormoz(int skorost) {
        speed-=skorost;
        return speed;
    }

    void showInfo() {          // void тк метод ничего не возвр он пустой
        System.out.println("Цвет:" + colour + " Мотор:" + engine + " skorost:" + speed);
    }
}
// вызываем методы
class Car2Test{
    public static void main(String[]args){
        Car2 c1 = new Car2();
        c1.colour = "white";
        c1.speed = 120;
        c1.engine ="V8";

        c1.showInfo();  // обращаемся к методу showInfo() без параметров он
        c1.gas(20);
        c1.showInfo();
        c1.tormoz(80);
        c1.showInfo();
        }

}

