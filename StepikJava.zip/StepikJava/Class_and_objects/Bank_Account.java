package Stepik.Class_and_objects;

public class Bank_Account {  // классы в джава ссылочные типы данных    // в классе всего один класс паблик
    int id;
    String name = new String("Vanya");
    double balance;

    double popolnenieScheta(double balance, double p){       // метод
        double result1 = balance + p;
        return result1;
    }

    double snytieScheta(double balance, double s){          //метод
        double result2 = balance - s;
        return result2;
    }

}
// обращаемся к методам
class Bank_Account_Test{
    public static void main (String[] args) {
        // создаём обьект
        Bank_Account MyAccount = new Bank_Account();  // тип данных + Имя переменой + значение   MyAccount ссылочный тип данных
        Bank_Account YourAccount = new Bank_Account();
        Bank_Account HisAccount = new Bank_Account();
        //Присваиваем значения
        MyAccount.id = 1;
        MyAccount.name = "Sergey";
        MyAccount.balance = 35.15;
        System.out.println(MyAccount.id + " " + MyAccount.name + " " + MyAccount.balance + "  Счёт поплнен, ваш баланс: " + MyAccount.popolnenieScheta(35.15, 100)  );

        YourAccount.id = 2;
        YourAccount.name = "Petya";
        YourAccount.balance = 20.0;
        System.out.println(YourAccount.id + " " + YourAccount.name + "  " + YourAccount.balance + "  Счёт поплнен, ваш баланс: " + MyAccount.popolnenieScheta(20.0, 100));

        HisAccount.id = 3;
        HisAccount.name = "Kolya";
        HisAccount.balance = 10.0;
        System.out.println(HisAccount.id + " " + HisAccount.name + "  " + HisAccount.balance + "  Счёт поплнен, ваш баланс: " + MyAccount.popolnenieScheta(10.0, 100));




    }
}
















