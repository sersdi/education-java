package Stepik.Class_and_objects;
// главный класс
public class Human {
    String name;                                 // у всех 3 переменных референс тип данных
    Car3 car;
    BankAccount Ba;
    // создаём метод без output
    void info() {                            // метод без парамаетров
        System.out.println("Имя:" + name + " Цвет машины:" + car.color + " Баланс банковского счёта:" + Ba.balance);
    }

}
//класс в котором метод
class HumanTest{
    // создаём внутри класса метод main
    public static void main(String[] args) {
        //внутри метода main создаю обьект класса human
        Human h = new Human();                              //обращаемся к классу human
        h.name = "David";                               // придаём значения переменным через класс human
        h.car = new Car3("Red", "V12");
        h.Ba = new BankAccount(18, 287.15);
        h.info();                                    //обращаемся к методу info в классе Hunan
    }


}

//конструкторы
class Car3{
    Car3(String c, String e) {   // конструктор с параметрами
        engine = e;            //тело
        color = c;
    }
    String color;          //вводим переменные  для конструктора
    String engine;
}
class BankAccount{
    BankAccount(int i, double b) {    // конструктор с параметрами
        id = i;                        //тело конструктора
        balance = b;
    }
    int id;                   //вводим переменные  для конструктора
    double balance;
}

