package Stepik.Class_and_objects;

public class Student {
    //konstructors
    public Student(int id1, String Name1, String Surname1, int yearsEducation1){
        id = id1;
        Name = Name1;
        Surname = Surname1;
        yearsEducation = yearsEducation1;
    }
    Student(int id2,String Name2){
        this(id2, Name2, null, 0);
    }
    Student(){
    }

    public static int a =15;
    int id;
    String Name;
    String Surname;
    int yearsEducation;
    //оценки по 10
    double EconomicEx;
    double LanguageEx;
    double MathEx;

//   method
    double srednyaaOcenka(double EconomicEx, double LanguageEx, double MathEx){
        double result = (EconomicEx + LanguageEx + MathEx)/3;
        return result;
    }
}
//обращаемся к онсовному классу
class StudentTest {
    public static void main(String[] args) {

        Student st1 = new Student(1,"Sergey", "Ivanov", 2);
        System.out.println(st1.id + " " + st1.Name + " " + st1.Surname + " " + st1.yearsEducation + " " + st1.srednyaaOcenka(1.5, 6.7, 8.5));

        Student st2 = new Student(2, "Kolya");
        System.out.println(st2.id + " " + st2.Name + " " +st1.srednyaaOcenka(4.5, 3.5, 6.6));


        Student st3 = new Student();
        st3.Name = "Vasya";
        System.out.println(st3.Name);


    }
}

