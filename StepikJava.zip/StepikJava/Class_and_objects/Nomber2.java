package Stepik.Class_and_objects;

public class Nomber2 {

    int b =120;
    byte b2=-5;
    char c='a';
    String s = "Hello";

    public static void main (String[] args) {
        int a =17;
        System.out.println(a);
    }
}
