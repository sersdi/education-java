package Stepik.Lesson32_Modules;

public class Nomber1 {
}
//Module descriptor
//exports 
//requires
//java.base