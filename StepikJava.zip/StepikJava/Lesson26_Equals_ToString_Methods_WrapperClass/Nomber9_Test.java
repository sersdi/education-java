package Stepik.Lesson26_Equals_ToString_Methods_WrapperClass;

public class Nomber9_Test {
}
    class X{
        static String s="";
        {s+="A";}
        static{s+="B";}
        {s+="C";}
    }
    class Z{
        public static void main(String[] args) {
            System.out.println(X.s);            //"B"    выводит статик значение B
            System.out.println(X.s);            //"B"       выводит статик значение B
            new X();                            //"B"+A+C
            new X();                            //"BAC"+A+C
            System.out.println(X.s);            //"BACAC"
                        //в аутпуте получаем  BACAC


        }
    }

