package Stepik.Lesson26_Equals_ToString_Methods_WrapperClass;
                                                                //приоритет вызовов оверлоадед методов:
                                                                //1 Точное совпадение типов данных
                                                                //2 Поглощающие типы данных(Большие типы данных для primitive и parent классы для reference типов)
                                                                //3 Autoboxed типы данных
                                                                //4 Varargs

public class Nomber3_Methods_Priority {             //приоритетность методов при метод оверлоадед
    void abc(int i){                            //1 приоритет
        System.out.println("int");
    }
    void abc(byte i){                           //3 приоритет
        System.out.println("byte");}
    void abc(long i){                          //2 приоритет
        System.out.println("long");}


    void ghi(int i, int b){                 //1 приоритет
        System.out.println("Hello 1");
    }
    void ghi(long a ,long b){               //2 приоритет
        System.out.println("Hello 2");
    }
    void ghi(Integer a,Integer b){          //3 приоритет
        System.out.println("Hello 3");
    }
    void ghi(int...a){                      //4 приоритет
        System.out.println("Hello 4");
    }




    public static void main(String[] args) {
        Nomber3_Methods_Priority n = new Nomber3_Methods_Priority();
        n.abc(1);
        n.ghi(1,2);


    }







}
