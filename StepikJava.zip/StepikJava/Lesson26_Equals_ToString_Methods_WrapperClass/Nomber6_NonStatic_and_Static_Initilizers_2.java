package Stepik.Lesson26_Equals_ToString_Methods_WrapperClass;

public class Nomber6_NonStatic_and_Static_Initilizers_2 {
                                                                //Последовательность иницилизации инишилайзер блоков и переменных:
                                        //1 Статические блоки и переменные род класса
                                        //2 Статические блоки и переменные дочернего класса
                                        //3 Не статические блоки и перменные род класса
                                        //4 конструктор род класса
                                        //5 не статические блоки и перменные дочернего класса
                                        //6 конструктор дочернего класса
                            //Иницилизация пунктов 3-6 происходит только и при каждом создании обьекта
    int a = 3;
    Nomber6_NonStatic_and_Static_Initilizers_2() {      //конструктор
        a = 4;
    }

    {                                                       //инишилайзер блок
        a = 5;
    }
}
//    public static void main(String[] args) {
//        Nomber6  t = new Nomber6();
//        System.out.println(t.a);
//    }
    class A{
        static final int b;        //константы всегда при создании  должны определять их значение либо в статик инишилайзере
        int a =5;

        static{b=10;}           //в статик инишилайзере нельзя обращаться к нестатик переменным
    }
    class B{
        static int c;
        static final int d;
        static final int e =1;
        static final int f;

        static{                             //статик инишилайзер блок
            c=5;
            d=3;
//            e=2;
            f=0;
        }
    }


    class C{
        String s ="ok";
        {                               //4         //инишилайзер блок
            System.out.println(s);
        }

        static int i =0;

        static{                                         //статик инишилайзер блок
            System.out.println(i);          //1                                         //при слзданни обьекта в мэйне с выполнится в такой последовательности
        }
        static{                             //2     //статик инишилайзер блок
            i=+1;
            System.out.println(i);
        }

        C(){                                         //5        //конструктор
            System.out.println("Eto konstructor");
        }
        public static void main(String[] args) {
            System.out.println("Privet vsem");          //3     //будет после статик инишилайзере тк до создания самого обьекта
            C c = new C();
        }
    }


    class D{
        static{abc(2);}                 //1
        static void abc(int a){
            System.out.println(a+" ");
        }
        D(){abc(5);}                    //6
        static{abc(4);}                 //2
        {abc(6);}                       //4
        static{                                 //7
            System.out.println(new D());}   //3 ПРИ СОЗДАНИИ ОБЬЕКТА D ПРОСИХОДИТ ВЫзов non static инишилайзеров, затем выполняется контсруктор D(создается обьект)
        {abc(8);}                       //5

        public static void main(String[] args) {

        }
    }

