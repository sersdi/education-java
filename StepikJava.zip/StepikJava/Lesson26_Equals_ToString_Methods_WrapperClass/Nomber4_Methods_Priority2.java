package Stepik.Lesson26_Equals_ToString_Methods_WrapperClass;

public class Nomber4_Methods_Priority2 {
    static void abc(String s){         // 1     прямое соответсвие
        System.out.println("A");
   }
    static void abc(String...s){        // 3    varargs
        System.out.println("B");
    }
   static void abc(Object s){          // 2     стринг это object(parent)
       System.out.println("C");
    }
    static void abc(String s1,String s2){       // 4    2 параметра пока не будет то в последнюю очередь
        System.out.println("D");
    }


    static void def(Long a){               // 0        Конверация типов данных для соответсивия параметр листу метода не может происходить в 2 этапа
        System.out.println("e");
    }
    static void def(Long...a){             // 0        Конверация типов данных для соответсивия параметр листу метода не может происходить в 2 этапа
        System.out.println("f");
    }
    static void def(long a){               // 1    прямое соответствие
        System.out.println("g");
    }
    static void def(Object a){             // 2     int(object)
        System.out.println("h");
    }
    static void def(Integer a){            // 3    автобоксинг int в Integer wrapper class
        System.out.println("I");
    }


    public static void main(String[] args) {
        Nomber4_Methods_Priority2 n = new Nomber4_Methods_Priority2();
        n.abc("ok");
        n.def(50);


    }

}
