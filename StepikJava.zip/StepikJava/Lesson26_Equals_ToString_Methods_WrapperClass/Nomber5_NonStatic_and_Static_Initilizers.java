package Stepik.Lesson26_Equals_ToString_Methods_WrapperClass;

public class Nomber5_NonStatic_and_Static_Initilizers {                 //initializer block срабатывает каждый раз когда создаётся новый обьект соответсвующего класса
                                                                        // Static initializers block срабатывает один раз когда класс загружается в память
    {         //initializer block 3
        System.out.println("Eto init blok 3");
    }

                                                                //конструктор
    Nomber5_NonStatic_and_Static_Initilizers(){
        System.out.println("Eto konstrucktor 1");
    }
    Nomber5_NonStatic_and_Static_Initilizers(int a){           //конструктор c параметром
        this();                 //обращаемся к оверлоадед конструктороу (первому)
        System.out.println("Eto konstrucktor 2");
    }


    {                                                       //initializer block1
        System.out.println("Eto init blok 1");
    }

    static {                                              // Static initializers block срабатывает только один раз когда класс загружается в память
        System.out.println("Eto static init blok 1");
    }

    {                                                       //initializer block2
        System.out.println("Eto init blok 2");
    }
    static{                                                  //Static initializer block2
        System.out.println("Eto static init blok 2");
    }

    public static void main(String[] args) {
        Nomber5_NonStatic_and_Static_Initilizers t1 = new Nomber5_NonStatic_and_Static_Initilizers();
        Nomber5_NonStatic_and_Static_Initilizers t2 = new Nomber5_NonStatic_and_Static_Initilizers(2);


    }








    
}
