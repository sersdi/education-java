package Stepik.Lesson26_Equals_ToString_Methods_WrapperClass;

import java.util.ArrayList;

public class Nomber2_Wrapper_class {            //Wrapper_class классы которые оборачивают наши данные.
                                        // Благодаря ему видим примитивные типы данных как классы.
                                        // тк Java Обьекто ориентированный язык(типы данных как классы)
                                        //Заключает в себя значения примитивных типов данных
                                        //Wrapper_class:
    //byte-Byte                 float-Float
    //short-Short               double-Double
    //int-Integer               char-Char
    //long-Long                 boolean-Boolean

    //AutoBoxing-конвертирование примитивных данных в wrapper class
    //Unboxing-конвертирование обьекта типа wrapper class в примитивный тип данных(обратный процесс)

    public static void main(String[] args) {
        ArrayList <Integer> list=new ArrayList<>();
        list.add(5);                //AutoBoxing примитивный тип данных конверитровался в референс int-Integer
//      Long l =50l;

        int a =list.get(0);         //Unboxing (обьект класса Integer( 0 по индексу) конвертируется в примитивный тип данных int)
        System.out.println(a);

        Number b = new Integer(10);     //В класс number входит int
        int c = (int) b;          //Unboxing    делаем кастинг из Number
        switch(c){}         //в свиче можем писать примитивные типы данных и их Wrapper классы. В свиче сравниваем

        String s1="50";
        String s2 = "true";
        String s3 = "3.14";
        boolean b1=Boolean.parseBoolean(s2);
        System.out.println(b1);
        int i1 = Integer.parseInt(s1);  //метод parse конвертирует значение типа данных String в соответсвующий примитивный тип данных
        System.out.println(i1);
        double d = Double.parseDouble(s3);
        System.out.println(d);

        Integer i3 = Integer.valueOf(10);  //1)valueOf метод статик как и parse Создали обьект i3 со значением 10 класса Integer
        System.out.println(i3);

        double d2 = Double.valueOf(s3);     //2)valueOf создался обьект типа double и переменная d2 ссылается на этот обьект(в параметре поместили стринг)
        System.out.println(d2);

        Byte b10 = new Byte((byte)5);       //Используем кастинг что бы создать обьект байт типа данных

        Integer i6 = new Integer(6);
        System.out.println(b10);

    }







}
