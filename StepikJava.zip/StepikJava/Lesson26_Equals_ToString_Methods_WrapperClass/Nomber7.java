package Stepik.Lesson26_Equals_ToString_Methods_WrapperClass;
//Последовательность иницилизации инишилайзер блоков и переменных:
//1 Статические блоки и переменные род класса
//2 Статические блоки и переменные дочернего класса
//3 Не статические блоки и перменные род класса
//4 конструктор род класса
//5 не статические блоки и перменные дочернего класса
//6 конструктор дочернего класса
//Иницилизация пунктов 3-6 происходит только и при каждом создании обьекта

public class Nomber7 {
    public static void main(String[] args) {
        Lion l = new Lion();
    }
}
class Animal {
    Animal() {
        System.out.println("Konstructor of Animal");
    }
    static {
        System.out.println("Static init in Animal");
    }
    {
        System.out.println("non-static init in Animal");
    }
}

class Mammal extends Animal{
    Mammal(){
        System.out.println("Konstructor of Mammal");
    }
    static{
        System.out.println("Static init in Mammal");
    }
    {
        System.out.println("non-static init in Mammal");
    }
}

class Lion extends Mammal{
    Lion(){
        System.out.println("Konstructor of Lion");
    }
    static{
        System.out.println("Static init in Lion");
    }
    {
        System.out.println("non-static init in Lion");
    }
}


