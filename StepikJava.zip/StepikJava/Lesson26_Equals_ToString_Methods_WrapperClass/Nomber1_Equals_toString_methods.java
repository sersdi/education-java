package Stepik.Lesson26_Equals_ToString_Methods_WrapperClass;
import java.util.ArrayList;
public class Nomber1_Equals_toString_methods {
    public static void main(String[] args) {
        Car c1 =new Car("red","v12");
        Car c2 = new Car("red","v12");
        Car c3 = new Car("blue","v8");
        ArrayList <Car> list= new ArrayList<>();   //Создаём эррэй лист
        list.add(c1);                              //добавляем в эррэй лист обьекты класса кар
        list.add(c2);
        list.add(c3);
        Car c4 = new Car("blue","v8");

        System.out.println(list.contains(c4));      //метлод contains из листа работает с equals тк  мы его перезаписали будет тру ТК мы не доб с4 он сравнивает его параметры с другими обьектами в листе и находит совпадение
        System.out.println(c1.equals(c2));      //прежде чем сравнить обьекты мы перезаписываем метод equals чтобы он сравнивал параметры созданных обьектов а не сслыки на обьект

        System.out.println(c2.toString());      //Метод toString(by default) показывает название класса знак @ и число в 16 системе
        System.out.println(list);           //в эрэй листе метод ту стринг будет автоматически перезаписан тк мы его перезаписали а эрэй листе параметры будут в скобках и через запятую
    }
}
class Car{
    String colour;                          //переменные клсса
    String engine;
    Car(String colour, String engine){          //конструктор класса кар
        this.colour = colour;
        this.engine = engine;
    }
    @Override
    public boolean equals(Object obj){                   //перезаписываем метод equals  В параметре указываем класс Object что бы сравнивать не только обьекты класса Кар и что бы перезаписвать метод Equals
        if(obj instanceof Car){                 //кастинг если obj принадлежит к классу Кар
            Car c2 = (Car)obj;                  //то Кар с2 ссылается на обьект класса Кар
            return (colour.equals(c2.colour)&&engine.equals(c2.engine));    //возвращаем если параметры одиинаковые то возвращаем тру
        }
        else return false;                           //если параметры разные то false
    }
    @Override                           //оверайд метода тусринг
    public String toString() {
        return "Машина цвета "+colour+" и с мотором "+engine;
    }
}


