package Stepik.Lesson18_Массивы;

public class Test6 {
    public static void maxMin(double[] array) {  //метод работает с массивом тип данных double
        double max = array[0];
        double min = array[0];

        for (int i = 0; i < array.length; i++) {
            if (array[i] > max) {      //нашли макс
                max = array[i];
            }
            if (array[i] < min) {     //нашли мин
                min = array[i];
            }
        }
        System.out.println("min element massiva: " + min + " Max element massiva: " + max);
    }

    public static void main(String[] args) {
        double[] array1 = {1.05, -3.14, 8.0, 9.19, -3.0};   //создаём массив
        maxMin(array1);                            //обращаемся к методу
        maxMin(new double[]{2.5, -1.3});           //обращаемся к новому массиву
    }
}

