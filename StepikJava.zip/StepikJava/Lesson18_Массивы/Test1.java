package Stepik.Lesson18_Массивы;

public class Test1 {
    public static void main(String[] args) {     //Array-массив
        int[]array1;                  //создаем массивы
        String[]array2;                 //существуют массивы с референс либо простыми типами данных
        double[][]array3;
        int[][]array10;                  //двумерный массив элементы
        double[]array7;


        array2=new String[3];         //указываем их длину
        array1=new int[5];
        array10=new int[3][];            //элементы двумерного массива здесь 3 массива с одинарными
        array3 = new double[3][2];
        array7 = new double[2];


        System.out.println(array2.length);  //узнаём длину  2 массива (у массивов length это не метод а метод класса поэтому()не ставятся

        //статичное присвоение элементов(статичная иницилизация)
        array2[0]="prviet";     //в скобках указываем индекс нужного элемента
        array2[1]="poka";
        array2[2]="hey";

        array3[0][0]=3.14;
        array3[2][1]=3.14;

        double[]array5;           //создание
        array5 = new double[2];     //Указываем длину
        array5[0]=2.5;                 // статичная иницилизация
        array5[1]=3.5;

        array7=array5;    //7 массив ссылается на 5


        array3[1] = array5;   // массиву 3 элементу с индексом 1 присвоили значение 5 массива
        System.out.println(array3[1][0]);



    }
}
