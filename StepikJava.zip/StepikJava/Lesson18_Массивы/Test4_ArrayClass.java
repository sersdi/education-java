package Stepik.Lesson18_Массивы;
//в джаве есть класс Arrays что бы с ним работать его нужно импортировать
import java.util.Arrays;
public class Test4_ArrayClass {
    public static void main(String[] args) {
        int array1[]={1,9,3,-8,0,5,4,1};   // создали одномерный массив и добавили в него элементы
        for(int i=0;i<array1.length;i++){ // чтобы вывести элементы массива создаём цикл
            System.out.print(array1[i] + " ");
        }
        System.out.println();    //пишем с новой строки
        Arrays.sort(array1);    //сортируем наш массив по значению              //метод sort
        for(int i=0;i<array1.length;i++){       //выводим на экран элементы ещё раз
            System.out.print(array1[i] + " ");
        }
        int index1 = Arrays.binarySearch(array1,5);   //ищём индекс определенного элемента массива  метод binarySearch работает в остортированном массиве
        System.out.println(index1);






    }
}
