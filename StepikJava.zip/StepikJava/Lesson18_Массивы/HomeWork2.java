package Stepik.Lesson18_Массивы;

public class HomeWork2 {
    //программа выводит на экран массив

    public static void showArray(String[][]array){
        System.out.print("{ ");                              //выводим первую скобку двумерного массива
        for(int i=0;i<array.length;i++){                     //цикл выполняеься покеа i<длины массива
            System.out.print("{");                      //cоставим скобку у удномерного массива
            for(int j=0;j < array[i].length;j++){                //цикл выполняется пока j<длины одномерного массива
                if(j != array[i].length-1){                          //если j не равняется индексу одномерного массива то пишем
                    System.out.print(array[i][j]+", ");
                }
                else{
                    System.out.print(array[i][j]);
                }
            }

            if(i !=array.length-1){
                System.out.print("}, ");
            }
            else{
                System.out.print("}");
            }
        }
        System.out.println(" }");

    }


    public static void main(String[] args) {
        String[][]s1= new String[][]{{"apple","orange","3"}, {"4"}, {"5","6"}};   //создаём массив
        showArray(s1);// применяем метод

        showArray(new String[][]{{"man","woman"},{"male","female"}});  //в методе создаём массив

    }
}
