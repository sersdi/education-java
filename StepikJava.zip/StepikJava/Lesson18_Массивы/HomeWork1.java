package Stepik.Lesson18_Массивы;
//программа которая заменяет класс Arrays сортируем массив самостоятельно
public class HomeWork1 {
    public static int[] Sortirovka(int[]array) {           //создаю статичный метод тип данных int в методе инпут одномерный массив
        int a;                                          //вводим новую переменную что бы при сортировке менять  их местами
        for (int i = 0; i < array.length; i++) {                //цикл проверяет первый элемент
            int min = array[i];                                 //вводим переменную min ей присваиваем элемент из массива с индексом i
            int index = i;                                      //вводим переменную индекс
            for (int j = i + 1; j < array.length; j++) {        //цикл проверяет второй элемент
                if (array[j] < min) {
                    min = array[j];
                    index = j;
                }
            }

            if (i != index) {          //идёт проверка на замену
                a = array[i];
                array[i] = min;
                array[index] = a;
            }

        }
        return array;
    }
    public static void main(String[] args) {
        int[]array={1,2,3,4,0,-2,-10};
        Sortirovka(array);
        for(int i=0;i< array.length;i++){               //выводим сам массив который получился
            System.out.println(array[i]);
        }
    }


}
