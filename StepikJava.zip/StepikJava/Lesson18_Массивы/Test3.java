package Stepik.Lesson18_Массивы;

public class Test3 {
    static String s;
    public static void main(String[] args) {
        int[] array = new int[3];
        array[0]=1;
        array[1]=2;
        array[2]=3;
        int[][]array2=new int[3][];
        System.out.println(s.length());  // у стринга дефолт налл а у налла нет длины


    }
}

