package Stepik.Lesson18_Массивы;

public class Test5_Sravnenie_Massivov {
    public static void main(String[] args) {
        int array1[]={1,9,3,-8,0,5,4,1};
        int array2[]={1,9,3,-8,0,5,4,1};
        int array3[]=array2;
        System.out.println(array1==array2);//false ссылки на обьект разные
        System.out.println(array3==array2);//true после изменения ссылки равны
        System.out.println(array1.equals(array2)); //тоже самое ==(в array не перезаписан)
        array1[5-3]=3;
        //array1[array1.length]=10; ошибка тк длина массива 8 а индекса такого нет


    }
}
