package Stepik.Lesson18_Массивы;

public class Test7_String_Stringbuilder {
    public static void main(String[] args) {
        char[] array={'l','k','o'};           // создалём массив тип данных чар
        String s = new String(array);         //создаём строку с данными из массива
        System.out.println(array);

        StringBuilder sb = new StringBuilder("Hello World");               //Создаём обьект класса стрингбирдер
        //sb.append(array,1,2);                                       //метод append
        sb.insert(2,array,1,2);                       //метод insert 1 параметр в какоем место вставить обьект 2 какой обьект 3-4 с какого индекса по какой вставлять обьект
        System.out.println(sb);


    }
}
