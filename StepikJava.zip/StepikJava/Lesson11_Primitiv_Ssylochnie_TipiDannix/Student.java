package Stepik.Lesson11_Primitiv_Ssylochnie_TipiDannix;

public class Student {
    public String name;
    public int course;
    public double grade;

    public Student(String name, int course, double grade) {
        this.name = name;
        this.course = course;
        this.grade = grade;
    }

//    public static void swap(Student s1, Student s2) {     //метод статичный тк выполняется без создания обьектов. В методе референс тип данных Student
//        Student s3 = s1;                                  // когда в параметр подставляется параметры с типом данных референс, то туда подставляются их копии, сами ссылки на обьекты не меняются
//        s1 = s2;                                          //с помощью типов данных референс можно менять, изменять элементы обьекта с помощью копий
//        s2 = s3;                                          //можем изменить имя, нельзя менять референсы на обьекты(нельзя менять сам обьект)//       System.out.println(s1.name);
        // параметры референс живут только внтури метода, потом их копии удаляются
//    }

//    public static void changeName(Student s1) {               //метод статичный тк выполняется без создания обьектов.
//        s1.name = "Sergey";

//    }


//    public static void main(String[] args) {
//       Student st1 = new Student("Petr", 3, 9.5);
//        Student st2 = new Student("Sanya", 1, 5.3);
//        swap(st1, st2);                       //имена поменются только внутри метода (сам обьект не изменится)
//        System.out.println(st1.name);
//        System.out.println(st2.name);

//        changeName(st1);                    // вызываем метод  после него обьект изменился выводим его на экран
//     System.out.println(st1.name);


    public static void sravnenie(Student s1, Student s2) {
        if (s1.name.equals(s2.name) && s1.course == s2.course && s1.grade == s2.grade) {
            System.out.println("Studenti ravni");}
        else {
            System.out.println("Stydenti ne ravni");}
    }

    public static void polnoeSravnenie(Student s1, Student s2) {
        if (s1.name.equals(s2.name)) {            // equals для типов данных СТРИНГ
            if (s1.course == s2.course) {
                if (s1.grade == s2.grade) {
                    System.out.println("Студенты равны по всем параметрам");}
                else {
                    System.out.println("Имена и курсы одинаковые, оценки различаются");}
            } else {
                System.out.println("Имена одиновые,но курсы разные");}
        } else {
            System.out.println("Имена студентов разные");}

    }

    public static void main(String[] args) {
        Student st1 = new Student("Kolya", 3, 9.5);
        Student st2 = new Student("kolya", 3, 9.5);

        sravnenie(st2, st1);
        polnoeSravnenie(st2, st1);
        System.out.println(st1.name);
        System.out.println(st2.name);
    }
}









