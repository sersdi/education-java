package Stepik.Lesson11_Primitiv_Ssylochnie_TipiDannix;

public class Car {
     String colour;
     String engine;
     int dvery;
    
    Car(String colour, String engine, int dvery){
        this.colour = colour; 
        this.engine = engine;
        this.dvery = dvery;
    }
}

class CarTest{
    public static void changeDvery(Car car1, int col){            // метод менят кол-во дверей на кол-во в параметре метода   (копии в параметрах)
        car1.dvery = col;
    }

    public static void swap(Car col1, Car col2){        //метод менят цвета двух обьектов(в парамтре копии) тк тип данных референс(Car)
        Car col3 = col1;
        col1 = col2;
        col2 = col3;
        System.out.println(col1.colour);
        System.out.println(col2.colour);

    }

    public static void main(String[] args) {
        Car c1 = new Car("red", "v8", 2);
        Car c2 = new Car("blue","v12", 4);
        changeDvery(c1, 6);                                          //результат сохранился так как меняем данные обьекта  // меняем кол-во дверей у обьекта
        System.out.println(c1.colour + " " + c1.dvery);
        swap(c1, c2);                                           //результат этого метода виден только в методе        //Меняем цвет двух обьектов
        System.out.println(c1.colour + "." + c1.engine + "." + c1.dvery);
        System.out.println(c2.colour + "." + c2.engine + "." + c2.dvery);
        
    }
}
