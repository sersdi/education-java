package Stepik.Lesson11_Primitiv_Ssylochnie_TipiDannix;

public class Employee {
    public String name;
    public double salary;

    Employee(String name, double salary){          //конструктор
        this.name = name;
        this.salary = salary;
        System.out.println(name);
        System.out.println(salary);
    }

    public double uvelichitel(double a){           //метод
        a = a * 2;
        return a;

    }
}

class EmployeeTest{
    public static void main(String[] args) {
        Employee emp1 = new Employee("Ivan", 100.55);
        System.out.println(emp1.uvelichitel(100.55));

    }
}


