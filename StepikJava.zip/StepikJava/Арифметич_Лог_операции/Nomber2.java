package Stepik.Арифметич_Лог_операции;

public class Nomber2 {
    public static void main (String[] args) {
        int a=11;
        int b=3;

        int целаячасть=a/b;
        int остаток=a%b;

        int x = 5;
        int y = 3;
        int z =x-y++;   //++ увеличивает на +1y  после выполнения действия x-y

        System.out.println(z);
        System.out.println(y);

        //System.out.println(целаячасть);
        //System.out.println(остаток);


    }
}
