package Stepik.Арифметич_Лог_операции;

public class Nomber1 {
    public static void main (String[] args) {
        int a=5;
        int b=a*2;

        int x=1, y=2, z=3;

        System.out.println(b);


    }
}
