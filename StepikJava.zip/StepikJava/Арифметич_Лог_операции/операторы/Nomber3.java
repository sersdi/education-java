package Stepik.Арифметич_Лог_операции.операторы;

public class Nomber3 {
    public static void main (String[] args) {
        int a=10;
        int b =5;
        int c =0;
        int d=100;

        boolean e =(a>b) & c++==d; //true && false = false   &&-обычный энд &(битовые операции) -один энд выражение все равно обработается

        int x=10;
        int y=5;

        boolean b1=false;
        boolean b2=false;
        boolean b3=true;
        boolean b4=false;


        System.out.println(e);
        System.out.println(c);
        System.out.println(x|y);    //битовая операция (или) || обычный | битовый (битовые с числами взаим)
        System.out.println(b1^b2^b3^b4);    // ^(or) возвращает тру когда одна только операнда в выражении тру
    }
}
