package Stepik.Арифметич_Лог_операции.операторы;

public class nomber4 {
    public static void main (String[] args) {
        int a=10;
        int b=3;

        int c =a-- - b*2;        //++a префикс a++ постфикс  префикс сначала увеличиваает на 1, префикс после операций увеличивает переменную


        System.out.println(c);
        System.out.println(a);

    }
}
