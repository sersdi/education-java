package Stepik.Арифметич_Лог_операции.операторы;

public class Nomber2 {
    public static void main(String[] args) {
        int a=3;
        int b=5;

        boolean b1=a>=b;

        boolean x=false;
        boolean y=false;
        boolean z=true;

        boolean result =x||y||z;    // ||-или(or) &&-и(and)


        System.out.println(result);

    }
}
