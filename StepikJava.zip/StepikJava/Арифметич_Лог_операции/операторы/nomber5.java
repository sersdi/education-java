package Stepik.Арифметич_Лог_операции.операторы;

public class nomber5 {
    public static void main(String[] args) {

        char c = 'a';   // из эникода (97 порядковый номер a)
        int i =10;
        int i2=c;
        short s1 = 500;


        System.out.println(i%c);
    }
}
