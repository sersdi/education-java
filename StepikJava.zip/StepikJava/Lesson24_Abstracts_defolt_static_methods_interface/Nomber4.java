package Stepik.Lesson24_Abstracts_defolt_static_methods_interface;

public class Nomber4 {
    public static void main(String[] args) {
        Jumpable j1 = new Human();
        Jumpable j2 = new Animal();
        j1.jump();
        j2.jump();
    }
}
class Human implements Jumpable{
    @Override
    public void jump() {System.out.println("Human jumps");}
}
class Animal implements Jumpable{
    @Override
    public void jump() {System.out.println("Animal jumps");}
}
interface Jumpable{ void jump();};
interface A2{ void abc();}
interface B2 extends A2,Jumpable{ void def();}                    //интерфейс может наследовать интерфейсы

abstract class D implements B2{}                                //абстрактный класс наследует интерфейсы