package Stepik.Lesson24_Abstracts_defolt_static_methods_interface;

public class Nomber2_Abstract_methods {
    public static void main(String[] args) {
        Figura f1 = new Kvadrat();                      //создать обьект можно не абстракт класса (используем тип переменной abstract).Можно обращаться только к элементам abstract класса(Figura)тк тип данных abstract класс
        System.out.println(f1.kolvoStoron);     //компаил тайм байдинг
        f1.ploshad();                           //ран тайм байндинг  //площадь вызвалась для обьекта квадрат
    }
}
abstract class Figura{                              //abstract класс.В абстрактном классе могут быть обычные методы.В абстракт классе может не быть абстракт методов.
//  Figura(int kolvoStoron){
//      this.kolvoStoron = kolvoStoron;}            //невозможно создать обьект abstract класса. Если в классе есть abstract метод то и класс должен быть abstract
                                                    //в абстракт классе могут быть наследники тоже абстракт,они могут перезаписывать методы или нет
                                                    //абстракт класс не может быть файнал(абстракт и файнал класс противополжны по значению друг другу)
    int kolvoStoron=0;                              //переменные не могут быть абстракт.   // У абстракт класса есть конструктор
    abstract void perimetr();       //abstract метод(метод без тела)  Абстрактные методы без тела
    abstract void ploshad();
    void showInfo(){
        System.out.println("Eto figura");
    }
}

class Kvadrat extends Figura{               //классы наследники абстракт класса должны перезаписать или захайдить методы,переменные абстрактные род класса
//    Kvadrat(int kolvoStroron){            //любой перезаписанный метод может быть перезаписан или нет
//      super(kolvoStroron);                      //обращаемся к род конструктору
//      this.kolvoStroron = kolvoStroron;
//    }
    int kolvoStroron=4;
    int storona1 = 10;
    public void perimetr(){
        System.out.println("perimetr kvadrata = "+storona1*4);
    }
    public void ploshad(){
        System.out.println("ploshad kvadrata= "+storona1*storona1);
    }
}
abstract class Pryamougolnik extends Figura{
    int kolvoStroron=4;
    int storona1 = 8;
    int storona2=5;
    abstract public void perimetr();
    public void ploshad(){
        System.out.println("ploshad pryamougolnika = "+storona1*storona2);
    }
}
class Okrugnost extends Figura{
    int kolvoStroron=0;
    int radius = 3;
    public void perimetr(){
        System.out.println("perimetr okrugnosti  = "+2*3.14*radius);
    }
    public void ploshad(){
        System.out.println("ploshad okrugnosti = "+3.14*radius*radius);
    }
}
abstract class Chetirexugolnick extends Figura{
    void def(){
        System.out.println("Eto chetirexugolnick");
    }

}
