package Stepik.Lesson24_Abstracts_defolt_static_methods_interface;

public class Nomber7_Private_StaticMethodsInInterface {
}
interface I {                                           //private interface method не может быть абстракт
    private static void method1(){                      //private interface метод может быть использован только внутри интерфейса
        System.out.println("static method1");
    }
    private void method2(){
        System.out.println("non-static methods");                //не можем использовать private вместе с abstract
    }
    default void methid3(){                                  //private static метод может быть использован внутри static или non-static методов
        method2();
        method1();
    }
    static void method4(){
        method1();
        //method2();                                    //privat non-static метод не может быть использован внутри private static methodov
    }

}
