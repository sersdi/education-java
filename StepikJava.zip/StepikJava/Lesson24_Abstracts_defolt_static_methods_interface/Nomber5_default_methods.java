package Stepik.Lesson24_Abstracts_defolt_static_methods_interface;

public class Nomber5_default_methods {
}
interface I1{
    void abc();
    public default void ghi(){System.out.println("eto metod ghi");};    //аксесс модифаер в интерфесе всегда public
    default void def(){System.out.println("eto metod def");}          //дефолтный метод можно не оверайдить.В интерфейсе дефолтный метод всегда имеет тело
}                                                                     //дефолтные методы только в интерфейсе(не могут быть final или abstract) тк абстракт не имеет тело,файнал не может перезаписываться

class Z2 implements I1{
    public void abc(){
        System.out.println("eto metod abc");
    }
    public static void main(String[] args) {
        Z2 z = new Z2();
        z.abc();
        z.def();
        z.ghi();
    }
    @Override
    public void ghi() {System.out.println("eto metod ghi");}             //можем оверайдить дефолт метод интерфейса
}
