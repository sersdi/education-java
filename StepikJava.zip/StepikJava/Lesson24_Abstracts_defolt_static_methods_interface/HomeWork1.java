package Stepik.Lesson24_Abstracts_defolt_static_methods_interface;

public class HomeWork1 {
    public static void main(String[] args) {
        Mechenosec m = new Mechenosec("Mechenosec");
        System.out.println(m.name);
        m.swim();
        m.sleep();
        m.eat();
        System.out.println();

        SpeakAble s = new Pingvin("Pingvin");
        s.speak();
        System.out.println();

        Animal1 a = new Lev("Lev");
        System.out.println(a.name);
        a.eat();
        a.sleep();
        System.out.println();

        Mammal1 ma = new Lev("Mammal");
        System.out.println(ma.name);
        ma.run();
        ma.sleep();
        ma.speak();
        ma.eat();
        System.out.println();
    }
}
abstract class Animal1{
    String name;
    Animal1(String name) {
        this.name = name;
    }
    abstract void eat();
    abstract void sleep();
}

abstract class Fish1 extends Animal1 {
    Fish1(String name) {
        super(name);                        //передаем значение переменной в конструктор супер класса
        this.name = name;
    }
    public void sleep() {
        System.out.println("vsegda interesno nabludat kak spyat ribi");
    }
    abstract void swim();
}
class Mechenosec extends Fish1 {
    Mechenosec(String name) {
        super(name);
    }
    public void swim() {
        System.out.println("mechenosec bistro plavat");
    }
    public void eat() {
        System.out.println("Mechenosec ne xichnik,est ribiy korm");
    }
}

abstract class Bird1 extends Animal1 implements SpeakAble {
    Bird1(String name) {
        super(name);
        this.name = name;
    }
    abstract void fly();
    @Override
    public void speak() {System.out.println(name + " speaks");}
}
class Pingvin extends Bird1 {
    Pingvin(String name) {
        super(name);
        this.name = name;
    }
    public void eat() {
        System.out.println("Pingvin lubit est riby");
    }
    public void sleep() {
        System.out.println("Pingvini spyat prijavhis k drug drugu");
    }
    public void fly() {
        System.out.println("Pingvin ne letayut");
    }
    public void speak() {
        System.out.println("Pingvin cant sing");
    }
}

abstract class Mammal1 extends Animal1 implements SpeakAble {
    Mammal1(String name) {
        super(name);
        this.name = name;
    }
    abstract void run();
}
class Lev extends Mammal1{
    Lev(String name){
        super(name);
        this.name = name;
    }
    public void sleep(){
        System.out.println("Lev spit ves den");
    }
    public void eat(){
        System.out.println("Lev est myaso");
    }
    public void run(){
        System.out.println("Lev ne samaya bistraya koska");
    }
    public void speak(){
        System.out.println("Mammal richit");
    }
}
interface SpeakAble {
    default void speak() {System.out.println("Somebody speaks");}
}



