package Stepik.Lesson24_Abstracts_defolt_static_methods_interface;
import java.util.ArrayList;                                             //относится к классам и интерфейсам
public class Nomber6_Static_methods_interface {
}
interface I6{
    default void abc(){System.out.println("eto metod abc");}
    static void def(){System.out.println("static method1");}      //статические методы не наследуются из интерфейса в класс
}                                                               //что бы статик метод вызвать нужно использовать названеи интерфейса
interface I7{ static void def(){System.out.println("static method2");}}

abstract class O{}

class R extends O implements I6,I7{                           //можем имплементить 2 интерфейса со статик методами одинаковыми тк когда их используем указываем название интерфейса(оно у них будет разное)
    static I7 method1(I7 i){return new D2();}
    public static void main(String[] args) {
        I7 i = new D2();
        method1(i);
        I6.def();                                   //для вызова статик метода из интерфейса исп название интерфейса(даже если не импломинтируем его(область видимости))
        I7.def();
    }
}
class D2 implements I7{}