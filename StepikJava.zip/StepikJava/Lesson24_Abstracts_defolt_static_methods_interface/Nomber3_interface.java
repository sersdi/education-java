package Stepik.Lesson24_Abstracts_defolt_static_methods_interface;

public class Nomber3_interface {
    public static void main(String[] args) {
        Help_Able h = new Driver();             //с помощью интерфейса можно создавать переменные класса (тип интерфейс) Тк java поддерживает наследование
        Swim_Able s = new Driver();
        Employee e = new Driver();
        System.out.println(h.a);
        h.pomosh();
        h.tushitPojar("Voda");
        s.swim();
    }
}
class Employee{
    double salary;
    String name;
    int age;
    int experiance;
    void eat(){System.out.println("Kushat");}
    void sleep(){System.out.println("Spat");}
}

class Teacher extends Employee implements Help_Able {               //implements-воплощает интерфейс  после воплощения нужнно перезаписать все методы если класс не абстрактный. Если класс абстракт то тогда нельзя создавать обьекты в классе
    int kolvokids;
    void uchit(){System.out.println("Uchit");}
    @Override
    public void pomosh() {
        System.out.println("Uchitel pomogaet");
    }
    @Override
    public void tushitPojar(String s) {
        System.out.println("Uchitel tushit pojar s pomoshyu "+s);
    }
}
class Driver extends Employee implements Help_Able,Swim_Able {
    String machina;
    void vodit(){System.out.println("Vodit");}
    @Override                                               //перезаписываем методы из интерфейса в класс что бы они вызывались и класс driver небыл абстракт
    public void pomosh(){
        System.out.println("Voditel pomogaet");
    }
    @Override
    public void tushitPojar(String s) {
        System.out.println("Voidetel tushit pojar s pomoshyu "+s);
    }
    @Override
    public void swim() {
        System.out.println("Voditel plavaet");
    }
}
                                            //интерфейс не класс. У интерфейса нет конструктора.Access modifier public (default) Если класс который иплементировал интерфейс не перезаписал методы то тогда класс будет abstract
interface Help_Able{                    //создали два интерфейса. Интерфейс содержит только абстракт методы и констант переменные
    public abstract void pomosh();      // по дефолту в компиляторе методы абстракт можно не писать словами и паблик
    void tushitPojar(String predmet);
    public final static int a = 10;     // public final static по дефолту когда пишем переменную в интерфейсе
}
interface Swim_Able{                        //Able значит умеющий
    void swim();
}

