package Stepik.Типы_данных;

public class Nomber1 {
    public static void main (String[] args) {
        // целые
        byte b1  = 10;
        byte b2 = 20;
        byte b3 = 30;

        short s1 = 5;
        short s2 = -10;
        short s3 = 0;

        int i1 = 500;

        long l1 = 1000L;        //+L
        long l2 = 10000000000l;
        long l3 = 51L;
        // дробные
        float f1 = 3.14F;   //32 byte    +F
        float f2 = 2.5f;
        float f3 = 20;     //float(int)
        float f4 =20.0F;

        double d1 = 5.5;  //64byte (дефолтный тип данных в джава)   +D точнее чем float
        double d2 = 87.65;  // можем не исп D тк он стандартный  double(float)
        //символьный
        char c1 = 'a';   // символы в одинарных ковычках и всегда один
        char c2 = 'A';
        char c3 = 1;
        char c4 = ' ';

        char c5 = 500;  //  500-й символ в юникоде  10-ричная система счисления

        char c6 = '\u05AB';   //16-ричная система счисления

        boolean bool1 = true;
        boolean bool2 = false;


        int a1 = 60;         // 10 система
        int a2 = 0B111100;  //2 система счисления
        int a3 = 0b111100;
        int a4 = 074;      //8 ричная система счисления
        int a5 = 0x3c;     //16 система
        int a6 = 0X3C;

        int a7 = 1_000_000_00______0;   // андерскором удобнее писать большие числа// Нельзя писать в начале и конце числа//до и после точки в дробных числах// до и после букв L F D


        System.out.println(c6);
        System.out.println(bool1);
        System.out.println(a6);
        System.out.println(a7);
        System.out.println(a4);




    }

}