package Stepik.Типы_данных;

public class HomeWork1 {
    public static void main (String[] args) {
        //1                 //Системы смчисления
        byte b1 = 12;              //10
        byte b2 = 0b1100;          // 2
        byte b3 = 014;           // 8
        byte b4 = 0XC;     // 16

        System.out.println(b1);
        System.out.println(b2);
        System.out.println(b3);
        System.out.println(b4);

        short s1 = 1300;                    //10
        short s2 = 0b010100010100;          //2
        short s3 = 02424 ;                 //8
        short s4 =0X514 ;                      //16

        System.out.println(s1);
        System.out.println(s2);
        System.out.println(s3);
        System.out.println(s4);

        int i1 = 0;          //10
        int i2 = 0b0;           //2
        int i3 = 00 ;           //8
        int i4 = 0X0;           //16

        System.out.println(i1);
        System.out.println(i2);
        System.out.println(i3);
        System.out.println(i4);

        long l1 = 123456789L;                    //10
        long l2 = 0b0111_0101_1011_1100_1101_0001_0101L;// 2
        long l3 = 0726746425L;                   //8
        long l4 = 0X75BCD15L;                        //16

        System.out.println(l1);
        System.out.println(l2);
        System.out.println(l3);
        System.out.println(l4);

        //2

        float f1 = 13.5F;
        float f2 = 11.2F;

        double d1 = 20.0;
        double d2 = 38.9;

        boolean bool1 = false;
        boolean bool2 = true;

        //3

        char c1 = 'a';
        char c2 = 200;
        char c3 = '\u0235';

        System.out.println(c2);
        System.out.println(c3);

















    }

}
