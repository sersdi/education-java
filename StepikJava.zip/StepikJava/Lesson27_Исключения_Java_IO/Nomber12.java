package Stepik.Lesson27_Исключения_Java_IO;

public class Nomber12 {
    static String abc(){
        String s1 ="";
        String s2 = null;
        try{                            //внешний трай
            try{                        //внутренний трай
                s1+="1";
                s2.charAt(3);           //здесь будет ошибка NulllPointer
                s1+="2";        //это не выполнится из за ошибки выше
            }
            catch (NullPointerException e){         //внутренний кэч //ловим ошибку наллпоинтера
                s1+="3"; //выполнится
                throw new RuntimeException();       //выбрасываем рантайм но оно не ловится
            }
            finally {                           //файнали всегда один будет внешним
                s1+="4";//всегда выполнится
                throw new Exception();      //выбрасываем ошибку. Внешний трай выбрасывает new Exception
            }
        }
        catch (Exception e){            //внешний кэч
            s1+="5";//выполнится
        }

        return s1;              //метод возвращает s1
    }
    public static void main(String[] args) {
        System.out.println(abc());
    }
}
