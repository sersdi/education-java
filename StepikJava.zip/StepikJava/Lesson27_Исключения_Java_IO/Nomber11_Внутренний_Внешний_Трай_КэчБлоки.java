package Stepik.Lesson27_Исключения_Java_IO;

public class Nomber11_Внутренний_Внешний_Трай_КэчБлоки {
    void abc(){
        int[]array = {1,2,3};
        try{                                    //внешний трай
            System.out.println(array[7]);
        }
        catch (ArrayIndexOutOfBoundsException e){  //внешний кэч
            String s =null;
            System.out.println("Пойман эррэй индекс экзепшн во внешнем кэч блоке");
            try{   //внутренний трай
                System.out.println(s.length());
            }
            catch (NullPointerException e2){   //внутренний кэч
                System.out.println("Пойман наллпоинтер екзепшн во внутреннем кэч блоке");
            }
        }

    }

    public static void main(String[] args) {
        Nomber11_Внутренний_Внешний_Трай_КэчБлоки t = new Nomber11_Внутренний_Внешний_Трай_КэчБлоки();
        t.abc();
    }
}
