package Stepik.Lesson27_Исключения_Java_IO;
public class HomeWork1 {
    public static void main(String[] args)throws NeVodaException,RuntimeException{
        Tiger27 t = new Tiger27();
        t.eat("myaso");
        try{t.drink("voda");
            try{t.drink("pivo");}
            catch (NeVodaException e) {System.out.println(e.getMessage());}
            finally {System.out.println("eto inner finally block");}
        }
        catch (NeMyasoException e){System.out.println(e.getMessage());}
        finally {System.out.println("eto outer finally block");}
    }
}
class Tiger27{
    void eat(String s){
        if(!s.equals("myaso")){throw new NeMyasoException("Исключение поймано Tigr ne est: "+s);}
        System.out.println("Tigr est myaso");
    }
    void drink(String s) throws NeVodaException{
        if(!s.equals("voda")){throw new NeVodaException("Исклчение поймано Tigr ne piet: "+s);}
        System.out.println("Tigr piet vodu");
    }
}
class NeMyasoException extends RuntimeException{
    NeMyasoException(String s){super(s);}
}
class NeVodaException extends Exception{
    NeVodaException(String s){super(s);}
}
