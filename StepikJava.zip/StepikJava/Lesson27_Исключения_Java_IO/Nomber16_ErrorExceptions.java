package Stepik.Lesson27_Исключения_Java_IO;
//ExceptionInInitializerError
//StackOverflowError
//OutOfMemoryError      нет памяти свободной
//NoClassDefFoundError  джава не может найти класс рантайм во время запуска программы
public class Nomber16_ErrorExceptions {         //ExceptionInInitializerError всегда выбрасывается когда имеем дело со статик иницилизаторыми переменными методами при рантайм экзепшоне в них
//    static {
//        int a = Integer.parseInt("12e");        //ExceptionInInitializerError будет тк ошибка в статик инишилайзере(тк рантаймэкзепшн будет ерор)
//    }

//    static String s = null;
//    static int a = s.length();                      ////ExceptionInInitializerError тк рантайм экзепшн в статик переменных

    static String s = abc();
    static String abc(){
        String[]array ={"1","2","3"};
        return array[100];                  //ExceptionInInitializerError тк в статик методе рантайм экзепшн
    }
    public static void main(String[] args) {

    }
}

