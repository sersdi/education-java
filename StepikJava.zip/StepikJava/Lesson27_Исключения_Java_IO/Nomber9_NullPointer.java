package Stepik.Lesson27_Исключения_Java_IO;

public class Nomber9_NullPointer {
    public static void main(String[] args)  throws Exception{
        Exception e = null;
        throw e;        //выбросить нал нельзя будет другая ошибка
    }
}
