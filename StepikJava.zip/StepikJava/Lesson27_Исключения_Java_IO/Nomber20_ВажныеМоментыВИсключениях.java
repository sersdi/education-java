package Stepik.Lesson27_Исключения_Java_IO;
import java.io.*;

public class Nomber20_ВажныеМоментыВИсключениях {
     static void abc()throws FileNotFoundException{         //указание в сигнатуре метода исключения которое не выбрасывается в данном методе не является ошибкой
        System.out.println("ok");
    }

    public static void main(String[] args) {
        try{
            abc();
        }
        catch (FileNotFoundException e){
            System.out.println(e.getMessage());

        }

    }
}
