package Stepik.Lesson27_Исключения_Java_IO;
import java.io.*;
public class Nomber7_finally {
    static StringBuilder abc() {
        StringBuilder a = new StringBuilder("privet");
        try {
            File f = new File("test10.txt");
            FileInputStream fis = new FileInputStream(f);
        } catch (FileNotFoundException e) {
            System.out.println("Исключение поймано");
            System.out.println("Переменная в кэч блоке = "+a);
            return a;
        }
        finally {
            a.append("!!!");
            System.out.println("это файнали блок");
            System.out.println("Переменная в finally блоке = "+a);
        }
        return a;
    }

    public static void main(String[] args) {
        System.out.println(abc());

    }
}

