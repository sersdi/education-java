package Stepik.Lesson27_Исключения_Java_IO;

public class Nomber3_Throws_Exception {            //throws Exception означает что данный метод может выбросить исключения
    void abc() throws NullPointerException{         //для Runtime исключений можно не обьявлять и не обрабатывать но при желании можно.Тк они связаны с ошибками в коде программистом
        String s = null;
        System.out.println(s.length());
    }

    public static void main(String[] args) {
        int array[]={1,4,2};
        if(2>=0&&2<array.length){
            System.out.println(array[2]);
        }




    }


}
