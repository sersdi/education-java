package Stepik.Lesson27_Исключения_Java_IO;
import java.io.*;
public class Nomber2_Exeption_Try_Catch_Finally {
    void abc() throws FileNotFoundException{                  //Что бы не ловить возможную ошибку можем указать throws -можеет выкинуть ошибку предупреждаем
        File f = new File("test9.txt");
//        try {                                                   //try пытаемся выполнить какой то код
        FileInputStream fis = new FileInputStream(f);       //тут будет ошибка Тело трай завершается
//            fis.read();                                         //Когда работает с методом реад всегда ловим возможную ошибку IOException
        System.out.println("Всем хорошего дня");            //это не выводится тк ошибка
//        }
//        catch (FileNotFoundException e){                        //catch ловим ошибку   называем её e
//            System.out.println("Был пойман exeption "+ e);
//        }

    }
    void def(){                             //в другом методе если вызываем abc дублируем исключение (трай кэч) либо указываем на вылет программы без обработки исключений(Throws)
        System.out.println("privet");
        try{abc();}
        catch (IOException e){                      //IOException родитель FileNotFoundException
            System.out.println("Был пойман exception "+e);
            System.out.println(e.getMessage()); //методы которые можно использовать в исключениях
            e.printStackTrace();                //методы которые можно использовать в исключениях выводит путь ошибки
        }
    }

    public static void main(String[] args) {
        Nomber2_Exeption_Try_Catch_Finally t = new Nomber2_Exeption_Try_Catch_Finally();
//        try{
        t.def();
//        }
//        catch (FileNotFoundException e){
//            System.out.println("Был пойман exception "+e);
//        }



//        catch (IOException e){
//            System.out.println("Был пойман exeption "+e);
//        }
        //блок finally  не имеет отношения к исключениям        писать не обязательно (отдельно писать нельзя бех try catch)
//        finally {                                                //Всегда обрабатывается
//            System.out.println("Это finally блок");
//        }

        System.out.println("Данный код не имеет отношения к исключениям");      //продожения тела мэйн



    }



}
