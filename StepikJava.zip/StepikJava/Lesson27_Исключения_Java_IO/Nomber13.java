package Stepik.Lesson27_Исключения_Java_IO;
import java.io.*;
public class Nomber13 {
    static FileInputStream fis1,fis2;

    public static void main(String[] args) {
        try{
            fis1=new FileInputStream("test9.txt");
            System.out.println("файл тест9 сущ в системе и найден");
            try {
                fis2.close();       //будет ошибка тк fis2 ссылается на null а не на обьект и мы не можем закрыть то чего нет
            }
            catch (IOException e){
                System.out.println("Исключение поймано во внутрененм кэч блоке fis2 при закрытии потока");
            }
        }
        catch (FileNotFoundException e){
            System.out.println("Исключение поймано во внешнем кэч блоке fis1 такого файла не сущетсвует");

        }
        catch (NullPointerException e){
            System.out.println("Сработал наллпоинтерекзепш");

        }
    }
}
