package Stepik.Lesson27_Исключения_Java_IO;

public class Nomber14_CreateExeptions {
    void marafon(int temperatura,int tempBega) throws PodvernulNogu,SveloMiscuandPodvernulNogu {    //указываю ошибку тк чект
        if(temperatura>30&&tempBega<10){
            throw new SveloMiscu("Из за большой температуры у вас свело мышцу");
        }
        if (tempBega>10&&temperatura>30){
            throw new SveloMiscuandPodvernulNogu("Из за высокого темпа бега вы подвернули ногу и у вас свело мышцу");}

        if(tempBega>10&&temperatura<30){
            throw new PodvernulNogu("Из за высокого темпа бега вы подвернули ногу");

        }
        System.out.println("Вы пробежали марафон");
    }
    public static void main(String[] args)  throws PodvernulNogu,SveloMiscuandPodvernulNogu{
        Nomber14_CreateExeptions t = new Nomber14_CreateExeptions();
        try {
            t.marafon(43,59);
        }
        catch (SveloMiscuandPodvernulNogu e){
            System.out.println(e.getMessage());
        }
        catch(PodvernulNogu e){                             //чект исключение
            System.out.println(e.getMessage());

        }
        catch (SveloMiscu e){                               //обработал анчект для удобстава
            System.out.println(e.getMessage());
        }

        finally {
            System.out.println("В любом случае вы получите грамоту");
        }
    }
}
class PodvernulNogu extends Exception{      //чект экзепшн
    PodvernulNogu(String message){
        super(message);
    }
    PodvernulNogu(){}

}
class SveloMiscu extends RuntimeException{  //анчект экзепшн могу не обрабатывать и не писать в методе throws
    SveloMiscu(String message){
        super(message);
    }
    SveloMiscu(){}
}
class SveloMiscuandPodvernulNogu extends Exception {  //анчект экзепшн могу не обрабатывать и не писать в методе throws
    SveloMiscuandPodvernulNogu(String message) {
        super(message);
    }
    SveloMiscuandPodvernulNogu() {}
}
