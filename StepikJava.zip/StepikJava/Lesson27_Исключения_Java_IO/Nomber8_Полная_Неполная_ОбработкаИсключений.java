package Stepik.Lesson27_Исключения_Java_IO;

import java.io.*;

public class Nomber8_Полная_Неполная_ОбработкаИсключений {
    void abc() throws FileNotFoundException {       //указываем на ошибку тк в кэч выкидывали чек исключение
        try {
            File f = new File("test10.txt");
            FileInputStream fis = new FileInputStream(f);       //здесь ошибка может быть
        } catch (FileNotFoundException e) {
            System.out.println("Исключение поймано и немного обработано");
            throw e;        //ещё раз выкидываем ошибку тк он чекд исключение и указываем в сигнатуре метода по правилу ещё раз ешл полносью обрабатываем в дургом методе
        }
        finally {
            System.out.println("это файнали блок");
        }
    }
    void method(){
        try{abc();}                         //по правилу полностью обрабатываем в номом методе
        catch (FileNotFoundException e){
            System.out.println("исключение поймано и полностью обработано");
        }
    }

//    void def()    рантайм исключения не пишем в методе что выкидываем{
//        try {
//            int[]array = {1,2,3};
//            System.out.println(array[5]);
//        } catch (ArrayIndexOutOfBoundsException e) {
//            System.out.println("Исключение поймано и немного обработано");
//            throw e;
//        }
//        finally {
//            System.out.println("это файнали блок");
//
//        }
//
//    }
}


