package Stepik.Lesson27_Исключения_Java_IO;
import java.util.*;
public class Nomber15_RuntimeExceptions {
    static Doctor[]array = new Doctor[4];                    //длина массива 4(4 нала будет)
    public static void main(String[] args) {                                                         //Ошибки рантайм exceptions анчект
//    static ArrayList<String>list;                 //дефолт значение null
//        list.add("1");
//        list.add("2");
//        System.out.println(list.get(3));           ошибка IndexOutOfBoundsException
//        System.out.println(5/0);                   ошибка ArithmeticException

//        Doctor d = new Doctor();
//        Teacher t = new Teacher();
//        Teacher t3 = new Teacher();
//        Teacher[]array2 ={t,t3};
//        Employee[]array1 ={d,t};
//        Teacher t2 = (Teacher)array1[0];          //ошибка ClassCastException тк переменной типа тичер присваивем элемент арэй листа типа доктор
//        Doctor d2 =(Doctor)array2[0];             // тут будет чект исключение ошибка компиляции Тк в этом эрэйлисте нет переменный типа доктор а только тичеры

//        createPwd("qwertyфывфывывфывфывфывфывфыв"); //ошибка  IllegalArgumentException(создали своё исключение)

//        list.add("!!!!");                                 //NullPointerException будет исключение тк к налл доб стринг

//        System.out.println(array[0].toString());       // будет NullPointerException исключение тк на налл нельзя вызывать методы

//        Integer.parseInt("44op");                   //будет ошибка NumberFormatException Стринг не можем перевести в Integer
        Integer.parseInt("44ab",16);        //Стринг  можем перевести в Integer указали систему счисления
    }
    public static void createPwd(String pwd){            //если метод статик то не нужно создавать обьект в мейне что бы его вызвать
        if(pwd.length()<6){
            throw new IllegalArgumentException("Длина пароля слишком маленькая");       //IllegalArgumentException ошибка выбрасывается если параметр какой то не подходящий(используется при написании своих методов)
        }
        if(pwd.length()>12){
            throw new IllegalArgumentException("Длина пароля слишком большая");          //в этом исключении можем сразу прописывать свой месседж
        }
        System.out.println("Пароль принят");

    }
}
class Employee{}
class Doctor extends Employee{}
class Teacher extends Employee{}

class Samolet{
    String sostoyanie ="в ожидании";    //в ожиданнии, в воздухе ,полет отменен
    public void letet(){
        sostoyanie = "в воздухе";
        System.out.println("Самолёт летит");
    }
    public void Ojidat(){
        if(sostoyanie.equals("в воздухе")){
            throw new IllegalStateException("Самолёт уже в воздухе");
        }
        sostoyanie = "в ожидании";
        System.out.println("Самолёт в ожидании");
    }
    public void OtmenitPolet(){
        if(sostoyanie.equals("в воздухе")){
            throw new IllegalStateException("Самолёт уже в воздухе");
        }
        sostoyanie = "Полёт отменён";
        System.out.println("Полёт самолёта отменён");

    }
    public static void main(String[] args) {
        Samolet s = new Samolet();
        s.Ojidat();
        s.OtmenitPolet();
        s.letet();
        s.OtmenitPolet();       //будет ошибка IllegalStateException(если что то происходит не вовремя при создании своих методов) тк самолет уже летит


    }


}
