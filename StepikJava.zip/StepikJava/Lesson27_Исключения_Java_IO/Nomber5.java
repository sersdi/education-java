package Stepik.Lesson27_Исключения_Java_IO;
import java.io.*;
public class Nomber5 {
    public static void main(String[] args) {
        try {
            File f = new File("test9.txt");
            FileInputStream fis = new FileInputStream(f);
        }
//        catch(FileNotFoundException e){                           // иерархия исключений родители внизу иначе будет ошибка тк дочерний класс никогда не будет выполнен
//            System.out.println("Исключение поймано 1"+e);
//        }
//               catch(NullPointerException e){
//            System.out.println("Исключение поймано 2"+e);
//        }
//       catch(RuntimeException e){
//            System.out.println("Исключение поймано 3"+e);
//        }
//        catch(IOException e){
//            System.out.println("Исключение поймано 4"+e);
//        }
        catch(Exception e){
            System.out.println("Исключение поймано 4"+e);
        }
        catch(Throwable e){
            System.out.println("Исключение поймано 5"+e);
        }



    }
}
