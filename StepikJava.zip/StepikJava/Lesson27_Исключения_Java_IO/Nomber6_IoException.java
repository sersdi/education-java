package Stepik.Lesson27_Исключения_Java_IO;

import java.io.*;

public class Nomber6_IoException {
    public static void main(String[] args) {
        StringBuilder result = new StringBuilder("");
        try{
            File f = new File("Test9.txt");
            System.out.println("обьект создался");
            FileInputStream fis = new FileInputStream(f);   //FileNotFoundException если не будет файла
            System.out.println("поток создан");
            int counter =0;
            while(true){
                counter++;
                result.append(fis.read());
                System.out.println("Информация читается");
                if(counter==3){
                    fis.close();      //когда поток закроется вылезет ошибка тк прочитать не сможем IO Exception
                }

            }

        }

        catch (FileNotFoundException e){
            System.out.println("Исключение поймано 1 "+e);
        }
        catch (IOException e){
            System.out.println("Исключение поймано 2 "+e);
        }
        finally {           //В этом блоке как правило использует подчищающий код(например клоуз что бы закрыть все потоки)
            System.out.println("eto finally");
            System.out.println(result);
        }

    }
}
