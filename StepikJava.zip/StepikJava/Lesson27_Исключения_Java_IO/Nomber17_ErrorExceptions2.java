package Stepik.Lesson27_Исключения_Java_IO;

public class Nomber17_ErrorExceptions2 {
    void abc(){
        System.out.println("method abc");
        throw new StackOverflowError();                     //StackOverflowError
    }
    void def(){
        try {
            abc();      //не ловим ошибку
            return;
        }
        finally {
            System.out.println("файнали блок");
        }
    }

    public static void main(String[] args) {
        Nomber17_ErrorExceptions2 t = new Nomber17_ErrorExceptions2();
        t.def();
    }
}

