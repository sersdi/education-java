package Stepik.Lesson27_Исключения_Java_IO;
import java.io.*;
public class Nomber10_НесколькоTryCatch {
    FileInputStream fis1,fis2;  //2 обьекта типа fileinputstream
    public void abc(){
        try {                                                       //внешний  трай
            fis1 = new FileInputStream("test9.txt");
            System.out.println("Поток фис1 открыт");
            try {                                                  //внутренний трай
                fis2 = new FileInputStream("test10.txt");  //тут будет ошибка к нет такого файла
                System.out.println("Поток на фис2 открыт");
            } catch (FileNotFoundException e) {                     //внутренний кэч
                System.out.println("Исключение поймано в фис2 и поток не открылся");
            }
        }
        catch (FileNotFoundException e){                            //внешний кэч
            System.out.println("Исключенеи поймано в фис1 и поток не открылся");
        }
        finally {                                                    //всегда выполняется этот блок
            System.out.println("Это внешний файнали блок");
            try {                                                    //  закрываем потоки  в файнали
                fis1.close();                                       //когда закрываем потоки может вылести IOException поэтому поместили это в трай и ловип поотом кэчем
                System.out.println("Поток на фис1 закрыт");
                fis2.close();
                System.out.println("Поток на фис2 закрыт");
            } catch (IOException e) {
                System.out.println("исключение поймано в файнали блоке: " + e);
            }
        }

    }
    public static void main(String[] args) {
        Nomber10_НесколькоTryCatch t = new Nomber10_НесколькоTryCatch();
        t.abc();


    }


}
