package Stepik.Lesson27_Исключения_Java_IO;

public class Nomber4_Error {
    public static void abc(){
        System.out.println("Rabotat abc");
        abc();                              //рекурсия метод вызывает сам себя до бесконечности вылазит error
    }                                                   //такие error не нужно обрабатывать и указывать в throws это глупо
    public static void main(String[] args) {
        try{
            abc();
        }
        catch (StackOverflowError e){
            System.out.println("error poyman");
        }

    }

}
