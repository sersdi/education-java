package Stepik.Lesson27_Исключения_Java_IO;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

//JavaIO пакет в котором собраны классы и интерфейсы которые предназначены для чтения и записи информации из/в какой либо источник,например файл
//класс File абстрактная репрезентация пути к файлу или папке
//класс FileInputStream предназначен для создания потока с помощью которого можно читать информацию из источника
//класс FileOutputStream предназначен для создания потока с помощью которого можно писать информацию в источник

public class Nomber1_JavaIO_Potoki {
    public static void main(String[] args) throws Exception {       //throws Exception означает что данный метод может выбросить исключения
        File f = new File("test10.txt");       //создаём файл, в параметре название файла.(абстрактная репрезентация,если такого файла в папке нет,ошибка не вылезет) Ишет файл в папке с файлами джавы
        FileInputStream fis = new FileInputStream(f);   //создаём поток для чтения В параметре указываем файл  (На этом месте будет ошибка если файла такого в папке не будет)
        System.out.println("File naiden");
        fis.read();
        FileOutputStream fos = new FileOutputStream(f);         //создаём поток для редактирования В параметре указываем файл
        fos.write(100);                                     //в параметре 100 это чар (символ под номером 100)





    }

}
