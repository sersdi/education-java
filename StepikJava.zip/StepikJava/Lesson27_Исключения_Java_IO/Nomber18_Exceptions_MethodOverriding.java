package Stepik.Lesson27_Исключения_Java_IO;

import java.io.*;

public class Nomber18_Exceptions_MethodOverriding {
    public static void main(String[] args) {
        Animal18 a = new Mouse();
        try{                                    //заключаем в трай тк тип данных animal метод в animal выкидываем чект IOException поэтому обработали в try catch либо throws пишем в методе
            a.run();                            //вызовется метод ран из мауса тк переменная c типом данных animal ссылается на обьект типа маус
        }
        catch (IOException e){
            System.out.println("Exception пойман");
        }

    }
}
class Animal18{                                                  //IOException чект
    void run() throws IOException,ArrayIndexOutOfBoundsException {            //исключение в супер класса. ArrayIndexOutOfBoundsException-наследник IndexOutOfBoundsException Так можно писать в супер классе если это рантайм(анчект исключения)
        System.out.println("Animal runs");                              //если чект то нельзя что бы в супер классе был наследник а в оверайдинге родитель
    }
    void run(int a)throws Exception{            //оверлоадед методы выбрасывает любые исключения(Чект анчект)
        System.out.println("Animal runs");
    }


}
class Mouse extends Animal18{
    @Override
    void run() throws IndexOutOfBoundsException,NullPointerException {     //в оверайде могу указывать рантайм екзепшенеы либо чект исключения наследники супер класса исключения
        System.out.println("Mouse runs");
    }
}
