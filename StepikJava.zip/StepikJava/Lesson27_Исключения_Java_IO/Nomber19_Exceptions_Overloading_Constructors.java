package Stepik.Lesson27_Исключения_Java_IO;

import java.io.FileNotFoundException;
import java.io.IOException;

public class Nomber19_Exceptions_Overloading_Constructors {
    public static void main(String[] args) {
//        Animal19 a = new Mouse19();

    }
}
class Animal19{
    Animal19()throws FileNotFoundException, IndexOutOfBoundsException {} //IndexOutOfBoundsException анчект(рантаймисключение) для них рантаймов не нужно указывать в конструкторам наследниках такие же исключения

}
class Mouse19 extends Animal19{
Mouse19()throws Exception,IOException,ArrayIndexOutOfBoundsException{
    super();                                            //обращаемся к конструктуру супер класса(там FileNotFoundException чект исключение) поэтому указываем в констукторе класса throws FileNotFoundException
}                                                                       //либо указываем в throws родителей(IOException) тк он покроет исключение в конструкторе родителя
}
class Human{
    String name;
    int age;
    Human(String name,int age)throws Exception{
        if(age<0){
            throw new Exception("Некорректный возраст");
        }
        this.name = name;
        this.age = age;
    }
}

