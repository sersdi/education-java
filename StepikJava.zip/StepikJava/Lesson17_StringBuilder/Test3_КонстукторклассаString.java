package Stepik.Lesson17_StringBuilder;

public class Test3_КонстукторклассаString {
    public static void main(String[] args) {
        StringBuilder sb1 = new StringBuilder("Hello");
        String s1 = new String(sb1);    //параметр конструктора стринг исп стрингбилдер

        StringBuffer sb2 = new StringBuffer("Hello");        //StringBuffer = StringBuilder только для многопоточности
        String s2 = new String(sb2);    //параметр конструктора стринг исп стрингбилдер
    }
}
