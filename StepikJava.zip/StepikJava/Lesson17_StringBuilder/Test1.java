package Stepik.Lesson17_StringBuilder;
class Car{}   //добавляем класс

public class Test1 {
    public static void main(String[] args) {
        // StringBuilder является изменяемым классом(mutable)
        // что бы изменить обьект не нужно создавать новый, память используется меньше

        StringBuilder sb1 = new StringBuilder();                 // создаётся обьект пустой(вместимость массива по дефолту 16 символов
        StringBuilder sb2 = new StringBuilder("Good day!!!");    // создаётся обьект кол-во символов 11+16 = 24 символа вместимость
        StringBuilder sb3 = new StringBuilder(50);        // capacity тип данных int это вместимость создали обьект массив которого 50 символов
        StringBuilder sb4 = new StringBuilder(sb2);              // создаётся новый обьект содержимого которого такой же как у обьекта sb2

        System.out.println(sb3.length());                   // метод length выводит длину строки(int)
        System.out.println(sb2.charAt(4));                      //charAt выводит символ по индексу (char)
        System.out.println(sb2.indexOf("o",2));     //indexOf выводит индекс по строке если есть повторы то указываем с какого индекса считать
        String s = sb2.substring(5);               //substring выводит строку указываем откуда считать
        System.out.println(s);
        String s2 = sb2.substring(5,8);           //выводит строку указываем где начало и конец(конец в счёт не входит)
        System.out.println(s2);

        System.out.println(sb2.subSequence(5,8)); //subSequence =substring(только выводит последовательность символов(char) а не строку)

//        sb2.append(22);             //append  в конец стрингбилдера добавляет значения(ввод dataType,вывод StringBuilder) Метод меняет сам стрингбилдер
//        sb2.append(true);              //append(любой тип данных)
//        System.out.println(sb2);
//        sb2.append(sb2);
//        System.out.println(sb2);
//        sb2.append(new Car());    // добавляем к сб2 класс Car его можно вихуализировать если переписать метод тустринг
//        System.out.println(sb2);

        System.out.println(sb2.insert(sb2.length(), 55));  //insert добавляет в стрингбилдер любой тип данных указываем где именно(индекс либо длина(тк int))
                                                                //insert = append но расширенный
        StringBuilder sb10 = new StringBuilder("Hello World");
//        sb10.delete(3,6);                                          //delete удаляет символы по индексам последний не входит Выводит стрингбилдер На входе инт
//        System.out.println(sb10);
        sb10.deleteCharAt(0);             //deleteCharAt удаляет символ по индексу Выводит стринг билдер(меняет его)
        System.out.println(sb10);
        sb10.reverse();                         //reverse переворачивает стринг билдер(меняет его)
        System.out.println(sb10);

        StringBuilder sb12 = new StringBuilder("Vsem privet");
        sb12.replace(0,5,"Pete");         //Меняет по индексам отрезок стрингБилдера
        System.out.println(sb12);
        System.out.println(sb12.capacity());     //capacity вместимость 16 по дефолту+ что мы ввели в стрингбилдер


        
    }
}
