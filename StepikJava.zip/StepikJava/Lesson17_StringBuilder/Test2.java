package Stepik.Lesson17_StringBuilder;

public class Test2 {
    public static void main(String[] args) {
        StringBuilder sb1 = new StringBuilder("123");
        StringBuilder sb2 = new StringBuilder("123");
        StringBuilder sb3 = sb1;
 //       StringBuilder sb2 = sb1.append("45");
 //       sb2=sb2.append("6").append("7");
 //       System.out.println(sb1);  // sb1 1234567
 //       System.out.println(sb2);     //sb2 1234567 потому что мы приравняли sb2 к sb1 а методы меняли и его тоже
        System.out.println(sb1.equals(sb3));      // в классе StringBuilder equals не перезаписан а такойже ==
                                                        //поэтому что бы обьекты ссылались на один и тот же мы их должны приравнять
    }
}
