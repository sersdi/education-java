package Stepik.Lesson17_StringBuilder;

public class HomeWork1 {
    public Boolean raventsvo (StringBuilder sb1, StringBuilder sb2) {
        boolean result = true;
        if (sb1.length() == sb2.length()) {
            for (int i = 0; i < sb1.length(); i++) {
                if (sb1.charAt(i) == sb2.charAt(i)) {
                    result = true;
                    break;
                }
            }
        }
        else {result = false;}
        return result;
    }

    public static void main(String[] args) {
        StringBuilder sb1 = new StringBuilder("privet");
        StringBuilder sb2 = new StringBuilder("privet");

        HomeWork1 h1 = new HomeWork1();
        System.out.println(h1.raventsvo(sb1,sb2));
    }
}
