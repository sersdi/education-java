package Stepik.Lesson29_Лямбда_выражения;

import java.util.ArrayList;
import java.util.function.*;

//                                                          Interface Predicate<T>
//лямбда выражения работают с интерфейсом в котором есть только 1 метод
//Такие интерфейсы называются функциолнальными
//интерфейс Predicate<T> находится в java.util.function
//

//public interface Predicate<T>{
//boolean test(T t);
// }
//

public class Nomber5_InterfacePredicate_T_ {
}
class Student5{
    String name;
    char sex;
    int age;
    int course;
    double avgGrade;
    Student5(String name,char sex,int age,int course,double avgGrade){
        this.name = name;
        this.sex = sex;
        this.age = age;
        this.course = course;
        this.avgGrade = avgGrade;
    }
}
class StudentInfo5 {
    void printStudent(Student5 st) {
        System.out.println("Name:" + st.name + " Sex:" + st.sex + " Age:" + st.age + " Course:" + st.course + " AvgGrade:" + st.avgGrade);
    }

    void testStudents(ArrayList<Student5> al, Predicate<Student5> t){   //используем интерфейс джавы доб его в метод
        for(Student5 s:al){
            if(t.test(s)){
                printStudent(s);
            }
        }
    }
    public static void main(String[] args) {
        ArrayList<Student5> list = new ArrayList<>();
        Student5 st1 = new Student5("Ivan", 'm', 22, 2, 6.5);
        Student5 st2 = new Student5("Sergey", 'm', 19, 3, 3.5);
        Student5 st3 = new Student5("Katya", 'f', 25, 1, 8.5);
        Student5 st4 = new Student5("Petya", 'm', 24, 1, 4.5);
        Student5 st5 = new Student5("Masha", 'f', 18, 2, 2.5);
        list.add(st1);
        list.add(st2);
        list.add(st3);
        list.add(st4);
        list.add(st5);
        StudentInfo5 si = new StudentInfo5();
        for(Student5 s:list){
            System.out.println(s.name);
        }
        System.out.println("-------------");
        list.removeIf(x->x.name.endsWith("a"));   //метод list.removeIf для списков
        for(Student5 s:list){
            System.out.println(s.name);
        }

//        si.testStudents(list,  st->{int z =5; return st.avgGrade>4.2;}  );      //лямбда выражение В параметре указываем если обьект st принадлежит студенту3 то перезаписываем метод test и возвращаем булиан при avgGrade>4.2 выводим этих студентов
//        System.out.println();
//        si.testStudents(list, (Student5 st)->st.avgGrade<3);         //смешанное написание лямбда выражения
//        System.out.println();
//        si.testStudents(list,(Student5 st)->{return st.sex=='m';});  //полный вариант написания      // при тру выводит этих студентов у которых параметр подходит
//        System.out.println();
    }
}



