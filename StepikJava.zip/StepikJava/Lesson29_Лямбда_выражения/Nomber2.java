package Stepik.Lesson29_Лямбда_выражения;
import java.util.ArrayList;
public class Nomber2 {
}
class Student2{
    String name;
    char sex;
    int age;
    int course;
    double avgGrade;
    Student2(String name,char sex,int age,int course,double avgGrade){
        this.name = name;
        this.sex = sex;
        this.age = age;
        this.course = course;
        this.avgGrade = avgGrade;
    }
}
class StudentInfo2 {
    void printStudent(Student2 st) {        //1 метод
        System.out.println("Name:" + st.name + " Sex:" + st.sex + " Age:" + st.age + " Course:" + st.course + " AvgGrade:" + st.avgGrade);
    }

    void testStudents(ArrayList<Student2>al,StudentChecks sc){      //2метод включает в себя 1
        for(Student2 s:al){                     //идём по списку
            if(sc.test(s)){                     //обращаемся к классам которые перезаписали метод test из interface
                printStudent(s);                //выводим через метод  printStudent студента
            }
        }
    }
    public static void main(String[] args) {
        ArrayList<Student2> list = new ArrayList<>();
        Student2 st1 = new Student2("Ivan", 'm', 22, 2, 6.5);
        Student2 st2 = new Student2("Sergey", 'm', 19, 3, 3.5);
        Student2 st3 = new Student2("Katya", 'f', 25, 1, 8.5);
        Student2 st4 = new Student2("Petya", 'm', 24, 1, 4.5);
        Student2 st5 = new Student2("Masha", 'f', 18, 2, 2.5);
        list.add(st1);
        list.add(st2);
        list.add(st3);
        list.add(st4);
        list.add(st5);

        StudentInfo2 si = new StudentInfo2();
        FindStudentsOverGrade fsog = new FindStudentsOverGrade();
        si.testStudents(list,fsog);
        System.out.println();
        FindStudentsOverAge fsoa = new FindStudentsOverAge();
        si.testStudents(list,fsoa);
        System.out.println();
        FindStudentsUnderAge fsua = new FindStudentsUnderAge();
        si.testStudents(list,fsua);
        System.out.println();


    }
}
interface StudentChecks{                        //создали интерфейс
    boolean test(Student2 s);      //булиан абстрактный метод если обьект принадлежит Studenty2 то тру
}
class FindStudentsOverGrade implements StudentChecks{       //класс который перезаписывает метод из интерфейса
    @Override
    public boolean test(Student2 s) {
        return s.avgGrade>5.5;
    }
}
class FindStudentsOverAge implements StudentChecks{       //класс который перезаписывает метод из интерфейса
    @Override
    public boolean test(Student2 s) {
        return s.age>20;
    }
}
class FindStudentsUnderAge implements StudentChecks{       //класс который перезаписывает метод из интерфейса
    @Override
    public boolean test(Student2 s) {
        return s.age<20;
    }
}
