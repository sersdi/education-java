package Stepik.Lesson29_Лямбда_выражения;
import java.util.ArrayList;
public class Nomber3_ЛямбдаВыражения {
}
class Student3{
    String name;
    char sex;
    int age;
    int course;
    double avgGrade;
    Student3(String name,char sex,int age,int course,double avgGrade){
        this.name = name;
        this.sex = sex;
        this.age = age;
        this.course = course;
        this.avgGrade = avgGrade;
    }
}
class StudentInfo3 {
    void printStudent(Student3 st) {                                  //1 метод
        System.out.println("Name:" + st.name + " Sex:" + st.sex + " Age:" + st.age + " Course:" + st.course + " AvgGrade:" + st.avgGrade);
    }

    void testStudents(ArrayList<Student3>al,StudentChecks3 sc){      //2метод включает в себя 1
        for(Student3 s:al){                     //идём по списку
            if(sc.test(s)){                     //если булиан тру(Через обьект интерфейса обращаемся к методу тест(В методе тест если обьект принадлежит студенту то булиан тру) )
                printStudent(s);                //выводим через метод  printStudent студента(Если после булиана тру то выводим этого студента)
            }
        }
    }
    public static void main(String[] args) {
        ArrayList<Student3> list = new ArrayList<>();
        Student3 st1 = new Student3("Ivan", 'm', 22, 2, 6.5);
        Student3 st2 = new Student3("Sergey", 'm', 19, 3, 3.5);
        Student3 st3 = new Student3("Katya", 'f', 25, 1, 8.5);
        Student3 st4 = new Student3("Petya", 'm', 24, 1, 4.5);
        Student3 st5 = new Student3("Masha", 'f', 18, 2, 2.5);
        list.add(st1);
        list.add(st2);
        list.add(st3);
        list.add(st4);
        list.add(st5);
        StudentInfo3 si = new StudentInfo3();

        si.testStudents(list,  st->{int z =5; return st.avgGrade>4.2;}  );      //лямбда выражение В параметре указываем если обьект st принадлежит студенту3 то перезаписываем метод test и возвращаем булиан при avgGrade>4.2 выводим этих студентов
        System.out.println();
        si.testStudents(list, (Student3 st)->st.avgGrade<3);         //смешанное написание лямбда выражения
        System.out.println();
        si.testStudents(list,(Student3 st)->{return st.sex=='m';});  //полный вариант написания      // при тру выводит этих студентов у которых параметр подходит
        System.out.println();
    }
}
interface StudentChecks3{          //создали интерфейс
    boolean test(Student3 s);      //булиан абстрактный метод если обьект принадлежит Studenty2 то тру
}


