package Stepik.Lesson29_Лямбда_выражения;
//lambda expressions:
//def( ()->5);
//def( (x)->x.length() );
//def( (String x)->x.length() );
//def( (x,y)->x.length());
//def( (String x,String y)->x.length());

//method( (int x,int y)->{int x=5;return10} );

public class Nomber4 {

//    void method1(int a){
//        int a =5; ошибка 2 а
//    }

    static void def(Test5 t){
        System.out.println(t.abc("privet"));
    }

    public static void main(String[] args) {
        def(x->{x="ok"; return x.length();} );                         //при помощи лямбды указываю в параметре стринг x и перезаписываем метод abc так что бы возвращал длину стринга

    }
}
interface Test5{
    int abc(String s1);                              //абстрактный метод в параметре стринг возвращает int
}

