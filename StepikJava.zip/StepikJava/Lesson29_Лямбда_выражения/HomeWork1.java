package Stepik.Lesson29_Лямбда_выражения;

import java.util.ArrayList;
import java.util.function.Predicate;

public class HomeWork1 {
}

class Employee{
    String name;
    String department;
    int salary;
    Employee(String name,String department,int salary){     //конструктор работника
        this.name=name;
        this.department = department;
        this.salary =salary;
    }

}

class TestEmployee{
    void printEmployee(Employee e){
        System.out.println("Имя работника:"+e.name+" Отдел работника:"+e.department+" Зарплата работника:"+e.salary);
    }
    void filtraciyaRabotnikov(ArrayList<Employee>al,Predicate<Employee>test){    //использую интерфэйс  Predicate от джавы для написания такого кородкого кода
        for(Employee e:al){
            if(test.test(e)){
                printEmployee(e);
            }
        }

    }
    public static void main(String[] args) {
        ArrayList<Employee>list = new ArrayList<>();

        Employee emp1 = new Employee("Sergey   ","IT",12000);
        Employee emp2 = new Employee("Alex     ","HR",50000);
        Employee emp3 = new Employee("Kolya    ","HR",45530);
        Employee emp4 = new Employee("Sasha    ","IT",25000);
        Employee emp5 = new Employee("Ekaterina","IT",768000);
        Employee emp6 = new Employee("Katya    ","HR",100000);
        list.add(emp1);
        list.add(emp2);
        list.add(emp3);
        list.add(emp4);
        list.add(emp5);
        list.add(emp6);

        TestEmployee te = new TestEmployee();
        te.filtraciyaRabotnikov(list, x->{return x.department.equals("IT") && x.salary>200;});
        System.out.println("---------");
        te.filtraciyaRabotnikov(list, x->{return x.name.startsWith("E") && x.salary!=450;});
        System.out.println("---------");
        te.filtraciyaRabotnikov(list, x->{return x.name.equals(x.department);});
        System.out.println("---------");








    }
}


