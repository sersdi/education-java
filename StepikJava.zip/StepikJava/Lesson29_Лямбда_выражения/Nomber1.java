package Stepik.Lesson29_Лямбда_выражения;
import java.util.ArrayList;

public class Nomber1 {
}
class Student{
    String name;
    char sex;
    int age;
    int course;
    double avgGrade;
    Student(String name,char sex,int age,int course,double avgGrade){
        this.name = name;
        this.sex = sex;
        this.age = age;
        this.course = course;
        this.avgGrade = avgGrade;
    }
}
class StudentInfo{
    void printStudent(Student st){
        System.out.println("Name:"+st.name+" Sex:"+st.sex+" Age:"+st.age+" Course:"+st.course+" AvgGrade:"+st.avgGrade);
    }
    void printStudentOverGrade(ArrayList<Student>al,double avgGrade){
        for(Student s:al){
            if(s.avgGrade>avgGrade){
                printStudent(s);
            }
        }
    }
    void printStudentUnderGrade(ArrayList<Student>al,double avgGrade){
        for(Student s:al){
            if(s.avgGrade<avgGrade){
                printStudent(s);
            }
        }
    }
    void printStudentOverAge(ArrayList<Student>al,int age) {
        for (Student s : al) {
            if (s.age > age) {
                printStudent(s);
            }
        }
    }
    void printStudentUnderAge(ArrayList<Student>al,int age) {
        for (Student s : al) {
            if (s.age < age) {
                printStudent(s);
            }
        }
    }
    void printStudentBySex(ArrayList<Student>al,char sex) {
        for (Student s : al) {
            if (s.sex == sex) {
                printStudent(s);
            }
        }
    }
    void printStudentMixConditions(ArrayList<Student>al,double avgGrade,int age,char sex) {
        for (Student s : al) {
            if (s.avgGrade>avgGrade&&s.age<age&&s.sex==sex) {
                printStudent(s);
            }
        }
    }
    public static void main(String[] args) {
        ArrayList<Student>list=new ArrayList<>();
        Student st1 = new Student("Ivan",'m',22,2,6.5);
        Student st2 = new Student("Sergey",'m',19,3,3.5);
        Student st3 = new Student("Katya",'f',25,1,8.5);
        Student st4 = new Student("Petya",'m',24,1,4.5);
        Student st5 = new Student("Masha",'f',18,2,2.5);
        list.add(st1);
        list.add(st2);
        list.add(st3);
        list.add(st4);
        list.add(st5);
        StudentInfo si = new StudentInfo();
        si.printStudentOverGrade(list,5.0);
        System.out.println();
        si.printStudentUnderGrade(list,5.0);
        System.out.println();
        si.printStudentOverAge(list,20);
        System.out.println();
        si.printStudentUnderAge(list,20);
        System.out.println();
        si.printStudentBySex(list,'m');
        System.out.println();
        si.printStudentMixConditions(list,1.2,25,'f');
        System.out.println();







    }





}
