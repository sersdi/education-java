package Stepik.Lesson14_LoopFor_break_continue;

public class nomber4 {
    public static void main(String[] args) {
        int a = 15;

        if(a > 10){
            for(int i = 1;i<=10;i++){
                System.out.println(i);
            }

        }


    }
}
