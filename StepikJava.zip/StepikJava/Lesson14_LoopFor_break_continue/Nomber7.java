package Stepik.Lesson14_LoopFor_break_continue;

public class Nomber7 {
    public static void main(String[] args) {
        for(; ;){System.out.println("Privet");}    //мин цикл бесконечный
    }
}
