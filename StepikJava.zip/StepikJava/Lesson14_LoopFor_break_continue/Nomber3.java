package Stepik.Lesson14_LoopFor_break_continue;

public class Nomber3 {
    public static void main(String[] args) {
        for(int i = 2; i<=30;i=i+2){      //выводим четные числа
            System.out.println(i);
        }

    }
}
