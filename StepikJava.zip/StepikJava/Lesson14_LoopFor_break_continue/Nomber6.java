package Stepik.Lesson14_LoopFor_break_continue;

public class Nomber6 {
    public void time() {

        OUTER:
        for(int chas=0;chas<=23;chas++){                //внешний цикл
            System.out.println("nachalo outer loopa");
            INNER:
            for(int minuta=0;minuta<=59;minuta++){//внутренний цикл
                if(minuta==20){continue OUTER;}   // пропускаем когда минута 30   continue OUTER0-переходим во внешний цикл
                if(minuta==30){break;}          // break - останавливаем inner
                System.out.println(chas+":"+minuta);
            }
            System.out.println("Konec outer loopa");

        }

    }
    public static void main(String[] args) {
        Nomber6 t = new Nomber6();
        t.time();
    }
}
