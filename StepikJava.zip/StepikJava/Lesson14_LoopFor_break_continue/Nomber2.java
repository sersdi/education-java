package Stepik.Lesson14_LoopFor_break_continue;

public class Nomber2 {
    public static void main(String[] args) {
        for(int i = 5; i<11; ){           //локальные переменные видны только внутри цикла
            System.out.println(i);
            i++;
            abc(10);
        }
    }
    static void abc(int n){
        System.out.println(n + " method");
    }

}
