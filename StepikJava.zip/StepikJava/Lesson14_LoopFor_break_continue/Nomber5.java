package Stepik.Lesson14_LoopFor_break_continue;

public class Nomber5 {
    public static void main(String[] args) {
        for(int i = 1;i<=100;i++){
            if(i==10){
                continue;   // пропускаем следущие команды и переходим на новый круг выполнения
            }
            if (i%55==0){
                break;
            }

            System.out.println(i);
        }

    }
}
