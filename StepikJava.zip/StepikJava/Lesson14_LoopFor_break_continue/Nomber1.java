package Stepik.Lesson14_LoopFor_break_continue;

public class Nomber1 {
    public static void main(String[] args) {
        for (int i = 1; i <= 10; i++) {
            System.out.println("Java");
        }
    }

}
