package Stepik.Обьекты_конструктор;

public class Nomber1 {
// создаём метод                                            Access modifier(public)+ Non-access modifier(static) + return type(void) + name(main) + parameters(String[] args) + body{our code}
    //шаблон
    int summa(int a, int b, int c) {            //return type(int) +name(summa) + parameters(int a int b int c)(сам метод)
        int result = a + b + c;                     // тело(что делает)
        return result;                                      // output(result) заканчивается всегда на output
    }
// метод внутри метода
    int sredneeArifm(int a1, int b1, int c1) {
        int result2 = summa(a1,b1,c1)/3;
        return result2;

    }

}

//как вызывать метод:

class Nomber2{                                                      // созд класс
    public static void main (String[] args){                        //метод main
        Nomber1 t = new Nomber1();                                      //конструктор всегда называется также как и класс            //создаем обьект класса Nomber1(тк метод принадлежит такому классу)
        int summaTrexChisel = t.summa(1,2,3);                   //создаем переменную которой присваеваем значение метода через обьект
        System.out.println(summaTrexChisel);                        //выводим на экран
        System.out.println(t.summa(5,10,15));               // второй вариант вывода без создания переменной

        System.out.println(t.sredneeArifm(20,40,60));
    }

}




