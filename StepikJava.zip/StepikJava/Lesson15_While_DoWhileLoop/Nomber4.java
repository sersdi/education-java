package Stepik.Lesson15_While_DoWhileLoop;

public class Nomber4 {
    public static void main(String[] args) {
        int a = 5;//6 7 8 9 10 11 12(a++)    мы увеличиваем а на 2 после провоерки
        while (a++ < 10){    // если один стейтмен то можно не писать фигурные скобки
            a++;
        }
        System.out.println(a);


    }
}
