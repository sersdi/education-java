package Stepik.Lesson15_While_DoWhileLoop;

public class Nomber5 {
    public static void main(String[] args) {
        int a = 5;
        while (a < 10){         //бесконенечный цикл
            System.out.println("poka");
            }
        System.out.println("privet");


    }
}
