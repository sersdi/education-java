package Stepik.Lesson15_While_DoWhileLoop;

public class Nomber1 {
    public static void main(String[] args) {
        int i  = 10;
        int b = 0;
        while(i<20){
            b++;
            System.out.println(b);
            i++;


        }

    }
}
