package Stepik.Lesson15_While_DoWhileLoop;

public class doWhile2 {
    public static void main(String[] args) {
        int money = 100;
        System.out.println("На счёте:"+money);
        do{
            System.out.println("delyte stavky");;
            System.out.println("vi lose");
            money-=10;
            System.out.println("ostatok:"+money);

        }
        while(money>50);

    }
}
