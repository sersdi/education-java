package Stepik.Lesson15_While_DoWhileLoop;

public class doWhile3 {
    public static void main(String[] args) {

        do {
            System.out.println("sdasd");
        }
        while(true);
    }
}
