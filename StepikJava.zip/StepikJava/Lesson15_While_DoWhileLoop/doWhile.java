package Stepik.Lesson15_While_DoWhileLoop;

public class doWhile {
    public static void main(String[] args) {
        int a = 1;
        do{
            System.out.println(a);
            a++;
        }
        while (a==10);
    }
}
