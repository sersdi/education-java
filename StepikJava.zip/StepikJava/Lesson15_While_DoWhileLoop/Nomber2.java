package Stepik.Lesson15_While_DoWhileLoop;

public class Nomber2 {
    public static void main(String[] args) {
        int money = 100;
        System.out.println(money);
        while (money>0){
            System.out.println("Делайте ставку!");
            System.out.println("Вы проиграли");
            money = money-10;
            System.out.println("Осталось:" + money);
        }
    }
}
