package Stepik.Перегрузка_методов;

public class MethodOverloading {        // перегрузка методы с одинаковым названием но с разными параметрами
    void show(int i1){
        System.out.println(i1);
        System.out.println("Data type is int");

    }

    void show(String s1){
        System.out.println(s1);
        System.out.println("Data type is String");
    }

    void show(boolean b1){
        System.out.println(b1);
        System.out.println("Data type is boolean");

    }

    void show(int i, String s){
        System.out.println("Int:" + i + " " + "String:" + s);

    }

    void show(String s, int i){
        System.out.println("Какой хороший день");

    }
}

class MethodOveloadingTest{
    public static void main(String[] args){
        MethodOverloading mO = new MethodOverloading();
        int a = 15;
        mO.show(a);

        String privet;
        mO.show("privet");

        boolean b1 = true;
        mO.show(b1);

        mO.show(15, "Poka");
        mO.show("Poka", 15);
    }
}