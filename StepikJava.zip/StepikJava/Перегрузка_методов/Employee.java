package Stepik.Перегрузка_методов;

public class Employee {
    //создаю конструкторы название конструктора это название класса
    Employee(int id2, String surname2, int age2) {
        this(id2, surname2, age2, 0.0, null);           // параметры конструктора в котором больше всего переменных(которых нет мы присваиваем дефолтные значения)

    }
    Employee(String surname3, int age3){
        this(0, surname3, age3, 0.0, null);

    }
    Employee(int id4, String surname4, int age4, double salary4, String department4){
        id = id4;                                                      //this(вызывает конструктор в конструкторе его оверлоадед конструкторы) всегда на первом месте в теле конструктора
        surname = surname4;
        age = age4;
        salary = salary4;
        department = department4;
    }
    //вводил переменные для конструкторов
    int id;
    String surname;
    int age;
    String department;
    double salary;
}

class EmployeeTest{
    public static void main(String[] args){
        Employee r1 = new Employee(1,"Petrov", 34);
        System.out.println(r1.id + " " +  r1.surname);

        Employee r2 = new Employee("Ivanov", 21);
        System.out.println(r2.age + " " +  r2.surname);

        Employee r3 = new Employee(2, "Sidorov", 22, 352.5, "Java-JuniorDeveloper");
        System.out.print(r3.id + "." + r3.surname + "." + r3.age + "." + r3.salary + "." +  r3.department);

    }

}
