package Stepik.Перегрузка_методов;

public class Homework1 {   //методы
     int summ(int a, int b, int c, int d){
         return a+b+c+d;
    }

     int summ(int a, int b, int c){
        return summ(a,b,c,0);
    }

     int summ(int a, int b){
        return summ(a,b,0,0);
    }

     int summ(int a){
        return summ(a,0,0,0);
    }

     int summ(){
        return 0;
    }
    int a, b, c, d;
}

class HomeWorkTest{
    public static void main(String[] args){
        Homework1 res1 = new Homework1();
        System.out.println(res1.summ(1,2,3,4));

        Homework1 res2 = new Homework1();
        System.out.println(res2.summ(1,2,3));

        Homework1 res3 = new Homework1();
        System.out.println(res3.summ(1,2));

        Homework1 res4 = new Homework1();
        System.out.println(res4.summ(1));

        Homework1 res5 = new Homework1();
        System.out.println(res5.summ());

    }
}
