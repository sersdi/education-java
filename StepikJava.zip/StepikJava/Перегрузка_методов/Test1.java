package Stepik.Перегрузка_методов;

public class Test1 {
    // создаю методы
    int summ(int a, int b, int c){
        return a + b + c;
    }
    // метод внутри тругого обращаемся к методу summ
    int SredArifm(int x, int y, int z){
        return summ(x, y, z)/3;
    }




}
