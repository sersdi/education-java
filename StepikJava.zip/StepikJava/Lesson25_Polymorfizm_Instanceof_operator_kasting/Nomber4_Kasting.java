package Stepik.Lesson25_Polymorfizm_Instanceof_operator_kasting;

                                            //Casting это процесс когда мы заставляем переменную одного типа данных вести себя как перееменную другого типа данных
                                            //он возможен только когда между классами/иинтерфейсам сущ IS-A взаимотношение
                                            //Делая cаsting мы не меняем тип данныъ обьекта а заставляем его чуствовать себя как обьект другого типа данных

public class Nomber4_Kasting {
    public static void main(String[] args) {
        HelpAble h = new Doctor4();
        Employee4 emp1 = new Doctor4();
        Employee4 emp2 = new Teacher4();       //автоматический кастинг(апкастинг) переменную сслыаем на обьект другого типа данных
        Employee4 emp3 = new Driver4();
        Employee4 emp4 = new Employee4();
        Employee4[]array={emp1,emp2,emp3,emp4};
        for(Employee4 e:array){
            if(e instanceof Driver4){
                System.out.println(((Driver4) e).machina);
                ((Driver4) e).vodit();
            }
        }


//        Employee4 e = new Employee4();
//        Doctor4 d1 = (Doctor4)emp1;//   (даункастинг)  делаем кастинг что бы через  Емплои емп1 обратиться к переменной класса доктор специализация,
                                    //           говорим компилятору что emp1 ссылается на обьект типа доктор(а не иплои как в условии),
                                     //           в()скобках указывается тип данных переменной.
//        h.help();
//        System.out.println(((Doctor4)h).specializacia);
//        System.out.println(((Doctor4)emp1).specializacia);
//        ((Doctor4)h).lechit();
//        ((Doctor4)emp1).help();
//        System.out.println(e==emp1);  //сравниваем 2 обьекта(ссылки на обьекты) (ссылки на обьекты могут быть одинаковые)
    }
}
class Employee4{
    double salary =100;
    String name="Kolya";
    int age;
    int experiance;
    void eat(){System.out.println("Kushat");}
    void sleep(){System.out.println("Spat");}
}
class Doctor4 extends Employee4 implements HelpAble {
    String specializacia = "xirurg";
    void lechit(){
        System.out.println("Lechit");}
    @Override
    public void help() {System.out.println("Доктор лечит");}
}
class Teacher4 extends Employee4 {
    int kids;
    void uchit(){System.out.println("Uchit");}
}
class Driver4 extends Employee4 {
    String machina = "bmw";
    void vodit(){System.out.println("Vodit");}
}

interface HelpAble{
    void help();
}
