package Stepik.Lesson25_Polymorfizm_Instanceof_operator_kasting;

public class Nomber10 {
}
class Test1 implements interface1,interface2{
    public void abc(){
        System.out.println("ok");
    }

    public static void main(String[] args) {
        Test1 t = new Test1();
        ((interface1)t).abc();  //выведет всё равно ok  тк обьект типа Test1
        System.out.println(((interface1)t).a);      //используем кастинг
    }
}
interface interface1{
    int a =5;
    void abc();
}
interface interface2{
    int a = 10;
    void abc();
}
