package Stepik.Lesson25_Polymorfizm_Instanceof_operator_kasting;

public class HomeWork1 {
    public static void main(String[] args) {
        Animal1 a1 = new Mechenosec("Animal1 Mechenosec");
        Animal1 a2 = new Pingvin("Animal1 pingvin");
        Animal1 a3 = new Lev("Animal1 lev");

        Fish1 f1 = new Mechenosec("Fish1 меченосец");
        Mammal1 ma1 = new Lev("Mammal1  лев");
        Bird1 b1 = new Pingvin("Bird1 пингвин");

        Mechenosec m1 = new Mechenosec("Mechenosec меченосец");
        Lev l1 = new Lev("Lev лев");
        Pingvin p1 = new Pingvin("Pingvin пингвин");

        SpeakAble s1 = new Pingvin("SpeakAble Pingvin");
        SpeakAble s2 = new Lev("SpeakAble Lev");

        Animal1[]array1={a1,a2,a3,f1,ma1,b1,m1,l1,p1};
        SpeakAble[]array2={ma1,b1,l1,p1,s1,s2};

        for(Animal1 a:array1){
            if (a instanceof Mechenosec) {
                Mechenosec m = (Mechenosec)a;
                System.out.println(m.name);
                m.swim();
                m.eat();
                m.sleep();
                System.out.println();
            }
            else if (a instanceof Lev) {
                Lev l = (Lev)a;
                System.out.println(a.name);
                l.sleep();
                l.eat();
                l.speak();
                l.run();
                System.out.println();
            }
            else if (a instanceof Pingvin) {
                Pingvin p = (Pingvin)a;
                System.out.println(p.name);
                p.fly();
                p.eat();
                p.speak();
                p.sleep();
                System.out.println();
            }
        }
        for(SpeakAble s:array2){
            if(s instanceof Pingvin){
                Pingvin p = (Pingvin) s;
                System.out.println(p.name);
                p.eat();
                p.speak();
                p.fly();
                p.sleep();
                System.out.println();
            }
            else if (s instanceof Lev) {
                Lev l = (Lev)s;
                System.out.println(l.name);
                l.run();
                l.speak();
                l.eat();
                l.sleep();
                System.out.println();
            }
        }
    }
}
abstract class Animal1{
    String name;
    Animal1(String name) {
        this.name = name;
    }
    abstract void eat();
    abstract void sleep();
}
abstract class Fish1 extends Animal1 {
    Fish1(String name) {
        super(name);                        //передаем значение переменной в конструктор супер класса
        this.name = name;
    }
    public void sleep() {
        System.out.println("vsegda interesno nabludat kak spyat ribi");
    }
    abstract void swim();
}
class Mechenosec extends Fish1 {
    Mechenosec(String name) {
        super(name);
    }
    public void swim() {
        System.out.println("mechenosec bistro plavat");
    }
    public void eat() {
        System.out.println("Mechenosec ne xichnik,est ribiy korm");
    }
}

abstract class Bird1 extends Animal1 implements SpeakAble {
    Bird1(String name) {
        super(name);
        this.name = name;
    }
    abstract void fly();
    @Override
    public void speak() {System.out.println(name + " speaks");}
}
class Pingvin extends Bird1 {
    Pingvin(String name) {
        super(name);
        this.name = name;
    }
    public void eat() {
        System.out.println("Pingvin lubit est riby");
    }
    public void sleep() {
        System.out.println("Pingvini spyat prijavhis k drug drugu");
    }
    public void fly() {
        System.out.println("Pingvin ne letayut");
    }
    public void speak() {
        System.out.println("Pingvin cant sing");
    }
}

abstract class Mammal1 extends Animal1 implements SpeakAble {
    Mammal1(String name) {
        super(name);
        this.name = name;
    }
    abstract void run();
}
class Lev extends Mammal1 {
    Lev(String name){
        super(name);
        this.name = name;
    }
    public void sleep(){
        System.out.println("Lev spit ves den");
    }
    public void eat(){
        System.out.println("Lev est myaso");
    }
    public void run(){
        System.out.println("Lev ne samaya bistraya koska");
    }
    public void speak(){
        System.out.println("Mammal richit");
    }
}
interface SpeakAble {
    default void speak() {System.out.println("Somebody speaks");}
}


