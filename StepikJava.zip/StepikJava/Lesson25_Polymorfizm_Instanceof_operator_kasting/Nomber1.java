package  Stepik.Lesson25_Polymorfizm_Instanceof_operator_kasting;

public class Nomber1 {
    public static void main(String[] args) {
        Employee emp1 = new Teacher();
        Employee emp2 = new Driver();
        Employee emp3 = new Doctor();
        Employee[]array2={emp1,emp2,emp3};

//        for(Employee emp:array2){                   //пример полиморфизма на ссылку к обьектам
//            emp.work();

        System.out.println(emp1 instanceof Employee);       //instanceof оператор позволяет узнать принадлежит ли обьект к классу

        //полиморфизм это способность обьекта принимать несколько форм
        //обьект в джава считается полиморфным если он имеет больше одной связи IS-A
        //Полиморфизм это способность метода вести себя по разному в зависимости от того обьект какого класса вызывает этот метод
        //Перезаписанные методы также часто называют полиморфными
    }
}
abstract class Employee{
    void sleep(){System.out.println("Работник спит");}
    abstract void work();
}
class Teacher extends Employee implements Help_Able{
    void work(){
        System.out.println("Учитель работает");
    }
    public void help(){
        System.out.println("Учитель помогает");
    }
}
class Driver extends Employee implements Help_Able{
    void work(){
        System.out.println("Водитель работает");
    }
    public void help(){
        System.out.println("Водитель помогает");
    }
}
class Doctor extends Employee implements Help_Able{
    void work(){
        System.out.println("Доктор работает");
    }
    public void help(){
        System.out.println("Доктор помогает");
    }
}
interface Help_Able{
    void help();
}