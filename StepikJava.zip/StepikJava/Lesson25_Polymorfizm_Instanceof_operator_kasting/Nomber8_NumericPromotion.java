package Stepik.Lesson25_Polymorfizm_Instanceof_operator_kasting;

public class Nomber8_NumericPromotion {         //NumericPromotion конвертация численного типа данных в больший
                                                 //NumericPromotion происходит если:
                                //имеются 2 значения разных типов данных Джава автоматически конверирует меньший числовой тип данных в больший
                                //если одно из значений это целое число а другое дробное Джава автоматически конвертирует целочисленный тип данных в дробный
                                //если byte short char участвуют в арифетьических операциях то они конверируются в int даже если в данных арифетических операциях нет inta
                                //искл(Унарные операторы.Использование ++ к типу данных byte не конвертирует результат в int)
    public static void main(String[] args) {
        int i =5;
        long l = 10;
//      i=(int)(i*l);     делаем кастинг но можно по другому
        i*=l;                       //автоматический кастинг
        System.out.println(i+l);    //автоматический кастинг

        float f = 3.14f;
        int i2=10;
        System.out.println(f+i2);           //автоматический кастинг

        byte b =3;
        short s =4;
        char c =5;
        System.out.println(b+s+c);  //все переводятся в int
        System.out.println(b++);    //искл не переводится в int
        System.out.println(b);

        byte b2 =10;
        float f2 =7;
        double d2 =2.0;
        System.out.println(b2+f2-d2);//перевелось в double тк он самый большой

        double d10 = 3.14;
        float f10=6.28f;

        float f11=0*1.5f;
        float f12=0*(float)1.5;

    }
}


