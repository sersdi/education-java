package Stepik.Lesson25_Polymorfizm_Instanceof_operator_kasting;

public class Nomber9 {
    int a,b=3, c, d=b+5;
    int a2,b2=3,c2,d2=a2+5;         //можно писать
//    int a3,b3=3,c3=10-d3,d3=7;    нельзя писать

    public static void main(String[] args) {
        Nomber9 t = new Nomber9();
        System.out.println(t.d2);
    }
}
