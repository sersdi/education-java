package Stepik.Lesson25_Polymorfizm_Instanceof_operator_kasting;

public class Nomber5 {
    public static void main(String[] args) {
        String[]array1={"privet","poka"};
        Object[]array2=array1;              //авто апкастинг любой массив типа обжект
        String[]array3=(String[])array2;    //даункастинг тк не любой обжект это стринг[]
        //array3[0]=new StringBuilder("ok"); ошибка
        array2[0]=new StringBuilder("ok"); //тут тоже ошибка рантайм не пройдет
    }
}
