package Stepik.Lesson25_Polymorfizm_Instanceof_operator_kasting;

public class Nomber2 {
}
class Car{
    static int a = 5;

    public static void main(String[] args) {
        Car c = new Car();
        System.out.println(c.a);
        c=null;
        System.out.println(c.a);        //тк статик переменная она не меняется
    }
}
