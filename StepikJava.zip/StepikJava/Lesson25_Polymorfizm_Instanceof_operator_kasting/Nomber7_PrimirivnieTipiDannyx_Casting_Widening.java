package Stepik.Lesson25_Polymorfizm_Instanceof_operator_kasting;

//                                                      Primitive data types casting
//                                                      19 forms of widening(расширение)
//byte to short,int,long,float,double
//short to int,long,float,double
//char to int,long,float,double
//long to float or double
//
                                            //Narrowing(сужение) without casting происходит если выполняются условия:
//int cast в bite,short,char
//int - final(constanta)
//значение int помещается в соответсвующий тип данных

                                                            //22forms of narrowing(сужения):
//short to byte or char
//char to byte or short
//int to byte or short or char
//long to byte,short,char or int
//float to byte,short,char,int,long or float

public class Nomber7_PrimirivnieTipiDannyx_Casting_Widening {
    public static void main(String[] args) {
        byte b =10;
        int a =b;
        int i1 = 3;
        short s2 =(short)i1;
        int i2 =(int)i1;

        boolean b10 = true;
        byte b2=127;
        short s1=5000;
        char c1=100;
        long l1=1;
        int i10=10000;

        short s10=(short)i10;
        char c10=(char)-19;
        System.out.println(c10);

        int i12= (int)3.64;
        System.out.println(i12);
        double d = 58974568.663;
        byte b12 =(byte) d;             //данные которые не влезают они теряются

        int i = 2147483647;             //max значение инта
        System.out.println(i+1);    //будет -2147483647 тк после максимального значения идёт процесс по кругу и начинается с самого маленького

    }
}
