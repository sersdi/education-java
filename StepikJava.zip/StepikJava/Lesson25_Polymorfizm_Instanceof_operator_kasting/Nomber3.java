package Stepik.Lesson25_Polymorfizm_Instanceof_operator_kasting;

public class Nomber3 {
    public static void main(String[] args) {
        Jumpable j = new Man();
        Man m = new Man();
        Student s = new Student();
        if(j instanceof Jumpable){
            System.out.println("j is Jumpable");
        }
        if(m instanceof Human){
            System.out.println("m is Human");
        }
        if(s instanceof Jumpable){                  //джава не видит на какой сабкласс ссылается стюдент После компиляции она увидит
            System.out.println("s is Jumpable");
        }
    }
}
interface Jumpable{}
class Human implements Jumpable{}
class Man extends Human{}
class Student{}
