package Stepik.Lesson25_Polymorfizm_Instanceof_operator_kasting;

public class Nomber6 {
}
class Test10{
    int a =5;
    void abc(){
        System.out.println("ok");
    }
}
class Test20 extends Test10{
    int a =10;          //hide переменная тк переменные не оверайдятся
    void abc(){
        System.out.println("ok2");
    }
}
class Test30 extends Test20{
    int a =15;
    void abc(){
        System.out.println("ok3");
    }

    public static void main(String[] args) {
        Test30 t = new Test30();
        System.out.println(((Test10)t).a);
        ((Test10)t).abc();          //будет вызываться метод типа Test30 тк он рантаймбайдинг

    }
}
